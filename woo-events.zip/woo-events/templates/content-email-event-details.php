<?php
global $event_items;
$check_ev = false;
foreach ( $event_items as $item ) {
	$product_id = $item['product_id'];
	$we_startdate = get_post_meta( $product_id, 'we_startdate', true );
	$we_enddate = get_post_meta( $product_id, 'we_enddate', true );
	if($we_startdate!=''){
		$check_ev = true;
		break;
	}
}
if($check_ev == true){
	?>
	<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;" border="1">
		<thead>
			<tr>
				<th class="td" scope="col" style="text-align:left;"><?php echo get_option('we_text_evname')!='' ? get_option('we_text_evname') : esc_html__( 'Event Name', 'exthemes' ); ?></th>
				<th class="td" scope="col" style="text-align:left;"><?php echo get_option('we_text_evdate')!='' ? get_option('we_text_evdate') : esc_html__( 'Event Date', 'exthemes' ); ?></th>
				<th class="td" scope="col" style="text-align:left;"><?php echo get_option('we_text_evlocati')!='' ? get_option('we_text_evlocati') : esc_html__( 'Event Location', 'exthemes' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $event_items as $item ) {
					$product_name = $item['name'];
					$product_id = $item['product_id'];
					$product_variation_id = $item['variation_id'];
					$we_startdate = get_post_meta( $product_id, 'we_startdate', true );
					$we_enddate = get_post_meta( $product_id, 'we_enddate', true );
					$all_day = get_post_meta($product_id,'we_allday', true );
					if($we_startdate!=''){
					?>
					<tr>
						<td class="td" scope="col" style="text-align:left; border: 1px solid #e4e4e4;"><?php echo $item['name'];?></td>
						<td class="td" scope="col" style="text-align:left; border: 1px solid #e4e4e4;">
							<span class="">
                            <b><?php echo get_option('we_text_stdate')!='' ? get_option('we_text_stdate') : esc_html__('Start Date','exthemes');?>: </b>
							<?php
							echo date_i18n( get_option('date_format'), $we_startdate).' ';
                            if(($we_enddate=='') || ($all_day!='1' && (date_i18n(get_option('time_format'), $we_startdate)!=date_i18n(get_option('time_format'), $we_enddate)))){ 
                                echo date_i18n(get_option('time_format'), $we_startdate);
                            }
							?>
                            </span><br>
							<span class=""><b><?php echo get_option('we_text_edate')!='' ? get_option('we_text_edate') : esc_html__('End Date','exthemes');?>: </b>
							<?php
							echo date_i18n( get_option('date_format'), $we_enddate);
                            if($all_day!='1' && (date_i18n(get_option('time_format'), $we_startdate)!=date_i18n(get_option('time_format'), $we_enddate))){ 
                                echo ' '.date_i18n(get_option('time_format'), $we_enddate);
                            }elseif($all_day=='1'){ 
								$alltrsl = get_option('we_text_allday')!='' ? get_option('we_text_allday') : esc_html__('(All day)','exthemes');
								echo '<span> '.$alltrsl.'</span>';
							}?>
                            </span><br>
                            <?php 
							$we_show_timezone = get_option('we_show_timezone');
							$we_time_zone = get_post_meta($product_id,'we_time_zone', true );
							if($we_show_timezone=='yes' && $we_time_zone!='' && $we_time_zone!='def'){?>
                            <span class=""><b><?php echo get_option('we_text_timezone_')!='' ? get_option('we_text_timezone_') : esc_html__('Timezone','exthemes');?>: </b>
                            	<?php 
								if (strpos($we_time_zone, '-') !== false) {
									echo 'UTC'.$we_time_zone;
								}else{
									echo 'UTC+'.$we_time_zone;
								}?>
                            </span><br>
                            <?php }?>
						</td>
						<td class="td" scope="col" style="text-align:left; border: 1px solid #e4e4e4;"><?php echo get_post_meta( $product_id, 'we_adress', true );?></td>
					</tr>
					<?php
					}else{
						$product_id = wp_get_post_parent_id( $product_id );
						$we_startdate = get_post_meta( $product_id, 'we_startdate', true );
						$we_enddate = get_post_meta( $product_id, 'we_enddate', true );
						if($we_startdate!=''){
							?>
							<tr>
								<td class="td" scope="col" style="text-align:left; border: 1px solid #e4e4e4;"><?php echo get_the_title($product_id);?></td>
								<td class="td" scope="col" style="text-align:left; border: 1px solid #e4e4e4;">
									<span class=""><b><?php echo get_option('we_text_stdate')!='' ? get_option('we_text_stdate') : esc_html__('Start Date','exthemes');?>: </b><?php echo date_i18n( get_option('date_format'), $we_startdate).' '.date_i18n(get_option('time_format'), $we_startdate);?></span><br>
									<span class=""><b><?php echo get_option('we_text_edate')!='' ? get_option('we_text_edate') : esc_html__('End Date','exthemes');?>: </b><?php echo date_i18n( get_option('date_format'), $we_enddate).' '.date_i18n(get_option('time_format'), $we_enddate);?></span><br>
                                    <?php 
									$we_show_timezone = get_option('we_show_timezone');
									$we_time_zone = get_post_meta($product_id,'we_time_zone', true );
									if($we_show_timezone=='yes' && $we_time_zone!='' && $we_time_zone!='def'){?>
									<span class=""><b><?php echo get_option('we_text_timezone_')!='' ? get_option('we_text_timezone_') : esc_html__('Timezone','exthemes');?>: </b>
										<?php 
										if (strpos($we_time_zone, '-') !== false) {
											echo apply_filters( 'wooevent_timezone_html', 'UTC'.$we_time_zone, $we_time_zone );
										}else{
											echo apply_filters( 'wooevent_timezone_html', 'UTC+'.$we_time_zone, $we_time_zone );
										}?>
									</span><br>
									<?php }?>
                                    
								</td>
								<td class="td" scope="col" style="text-align:left; border: 1px solid #e4e4e4;"><?php echo get_post_meta( $product_id, 'we_adress', true );?></td>
							</tr>
							<?php
						}
					}
					
				} ?>
		</tbody>
		<tfoot>
		</tfoot>
	</table>
	<?php
}