<?php
class WooEvent_Reminder_Email {
	public function __construct()
    {
		add_filter( 'exc_mb_meta_boxes', array($this,'email_reminder_metadata') );
		// Schedule the event when the order is completed.
		add_action( 'woocommerce_order_status_completed', array( $this, 'remind_email' ), 10, 1 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'remind_email_fb' ), 11, 1 );
		// Trigger the email.
		add_action( 'wooevent_email_reminder', array( $this, 'send_mail' ), 1,2 );
		add_action( 'wooevent_email_reminder_2', array( $this, 'send_mail' ), 1,2 );
		add_action( 'wooevent_email_reminder_3', array( $this, 'send_mail' ), 1,2 );
		add_action( 'wooevent_email_reminder_feedback', array( $this, 'send_mail_fb' ), 1,2 );
    }
	/**
	 * Gets permalinks from order.
	 *
	 * @param  int    $order_id Order ID.
	 *
	 * @return string           Permalinks.
	 */
	protected function get_permalinks_from_order( $order_id ) {
		global $wpdb;
		$permalinks = '<ul>';

		// Get all order items.
		$order_item_ids = $wpdb->get_col(
			$wpdb->prepare( "
				SELECT
				order_item_id
				FROM
				{$wpdb->prefix}woocommerce_order_items
				WHERE
				order_id = %d
			", $order_id )
		);

		// Get products ids.
		foreach ( $order_item_ids as $order_item_id ) {
			$product_id = $wpdb->get_row(
				$wpdb->prepare( "
					SELECT
					meta_value
					FROM
					{$wpdb->prefix}woocommerce_order_itemmeta
					WHERE
					order_item_id = %d
					AND
					meta_key = '_product_id'
				", $order_item_id ),
				ARRAY_N
			);

			// Test whether the product actually was found.
			if ( is_array( $product_id ) ) {
				$product_ids[] = implode( $product_id );
			}
		}

		// Creates products links.
		foreach ( $product_ids as $product_id ) {
			$permalinks .= sprintf( '<li><a href="%1$s" target="_blank">%1$s</a></li>', get_permalink( $product_id ) );
		}

		$permalinks .= '</ul>';

		return $permalinks;
	}
	/**
	 * Gets permalinks from order.
	 *
	 * @param  int    $order_id Order ID.
	 *
	 * @return string           Permalinks.
	 */
	protected function get_idproduct_from_order( $order_id ) {
		global $wpdb;
		// Get all order items.
		$order_item_ids = $wpdb->get_col(
			$wpdb->prepare( "
				SELECT
				order_item_id
				FROM
				{$wpdb->prefix}woocommerce_order_items
				WHERE
				order_id = %d
			", $order_id )
		);

		// Get products ids.
		foreach ( $order_item_ids as $order_item_id ) {
			$product_id = $wpdb->get_row(
				$wpdb->prepare( "
					SELECT
					meta_value
					FROM
					{$wpdb->prefix}woocommerce_order_itemmeta
					WHERE
					order_item_id = %d
					AND
					meta_key = '_product_id'
				", $order_item_id ),
				ARRAY_N
			);

			// Test whether the product actually was found.
			if ( is_array( $product_id ) ) {
				$product_ids[] = implode( $product_id );
			}
		}

		return $product_ids;
	}
	/**
	 * Remind email action.
	 *
	 * @param  int  $order_id Order ID.
	 *
	 * @return void
	 */
	public function remind_email( $order_id ) {
		$interval_type  = get_option( 'we_email_timeformat' )!='' ? get_option( 'we_email_timeformat' ) : 1;
		$interval_count = get_option( 'we_email_delay' )!='' ? get_option( 'we_email_delay' ) : 604800;
		
		$we_emtimeformat_2  = get_option( 'we_emtimeformat_2' );
		$we_emdelay_2 = get_option( 'we_emdelay_2' );
		
		$we_emtimeformat_3  = get_option( 'we_emtimeformat_3' );
		$we_emdelay_3 = get_option( 'we_emdelay_3' );
		
		$product_ids = $this->get_idproduct_from_order( $order_id );
		foreach ( $product_ids as $product_id ) {
			if(get_option('we_emreminder_single') == 'on'){
				$sg_em1 = get_post_meta( $product_id, 'we_email_delay', true );
				$sg_em2 = get_post_meta( $product_id, 'we_emdelay_2', true );
				$sg_em3 = get_post_meta( $product_id, 'we_emdelay_3', true );
				if($sg_em1!='' || $sg_em2!='' || $sg_em3!=''){
					$interval_type  = get_post_meta( $product_id, 'we_email_timeformat', true );
					$interval_count = $sg_em1;
					
					$we_emtimeformat_2  = get_post_meta( $product_id, 'we_emtimeformat_2', true );
					$we_emdelay_2 = $sg_em2;
					
					$we_emtimeformat_3  = get_post_meta( $product_id, 'we_emtimeformat_3', true );
					$we_emdelay_3 = $sg_em3;
				}
			}
			$startdate = get_post_meta( $product_id, 'we_startdate', true ) ;
			if($startdate!='' && is_numeric($startdate)){
				$gmt_offset = get_option('gmt_offset');
				// First time Sending email
				$we_startdate = $startdate - ($gmt_offset*3600);
				if(is_numeric($interval_count) && is_numeric($interval_type)){
					$interval = $startdate*1 - ($interval_count*$interval_type);
					if(is_numeric($gmt_offset)){
						$interval = $interval - ($gmt_offset*3600);
					}
					//echo $interval.'  -now- '.time();exit;
					if(($we_startdate > time()) && ($interval > time())){
						wp_schedule_single_event( $interval, 'wooevent_email_reminder', array( $order_id, $product_id ) );
					}
				}
				// Second time Sending email
				if(is_numeric($we_emdelay_2) && is_numeric($we_emtimeformat_2)){
					$interval_2 = $startdate*1 - ($we_emdelay_2*$we_emtimeformat_2);
					if(is_numeric($gmt_offset)){
						$interval_2 = $interval_2 - ($gmt_offset*3600);
					}
					if(($we_startdate > time()) && ($interval_2 > time())){
						wp_schedule_single_event( $interval_2, 'wooevent_email_reminder_2', array( $order_id, $product_id ) );
					}
				}
				// Third time Sending email
				if(is_numeric($we_emdelay_3) && is_numeric($we_emtimeformat_3)){
					$interval_3 = $startdate*1 - ($we_emdelay_3*$we_emtimeformat_3);
					if(is_numeric($gmt_offset)){
						$interval_3 = $interval_3 - ($gmt_offset*3600);
					}
					if(($we_startdate > time()) && ($interval_3 > time())){
						wp_schedule_single_event( $interval_3, 'wooevent_email_reminder_3', array( $order_id, $product_id ) );
					}
				}
			}
			
		}
	}

	/**
	 * Sends the email notification.
	 *
	 * @param  int  $order_id Order ID.
	 *
	 * @return void
	 */
	public function send_mail( $order_id , $product_id) {
		global $woocommerce;
		$mailer = $woocommerce->mailer();
		$order = new WC_Order( $order_id );
		if(method_exists($order,'get_status') && $order->get_status()!='completed'){
			return;
		}
		$subject = apply_filters(
			'wooevent_reminder_email_subject',
			esc_html__( 'Email Reminder from ', 'exthemes' ).get_bloginfo( 'name', 'display' ),
			$order
		);

		// Mail headers.
		$headers = array();
		$headers[] = "Content-Type: text/html\r\n";

		// Message title.
		$message_title = apply_filters(
			'wooevent_reminder_email_title',
			esc_html__( 'Email Reminder from ', 'exthemes' ).get_bloginfo( 'name', 'display' ),
			$order
		);

		// Message body.
		$we_email_content = get_post_meta($product_id,'we_email_content', true );
		if(preg_replace('/\s+/', '', $we_email_content) == ''){
			if ($order->billing_first_name){
				$first_name = ', '.$order->billing_first_name;
				if ($order->billing_last_name){
					$last_name = ' '.$order->billing_last_name;
				}
			}
			else{
				if ($order->billing_last_name){
					$last_name = ', '.$order->billing_last_name;
				}
			}
			$all_day = get_post_meta($product_id,'we_allday', true );
			$we_startdate = get_post_meta( $product_id, 'we_startdate', true ) ;
			$we_enddate = get_post_meta( $product_id, 'we_enddate', true ) ;
			$st_d = date_i18n( 'd', $we_startdate);
			$e_d = date_i18n( 'd', $we_enddate);
			$date = date_i18n( get_option('date_format'), $we_startdate).' '.date_i18n(get_option('time_format'), $we_startdate);
			if( $all_day!='1' && (date_i18n(get_option('time_format'), $we_startdate)!=date_i18n(get_option('time_format'), $we_enddate))){ 
				if($st_d != $e_d){
					$date .= ' - '.date_i18n( get_option('date_format'), $we_enddate).' '.date_i18n(get_option('time_format'), $we_enddate);
				}else{
					$date .= ' - '.date_i18n(get_option('time_format'), $we_enddate);
				}
			}elseif($all_day!='1' && (date_i18n(get_option('time_format'), $we_startdate)==date_i18n(get_option('time_format'), $we_enddate))){
				if($st_d != $e_d){
					$date .= ' - '.date_i18n( get_option('date_format'), $we_enddate).' '.date_i18n(get_option('time_format'), $we_enddate);
				}
			}
			$link = get_permalink( $product_id );
			$title = get_the_title($product_id);
			$body = '<p>' . esc_html__( 'This is an automatic reminder of the following event', 'exthemes' ) . '</p>' .
				'<h2><a href="'.$link.'">'.$title.'</a></h2>'.
				'<p><strong>' . esc_html__( 'Date', 'exthemes' ) . ': </strong>'.$date.'</p>'.
				'<p>' . esc_html__( 'Additional information', 'exthemes' ) . '</p>'.
				'<p>' . esc_html__( 'This is a reminder that you had registered for "','exthemes').$title.'".'.esc_html__('We look forward to seeing you', 'exthemes' ) . '</p>';
			$ct_email = get_option('we_email_content');
			if($ct_email!=''){
				$ct_email = str_replace('[eventitle]', $title, $ct_email);
				$ct_email = str_replace('[eventdate]', $date, $ct_email);
				$ct_email = str_replace('[eventlink]', $link, $ct_email);
				$body = $ct_email;
			}
		}else{
			$body = $we_email_content;
		}

		$message_body = apply_filters(
			'wooevent_reminder_email_message',
			$body,
			$order,
			$product_id
		);

		// Sets the message template.
		$message = apply_filters( 
			'wooevent_reminder_email_template',
			$mailer->wrap_message( $message_title, $message_body ),
			$message_title, 
			$message_body,
			$we_email_content
		);

		// Send the email.
		$mailer->send( $order->billing_email, $subject, $message, $headers, '' );
	}
	/**
	 * Remind email feedback action.
	 *
	 * @param  int  $order_id Order ID.
	 *
	 * @return void
	 */
	public function remind_email_fb( $order_id ) {
		if(get_option('we_email_reminder_fb') == 'off'){ return;}
		$interval_type  = get_option( 'we_email_fbtimefm' )!='' ? get_option( 'we_email_fbtimefm' ) : 1;
		$interval_count = get_option( 'we_email_fbdelay' )!='' ? get_option( 'we_email_fbdelay' ) : '';
		
		$product_ids = $this->get_idproduct_from_order( $order_id );
		$gmt_offset = get_option('gmt_offset');
		$sgos = get_option('we_reminder_fbsg');
		foreach ( $product_ids as $product_id ) {
			if($sgos == 'on'){
				$sg_em1 = get_post_meta( $product_id, 'we_email_fbdelay', true );
				if($sg_em1!=''){
					$interval_type  = get_post_meta( $product_id, 'we_email_fbtimefm', true );
					$interval_count = $sg_em1;
				}
			}
			$enddate = get_post_meta( $product_id, 'we_enddate', true ) ;
			if($enddate!='' && is_numeric($enddate)){
				// time Sending email
				if(is_numeric($interval_count) && is_numeric($interval_type)){
					$interval = $enddate*1 + ($interval_count*$interval_type);
					if(is_numeric($gmt_offset)){
						$interval = $interval - ($gmt_offset*3600);
					}
					//echo $interval.'  -now- '.time();exit;
					if($interval > time()){
						wp_schedule_single_event( $interval, 'wooevent_email_reminder_feedback', array( $order_id, $product_id ) );
					}
				}
			}
			
		}
	}
	/**
	 * Sends the email feedback notification.
	 *
	 * @param  int  $order_id Order ID.
	 *
	 * @return void
	 */
	public function send_mail_fb( $order_id , $product_id) {
		global $woocommerce;
		$mailer = $woocommerce->mailer();
		$order = new WC_Order( $order_id );
		if(method_exists($order,'get_status') && $order->get_status()!='completed'){
			return;
		}
		$we_email_content = get_post_meta($product_id,'we_email_fbcontent', true );
		$ct_email = get_option('we_email_content');
		if(preg_replace('/\s+/', '', $we_email_content) =='' && preg_replace('/\s+/', '', $ct_email)==''){
			return;
		}
		$subject = apply_filters(
			'wooevent_reminder_fb_email_subject',
			esc_html__( 'Email Thank you from ', 'exthemes' ).get_bloginfo( 'name', 'display' ),
			$order
		);
		// Mail headers.
		$headers = array();
		$headers[] = "Content-Type: text/html\r\n";
		// Message title.
		$message_title = apply_filters(
			'wooevent_reminder_fb_email_title',
			esc_html__( 'Email Thank you from ', 'exthemes' ).get_bloginfo( 'name', 'display' ),
			$order
		);
		// Message body.
		if(preg_replace('/\s+/', '', $we_email_content) == ''){
			if ($order->billing_first_name){
				$first_name = ', '.$order->billing_first_name;
				if ($order->billing_last_name){
					$last_name = ' '.$order->billing_last_name;
				}
			}
			else{
				if ($order->billing_last_name){
					$last_name = ', '.$order->billing_last_name;
				}
			}
			$all_day = get_post_meta($product_id,'we_allday', true );
			$we_startdate = get_post_meta( $product_id, 'we_startdate', true ) ;
			$we_enddate = get_post_meta( $product_id, 'we_enddate', true ) ;
			$st_d = date_i18n( 'd', $we_startdate);
			$e_d = date_i18n( 'd', $we_enddate);
			$date = date_i18n( get_option('date_format'), $we_startdate).' '.date_i18n(get_option('time_format'), $we_startdate);
			if( $all_day!='1' && (date_i18n(get_option('time_format'), $we_startdate)!=date_i18n(get_option('time_format'), $we_enddate))){ 
				if($st_d != $e_d){
					$date .= ' - '.date_i18n( get_option('date_format'), $we_enddate).' '.date_i18n(get_option('time_format'), $we_enddate);
				}else{
					$date .= ' - '.date_i18n(get_option('time_format'), $we_enddate);
				}
			}elseif($all_day!='1' && (date_i18n(get_option('time_format'), $we_startdate)==date_i18n(get_option('time_format'), $we_enddate))){
				if($st_d != $e_d){
					$date .= ' - '.date_i18n( get_option('date_format'), $we_enddate).' '.date_i18n(get_option('time_format'), $we_enddate);
				}
			}
			$link = get_permalink( $product_id );
			$title = get_the_title($product_id);
			if($ct_email!=''){
				$ct_email = str_replace('[eventitle]', $title, $ct_email);
				$ct_email = str_replace('[eventdate]', $date, $ct_email);
				$ct_email = str_replace('[eventlink]', $link, $ct_email);
				$body = $ct_email;
			}
		}else{
			$body = $we_email_content;
		}

		$message_body = apply_filters(
			'wooevent_reminder_fb_email_message',
			$body,
			$order,
			$product_id
		);

		// Sets the message template.
		$message = apply_filters( 
			'wooevent_reminder_fb_email_template',
			$mailer->wrap_message( $message_title, $message_body ),
			$message_title, 
			$message_body,
			$we_email_content
		);

		// Send the email.
		$mailer->send( $order->billing_email, $subject, $message, $headers, '' );
	}
	// register metadata
	
	function email_reminder_metadata(array $meta_boxes){
		if(get_option('we_emreminder_single') == 'on'){
			$event_reminder_time = array(
				array( 'id' => 'we_email_delay',  'name' => esc_html__('The First time', 'exthemes'), 'type' => 'text' ),
				array( 'id' => 'we_email_timeformat', 'name' => 'Type', 'type' => 'select', 'options' => array( 
					'' => esc_html__('', 'exthemes'), 
					'1' => esc_html__( 'seconds', 'exthemes' ),
					'60' => esc_html__( 'minutes', 'exthemes' ),
					'3600' => esc_html__( 'hours', 'exthemes' ),
					'86400' => esc_html__( 'days', 'exthemes' ),
					'604800' => esc_html__( 'weeks', 'exthemes' ),
					'18144000' => esc_html__( 'months', 'exthemes' ),
				),
				'desc' => esc_html__('Select type of time', 'exthemes') , 'repeatable' => false, 'multiple' => false),
				array( 'id' => 'we_emdelay_2',  'name' => esc_html__('The Second time', 'exthemes'), 'type' => 'text' ),
				array( 'id' => 'we_emtimeformat_2', 'name' => 'Type', 'type' => 'select', 'options' => array( 
					'' => esc_html__('', 'exthemes'), 
					'1' => esc_html__( 'seconds', 'exthemes' ),
					'60' => esc_html__( 'minutes', 'exthemes' ),
					'3600' => esc_html__( 'hours', 'exthemes' ),
					'86400' => esc_html__( 'days', 'exthemes' ),
					'604800' => esc_html__( 'weeks', 'exthemes' ),
					'18144000' => esc_html__( 'months', 'exthemes' ),
				),
				'desc' => esc_html__('Select type of time', 'exthemes') , 'repeatable' => false, 'multiple' => false),
				array( 'id' => 'we_emdelay_3',  'name' => esc_html__('The Third time', 'exthemes'), 'type' => 'text' ),
				array( 'id' => 'we_emtimeformat_3', 'name' => 'Type', 'type' => 'select', 'options' => array( 
					'' => esc_html__('', 'exthemes'), 
					'1' => esc_html__( 'seconds', 'exthemes' ),
					'60' => esc_html__( 'minutes', 'exthemes' ),
					'3600' => esc_html__( 'hours', 'exthemes' ),
					'86400' => esc_html__( 'days', 'exthemes' ),
					'604800' => esc_html__( 'weeks', 'exthemes' ),
					'18144000' => esc_html__( 'months', 'exthemes' ),
				),
				'desc' => esc_html__('Select type of time', 'exthemes') , 'repeatable' => false, 'multiple' => false),
				array( 'id' => 'we_email_content',  'name' => esc_html__('Content of Email', 'exthemes'), 'type' => 'wysiwyg' ),
			);
			$meta_boxes[] = array(
				'title' => __('Email reminder Setting','exthemes'),
				'context' => 'side',
				'pages' => 'product',
				'fields' => $event_reminder_time,
				'priority' => '',
			);
		}
		
		if(get_option('we_email_reminder_fb') != 'off' && get_option('we_reminder_fbsg') == 'on'){
			$event_reminder_fb = array(
				array( 'id' => 'we_email_fbdelay',  'name' => esc_html__('Time for sending', 'exthemes'), 'type' => 'text' ),
				array( 'id' => 'we_email_fbtimefm', 'name' => 'Type', 'type' => 'select', 'options' => array( 
					'' => esc_html__('', 'exthemes'), 
					'3600' => esc_html__( 'hours', 'exthemes' ),
					'86400' => esc_html__( 'days', 'exthemes' ),
					'604800' => esc_html__( 'weeks', 'exthemes' ),
				),
				'desc' => esc_html__('Select type of time', 'exthemes') , 'repeatable' => false, 'multiple' => false),
				array( 'id' => 'we_email_fbcontent',  'name' => esc_html__('Content of Email', 'exthemes'), 'type' => 'wysiwyg' ),
			);
			$meta_boxes[] = array(
				'title' => __('Email Feedback Setting','exthemes'),
				'context' => 'side',
				'pages' => 'product',
				'fields' => $event_reminder_fb,
				'priority' => '',
			);
		}
		return $meta_boxes;
	}

}
$WooEvent_Reminder_Email = new WooEvent_Reminder_Email();