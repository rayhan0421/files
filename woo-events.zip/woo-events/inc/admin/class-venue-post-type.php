<?php
class WooEvent_Venue {
	public function __construct()
    {
        add_action( 'init', array( &$this, 'register_post_type' ) );
		add_filter( 'exc_mb_meta_boxes', array($this,'venue_metadata') );
    }

	function register_post_type(){
		$labels = array(
			'name'               => esc_html__('Venue','exthemes'),
			'singular_name'      => esc_html__('Venue','exthemes'),
			'add_new'            => esc_html__('Add New Venue','exthemes'),
			'add_new_item'       => esc_html__('Add New Venue','exthemes'),
			'edit_item'          => esc_html__('Edit Venue','exthemes'),
			'new_item'           => esc_html__('New Venue','exthemes'),
			'all_items'          => esc_html__('Venues','exthemes'),
			'view_item'          => esc_html__('View Venue','exthemes'),
			'search_items'       => esc_html__('Search Venue','exthemes'),
			'not_found'          => esc_html__('No Venue found','exthemes'),
			'not_found_in_trash' => esc_html__('No Venue found in Trash','exthemes'),
			'parent_item_colon'  => '',
			'menu_name'          => esc_html__('Venues','exthemes')
		);
		
		$we_venue_slug = get_option('we_venue_slug');
		if($we_venue_slug==''){
			$we_venue_slug = 'venue';
		}
		$rewrite =  array( 'slug' => untrailingslashit( $we_venue_slug ), 'with_front' => false, 'feeds' => true );
		$args = array(  
			'labels' => $labels,  
			'supports' => array('title','thumbnail','custom-fields','editor'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => 'edit.php?post_type=product',
			'menu_icon' =>  'dashicons-groups',
			'query_var'          => true,
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'rewrite' => $rewrite,
		);  
		register_post_type('we_venue',$args);  
	}
	function venue_metadata(array $meta_boxes){
		// register meta
		$venue_settings = array(	
				array( 'id' => 'we_adress', 'name' => esc_html__('Address', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Location Address of event', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			array( 'id' => 'we_latitude_longitude', 'name' => esc_html__('Latitude and Longitude (optional)', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Physical address of your event location, if Event map shortcode cannot load your address, you need to fill Latitude and Longitude to fix it, you can find phisical address here: https://ctrlq.org/maps/address/. Enter Latitude and Longitude, separated by a comma. Ex for London: 42.9869502,-81.243177', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			
			array( 'id' => 'we_phone', 'name' => esc_html__('Phone', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Contact Number of event', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			array( 'id' => 'we_email', 'name' => esc_html__('Email', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Email Contact of event', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			array( 'id' => 'we_website', 'name' => esc_html__('Website', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Website URL of event', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
		);

		$meta_boxes[] = array(
			'title' => __('Venue Info','exthemes'),
			'pages' => 'we_venue',
			'fields' => $venue_settings,
			'priority' => 'high'
		);
		return $meta_boxes;
	}
	
}
$WooEvent_Venue = new WooEvent_Venue();
//Register bulk update button
function we_bulk_update_venue_box() {
    add_meta_box( 'we-bulk-update-venue', esc_html__( 'Bulk update venue info', 'exthemes' ), 'we_bulk_update_venue_button', 'we_venue', 'side', 'high' );
}
add_action( 'add_meta_boxes', 'we_bulk_update_venue_box',99);
 
//Add field
function we_bulk_update_venue_button( $meta_id ) {
 
    $outline = '<label for="bulk-venue" class="exc_mb_metabox_description">'. esc_html__('This feature allow you can update venue info to all events contain this venue in one click', 'exthemes') .'</label>';
    $outline .= '<input type="button" name="bulk-update-venue" id="bulk-update-venue" class="button" value="'. esc_html__('Update','exthemes') .'" data-id="'.$_GET['post'].'" style="margin-top: 10px;"/>';
 
    echo $outline;
}
// ajax update venue
add_action( 'wp_ajax_we_update_events_venue', 'we_update_events_venue' );
add_action( 'wp_ajax_nopriv_we_update_events_venue', 'we_update_events_venue' );
function we_update_events_venue(){
	if(!isset($_POST['id']) || !is_numeric($_POST['id'])){ echo 3; die;}
	$id = $_POST['id'];
	$args = array(
		'post_type' => 'product',
		'posts_per_page' => 999,
		'post_status' => 'publish',
		'ignore_sticky_posts' => 1,
	);
	$args ['meta_query'] = array(
		 array(
			'key'     => 'we_default_venue',
			'value'   => $id,
			'compare' => '=',
		 ),
	);
	$we_adress = get_post_meta( $id, 'we_adress', true ) ;
	$we_latitude_longitude = get_post_meta( $id, 'we_latitude_longitude', true ) ;
	$we_phone = get_post_meta( $id, 'we_phone', true ) ;
	$we_email = get_post_meta( $id, 'we_email', true ) ;
	$we_website = get_post_meta( $id, 'we_website', true ) ;
	$this_posts = get_posts( $args );
	$found = 0;
	foreach ( $this_posts as $post ) {
		$found  = 1;
		if($we_adress!=''){
			update_post_meta( $post->ID, 'we_adress', $we_adress);
		}
		if($we_latitude_longitude!=''){
		update_post_meta( $post->ID, 'we_latitude_longitude', $we_latitude_longitude);
		}
		if($we_phone!=''){
			update_post_meta( $post->ID, 'we_phone', $we_phone);
		}
		if($we_email!=''){
			update_post_meta( $post->ID, 'we_email', $we_email);
		}
		if($we_website!=''){
			update_post_meta( $post->ID, 'we_website', $we_website);
		}
	}
	echo $found;
	die;
}

