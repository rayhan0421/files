<?php
class WooEvent_Meta {
	public function __construct()
    {
		add_action( 'save_post', array($this,'recurrence_event') );
		add_action( 'init', array($this,'init'), 0);
    }
	function init(){
		add_filter( 'exc_mb_meta_boxes', array($this,'wooevent_metadata') );
	}
	//Recurrence event
	function recurrence_event( $post_id ) {
		
		if('product' == get_post_type()){
			do_action('we_before_create_recurring_event',$post_id,$_POST);
			$_recurr = get_post_meta($post_id,'recurren_ext', true );
			if($_recurr!=''){
				$mrcc_id  = explode("_",$_recurr);
				if(isset($mrcc_id[1]) && $mrcc_id[1]!=''){
					$_ctdate = get_post_meta($mrcc_id[1],'we_ctdate', false );
					$_crrlist = get_post_meta($mrcc_id[1],'recurren_list', true );
					$_std = get_post_meta($post_id,'we_startdate', true );
					$_edt = get_post_meta($post_id,'we_enddate', true );
					$_ald = get_post_meta($post_id,'we_allday', true );
					if(!empty($_ctdate)){
						foreach($_ctdate as $ix=> $valu){
							if($valu['we_ct_allday'] == $_ald && $valu['we_ct_stdate'] == $_std && $valu['we_ct_edate_end'] == $_edt  ){
								unset($_ctdate[$ix]);
								if (is_array($_crrlist) && ($key = array_search($post_id, $_crrlist)) !== false) {
									unset($_crrlist[$key]);
									update_post_meta( $mrcc_id[1], 'recurren_list', array_values($_crrlist));
								}
								update_post_meta( $post_id, 'recurren_ext', '');
								delete_post_meta( $mrcc_id[1], 'we_ctdate');
								foreach($_ctdate as $ix=> $valu){
									add_post_meta($mrcc_id[1], 'we_ctdate', $valu, false);
								}
								break;
							}
						}
					}
				}
			}
			
		}
		
		if('product' != get_post_type() || !isset($_POST['we_recurrence'])) { return;}
		$recurrence = $_POST['we_recurrence'];
		$we_startdate = $_POST['we_startdate'];
		$we_enddate = $_POST['we_enddate'];
		$cv_sd = strtotime(str_replace("/","-",$we_startdate['exc_mb-field-0']['date']));
		if(isset($we_startdate['exc_mb-field-0']['date']) && $cv_sd!=''){
			$_POST['we_startdate']['exc_mb-field-0']['date'] = date("d/m/Y", $cv_sd);
		}
		$cv_sd = strtotime(str_replace("/","-",$we_enddate['exc_mb-field-0']['date']));
		if(isset($we_enddate['exc_mb-field-0']['date']) && $cv_sd !=''){
			$_POST['we_enddate']['exc_mb-field-0']['date'] = date("d/m/Y", $cv_sd);
		}
		if(get_option('we_date_picker')=='dmy'){
			$_POST['we_startdate']['exc_mb-field-0']['date'] = str_replace(".","-",$we_startdate['exc_mb-field-0']['date']);
			$_POST['we_enddate']['exc_mb-field-0']['date'] = str_replace(".","-",$we_enddate['exc_mb-field-0']['date']);
			$_POST['we_recurrence_end']['exc_mb-field-0'] = str_replace(".","-",$_POST['we_recurrence_end']['exc_mb-field-0'] );
		}
		global $product;
		$ex_recurr = get_post_meta($post_id,'recurren_ext', true );
		if($recurrence['exc_mb-field-0']!= get_post_meta($post_id,'we_recurrence', true )){
			$recurren_list = get_post_meta($post_id,'recurren_list', true );
			if(!empty($recurren_list)){
				foreach($recurren_list as $idit){
					update_post_meta( $idit, 'recurren_ext', '');
				}
			}
		}
		$attach_id = get_post_thumbnail_id($post_id);
		if(!isset($recurrence['exc_mb-field-0']) || $recurrence['exc_mb-field-0']==''){
			update_post_meta( $post_id, 'recurren_ext', '');
			update_post_meta( $post_id, 'recurren_list', '');
			return;
		}
		if ($recurrence['exc_mb-field-0']=='day' || $recurrence['exc_mb-field-0']=='week' || $recurrence['exc_mb-field-0']=='month') {
			
			$we_recurrence_end = $_POST['we_recurrence_end'];
			$ev_date = (strtotime($we_enddate['exc_mb-field-0']['date']) - strtotime($we_startdate['exc_mb-field-0']['date']));
			$c_number = $ev_date/86400;
			$date_ed =  (strtotime($we_recurrence_end['exc_mb-field-0'])- strtotime($we_startdate['exc_mb-field-0']['date']));
			if($recurrence['exc_mb-field-0']=='day'){
				if($ev_date!=0){
					$date_ed = floor($date_ed/($ev_date + 86400));
				}elseif($ev_date==0){$date_ed = $date_ed/86400;}//echo $date_ed;exit;
				$number_plus = $c_number + 1;
			}elseif($recurrence['exc_mb-field-0']=='week'){
				if($ev_date!=0){
					$num_w = $ev_date + 86400*7;
					$date_ed = round($date_ed/$num_w);
				}else{ $date_ed = round($date_ed/(86400*7));}
				$number_plus = 7;
			}elseif($recurrence['exc_mb-field-0']=='month'){
				if($ev_date!=0){
					$n_m = $ev_date + 86400*30;
					$date_ed = round($date_ed/$n_m);
				}else{ $date_ed = round($date_ed/(86400*30));}
				$number_plus = 30;
			}
			if($ex_recurr !=''){
				$ev_stc = get_post_meta($post_id,'we_startdate', true );
				$ev_edc = get_post_meta($post_id,'we_enddate', true );
				$ev_recurrence_end = get_post_meta($post_id,'we_recurrence_end', true );
				$ev_recurrence = get_post_meta($post_id,'we_recurrence', true );
				$cr_st = strtotime($we_startdate['exc_mb-field-0']['date'] .' '. $we_startdate['exc_mb-field-0']['time']);
				$cr_ed = strtotime($we_enddate['exc_mb-field-0']['date'] .' '. $we_enddate['exc_mb-field-0']['time']);
				$cr_rec = strtotime($we_recurrence_end['exc_mb-field-0']);
				$ctmcheck = 0;
				if($ev_stc !=$cr_st || $ev_edc!= $cr_ed || $ev_recurrence_end!= $cr_rec || $ev_recurrence!= $recurrence['exc_mb-field-0']){
					$ctmcheck = 1;
				}
				$args = array(
					'post_type' => 'product',
					'post_status' => get_post_status ( $post_id ),
					'post__not_in' => array( $post_id ),
					'posts_per_page' => -1,
					'order' => 'ASC',
					'meta_key' => 'recurren_ext',
					'orderby' => 'meta_value_num',
					'meta_query' => array(
						array(
							'key'     => 'recurren_ext',
							'value'   => $ex_recurr,
							'compare' => '=',
						),
					),
				);
				$ex_posts = get_posts( $args );
				foreach($ex_posts as $item){
					remove_action( 'save_post', array($this,'recurrence_event' ));
					$stdate = get_post_meta($item->ID,'we_startdate', true );
					$enddate = get_post_meta($item->ID,'we_enddate', true );
					if($ctmcheck==1){
						wp_delete_post($item->ID);
					}else{
						we_update_recurren($_POST,$item->ID,$post_id,$stdate);
						if (class_exists('SitePress') && function_exists('wooevent_wpml_duplicate_product')) {
							wooevent_wpml_duplicate_product( $item->ID, $post_id,$stdate,$enddate );
						}
						if($attach_id!=''){
							set_post_thumbnail( $item->ID, $attach_id );
						}elseif(isset($_POST['_thumbnail_id']) & $_POST['_thumbnail_id']!=''){
							set_post_thumbnail( $item->ID, $_POST['_thumbnail_id'] );
						}
						update_post_meta( $item->ID, 'we_startdate', $stdate);
						update_post_meta( $item->ID, 'we_enddate', $enddate);
						update_post_meta( $item->ID, 'recurren_list', '');
						delete_post_meta( $item->ID, 'we_ctdate');
						
						delete_post_meta( $item->ID, 'we_recurrence_end');
						delete_post_meta( $item->ID, 'we_recurrence');
						delete_post_meta( $item->ID, 'we_ctdate');
						delete_post_meta( $item->ID, 'we_frequency');
						delete_post_meta( $item->ID, 'we_weekday');
						delete_post_meta( $item->ID, 'we_monthday');
						delete_post_meta( $item->ID, 'we_mweekday');
					}
					remove_action( 'save_post', array($this,'recurrence_event' ));
				}
				if($ctmcheck!=1){
					return;
				}
			}
			if ( current_user_can( 'manage_options' ) ) {
				$p_status = 'publish';
			}else{
				$p_status = 'pending';
			}
			//global $sitepress;//echo $_POST['lang'];exit;
			//echo $_POST['icl_post_language'];exit;
			//$def_trid = $sitepress->get_element_trid($post_id);//echo $def_trid;exit;
			
			for($i = 1; $i <= $date_ed; $i++){
				$attr = array(
				  'post_title'    => wp_strip_all_tags( $_POST['post_title'] ),
				  'post_content'  => $_POST['post_content'],
				  'post_status'   => $p_status,
				  'post_author'   => get_current_user_id(),
				  'post_type'      => 'product',
				  'post_excerpt' => $_POST['excerpt'],
				);
				$number_dt = $i*$number_plus;
				if($recurrence['exc_mb-field-0']=='month'){
					$st_date = strtotime("+".$i." month", strtotime($we_startdate['exc_mb-field-0']['date']));
				}else{
					$st_date = strtotime("+".$number_dt." day", strtotime($we_startdate['exc_mb-field-0']['date']));
				}

				$en_date = strtotime("+".$c_number." day", $st_date);
				
				$diff_st = strtotime($we_startdate['exc_mb-field-0']['date'] .' '. $we_startdate['exc_mb-field-0']['time'])- strtotime($we_startdate['exc_mb-field-0']['date']);
				$st_date = $st_date + $diff_st;
				
				$diff_ed = strtotime($we_enddate['exc_mb-field-0']['date'] .' '. $we_enddate['exc_mb-field-0']['time'])- strtotime($we_enddate['exc_mb-field-0']['date']);
				$en_date = $en_date + $diff_ed;
				$br_cre = strtotime($we_recurrence_end['exc_mb-field-0']) + 86399;
				if($en_date > $br_cre){
					$en_date = strtotime($we_recurrence_end['exc_mb-field-0'])+ $diff_ed;
				}
				
				if($st_date > $br_cre){
					break;
				}else{
					$arr_ids = $this->create_new_recurring($attr,$st_date,$en_date,$post_id,$attach_id);
					update_post_meta( $post_id, 'recurren_list', $arr_ids);
					if (class_exists('SitePress')) {
						wp_update_post( array('ID' => $post_id), false );
					}
				}
			}
		}else if($recurrence['exc_mb-field-0']=='custom'){
			$this->recurring_custom($_POST,$we_startdate,$we_enddate,$post_id,$ex_recurr);
		}else{
			return;
		}
	}
	function recurring_custom($data,$we_startdate,$we_enddate,$post_id,$ex_recurr){
		$we_frequency = $data['we_frequency']['exc_mb-field-0'];
		$attach_id = get_post_thumbnail_id($post_id);
		if($ex_recurr !=''){
			$ctmcheck = '';
			$ctmcheck = $this->update_recurring($data,$we_startdate,$we_enddate,$post_id,$data['we_recurrence_end'],$ex_recurr,$attach_id);
			if($ctmcheck!=1){ return;}
		}
		if ( current_user_can( 'manage_options' ) ) {
			$p_status = 'publish';
		}else{
			$p_status = 'pending';
		}
		$arr_ids = array();
		/*-- Create custom recurring date--*/
		if($we_frequency=='ct_date'){
			if(isset($data['we_ctdate']) && !empty($data['we_ctdate'])){
				foreach ($data['we_ctdate'] as $item){
					$it_st = $item['we_ct_stdate'];
					$it_e = $item['we_ct_edate_end'];
					if($it_st['exc_mb-field-0']['date']!=''){
						$st_date = strtotime($it_st['exc_mb-field-0']['date'] .' '. $it_st['exc_mb-field-0']['time']);
						if(isset($it_e['exc_mb-field-0']['date']) && $it_e['exc_mb-field-0']['date']!=''){
							$en_date = strtotime($it_e['exc_mb-field-0']['date'] .' '. $it_e['exc_mb-field-0']['time']);
						}else{
							$st_to_end = (strtotime($we_enddate['exc_mb-field-0']['date']) - strtotime($we_startdate['exc_mb-field-0']['date']));
							$c_number = $st_to_end/86400;
							$en_date = strtotime("+".$c_number." day", $st_date);
							$en_hou = strtotime($we_enddate['exc_mb-field-0']['date'] .' '. $we_enddate['exc_mb-field-0']['time'])- strtotime($we_enddate['exc_mb-field-0']['date']);
							$en_date = $en_date + $en_hou;
						}
						$all_day = $item['we_ct_allday']['exc_mb-field-0'];
						$attr = array(
						  'post_title'    => wp_strip_all_tags( $data['post_title'] ),
						  'post_content'  => $data['post_content'],
						  'post_status'   => $p_status,
						  'post_author'   => get_current_user_id(),
						  'post_type'      => 'product',
						  'post_excerpt' => $data['excerpt'],
						);
						$arr_ids[] = $this->create_new_recurring($attr,$st_date,$en_date,$post_id,$attach_id,$all_day);
					}
				}
				update_post_meta( $post_id, 'recurren_list', $arr_ids);
			}
		}else{
			$st_frst = $next_st = strtotime($we_startdate['exc_mb-field-0']['date'] .' '. $we_startdate['exc_mb-field-0']['time']);
			
			$time_ofst = strtotime($we_startdate['exc_mb-field-0']['date'] .' '. $we_startdate['exc_mb-field-0']['time']) - strtotime($we_startdate['exc_mb-field-0']['date']);
			
			$next_ed = strtotime($we_enddate['exc_mb-field-0']['date'] .' '. $we_enddate['exc_mb-field-0']['time']);
			$nb_bw = $next_ed - $next_st;
			$br_cre = strtotime($data['we_recurrence_end']['exc_mb-field-0']) + 86399;
			$every_x = $every_m = $data['we_every_x']['exc_mb-field-0'];
			if($every_x < 1){ return;}

			if($we_frequency=='week'){
				$every_x = $every_x * 7;
				$next_st = strtotime("+".$every_x." day", $next_st);
				//$next_st = strtotime($next_st);
			}else if($we_frequency=='month'){
				$next_st = strtotime("+".$every_x." month", $next_st);
			}else{
				$next_st = strtotime("+".$every_x." day", $next_st);
			}
			$attr = array(
			  'post_title'    => wp_strip_all_tags( $data['post_title'] ),
			  'post_content'  => $data['post_content'],
			  'post_status'   => $p_status,
			  'post_author'   => get_current_user_id(),
			  'post_type'      => 'product',
			  'post_excerpt' => $data['excerpt'],
			);
			$we_weekday = isset($data['we_weekday']['exc_mb-field-0']) ? $data['we_weekday']['exc_mb-field-0'] : array();
			if($we_frequency=='week' && !empty($we_weekday)){
				if(date('D', $next_st) == 'Sun'){
					$next_st = $next_st - 84600;
				}
				$next_st = strtotime('monday this week', $next_st) + $time_ofst;
				$i = 0;
				while($next_st < $br_cre){
					$i ++;
					foreach ($we_weekday as $item){
						if($i==1 && count($we_weekday) > 1){// create of same week with first event
							$st_date = strtotime($item.' this week', $st_frst) + $time_ofst;
							$en_date = $st_date + $nb_bw*1;
							if($en_date > $br_cre){$en_date = $br_cre;}
							if($st_date > $br_cre){ break;}
							if($st_date > $st_frst){
								$arr_ids[] = $this->create_new_recurring($attr,$st_date,$en_date,$post_id,$attach_id);
							}
						}
						$st_date = strtotime($item.' this week', $next_st) + $time_ofst;
						$en_date = $st_date + $nb_bw*1;
						if($en_date > $br_cre){$en_date = $br_cre;}
						if($st_date > $br_cre){ break;}
						if($st_date > $st_frst){
							$arr_ids[] = $this->create_new_recurring($attr,$st_date,$en_date,$post_id,$attach_id);
						}
					}
					$next_st = strtotime("+".$every_x." day", $st_date);
					if(date('D', $next_st) == 'Sun'){
						$next_st = $next_st - 84600;
					}
					$next_st = strtotime('monday this week', $next_st);
				}
			}else{
				if($we_frequency=='month'){
					$we_mthday = isset($data['we_monthday']['exc_mb-field-0']) ? $data['we_monthday']['exc_mb-field-0'] : '';
					if(!is_numeric($we_mthday)){
						$we_mweekday = $data['we_mweekday']['exc_mb-field-0'];
						if($we_mthday==''){ return;}
						$next_st = strtotime($we_mthday.' '.$we_mweekday.' of this month', $next_st) + $time_ofst;
					}else{
						$last_dom = strtotime('last day of this month', $next_st);
						$next_st =  strtotime(date('Y-m-'.$we_mthday,$next_st).' '. $we_startdate['exc_mb-field-0']['time']);
						if($next_st > $last_dom){
							$st_date = $next_st;
							$next_st = strtotime("+".$every_m." month", $last_dom);
							$next_st = strtotime(date('Y-m-'.$we_mthday,$next_st).' '. $we_startdate['exc_mb-field-0']['time']);
						}
					}
				}
				while($next_st < $br_cre){
					$st_date = $next_st;
					$en_date = $st_date + $nb_bw*1;
					$arr_ids[] = $this->create_new_recurring($attr,$st_date,$en_date,$post_id,$attach_id);
					if($we_frequency!='month'){
						$next_st = strtotime("+".$every_x." day", $st_date);
					}else{
						$next_st = strtotime("+".$every_m." month", $st_date);
						if(!is_numeric($we_mthday)){
							$we_mweekday = $data['we_mweekday']['exc_mb-field-0'];
							if($we_mthday==''){ return;}
							$next_st = strtotime($we_mthday.' '.$we_mweekday.' of this month', $next_st) + $time_ofst;
						}else{
							$last_dom = strtotime('last day of this month', $next_st);
							$next_st =  strtotime(date('Y-m-'.$we_mthday,$next_st).' '. $we_startdate['exc_mb-field-0']['time']);
							if($next_st > $last_dom){
								$st_date = $next_st;
								$next_st = strtotime("+".$every_m." month", $last_dom);
								$next_st = strtotime(date('Y-m-'.$we_mthday,$st_date).' '. $we_startdate['exc_mb-field-0']['time']);
							}
						}
					}					
				}
			}
			update_post_meta( $post_id, 'recurren_list', $arr_ids);
		}
	}
	function create_new_recurring($attr,$st_date,$en_date,$post_id,$attach_id,$all_day=false){
		remove_action( 'save_post', array($this,'recurrence_event' ));
		$attr['post_title'] = apply_filters( 'we_change_title_recurring', $attr['post_title'], $st_date );
		if($we_ID = wp_insert_post( $attr, false )){
			if($attach_id!=''){
				set_post_thumbnail( $we_ID, $attach_id );
			}
			// update meta
			update_post_meta( $we_ID, 'we_startdate', $st_date);
			update_post_meta( $we_ID, 'we_enddate', $en_date);
			if(isset($all_day) && $all_day!=''){
				update_post_meta( $we_ID, 'we_allday', $all_day);
			}
			update_post_meta( $we_ID, 'recurren_ext', 'event_'.$post_id);
			update_post_meta( $post_id, 'recurren_ext', 'event_'.$post_id);
			woometa_update($_POST,$we_ID, $post_id);
			update_post_meta( $we_ID, 'recurren_list', '');
			
			delete_post_meta( $we_ID, 'we_recurrence_end');
			delete_post_meta( $we_ID, 'we_recurrence');
			delete_post_meta( $we_ID, 'we_ctdate');
			delete_post_meta( $we_ID, 'we_frequency');
			delete_post_meta( $we_ID, 'we_weekday');
			delete_post_meta( $we_ID, 'we_monthday');
			delete_post_meta( $we_ID, 'we_mweekday');
		}
		//WPML support
		if (class_exists('SitePress')) {
			global $sitepress,$wpdb;
			$trid = $sitepress->get_element_trid( $post_id, 'post_product');
			$orig_id = $sitepress->get_original_element_id_by_trid( $trid );
			$orig_lang = $this->get_original_product_language( $post_id );
			//$sitepress->set_element_language_details($we_ID, 'post_product', false, $orig_lang);
			$new_trid = $sitepress->get_element_trid( $we_ID, 'post_product' );
			$set_language_args = array(
				'element_id'    => $we_ID,
				'element_type'  => 'post_product',
				'trid'   => $new_trid,
				'language_code'   => $_POST['icl_post_language'],
				'source_language_code' => $orig_lang
			);
			do_action( 'wpml_set_element_language_details', $set_language_args );
		}
		$arr_ids = $we_ID;
		add_action( 'save_post', array($this,'recurrence_event') );
		return $arr_ids;
	}
	// update 
	function update_recurring($data,$we_startdate,$we_enddate,$post_id,$recurr_end,$ex_recurr,$attach_id){
		$we_frequency = $data['we_frequency']['exc_mb-field-0'];
		$recurren_list = get_post_meta($post_id,'recurren_list', true );
		/*-- update custom date--*/
		if($we_frequency=='ct_date'){
			$j = 0;
			if(!empty($recurren_list)){
				if(isset($data['we_ctdate']) && !empty($data['we_ctdate'])){
					$attach_id = get_post_thumbnail_id($post_id);
					//echo '<pre>';print_r($data['we_ctdate']);echo '</pre>';exit;
					$_ids_ne = array();
					foreach ($data['we_ctdate'] as $item){
						//echo '<pre>';print_r($item);echo '</pre>';
						$it_st = $item['we_ct_stdate'];
						$it_e = $item['we_ct_edate_end'];
						$st_date = strtotime($it_st['exc_mb-field-0']['date'] .' '. $it_st['exc_mb-field-0']['time']);
						$e_date = strtotime($it_e['exc_mb-field-0']['date'] .' '. $it_e['exc_mb-field-0']['time']);
						$all_day = $item['we_ct_allday']['exc_mb-field-0'];
						if(  ($it_st['exc_mb-field-0']['date']!='') && $j < count($recurren_list) && is_numeric($recurren_list[$j]) && (FALSE !== get_post_status( $recurren_list[$j])) ){
							remove_action( 'save_post', array($this,'recurrence_event' ));
							
							we_update_recurren($_POST,$recurren_list[$j],$post_id,$st_date);
							if (class_exists('SitePress') && function_exists('wooevent_wpml_duplicate_product')) {
								wooevent_wpml_duplicate_product( $recurren_list[$j], $post_id,$st_date,$e_date );
							}
							if($attach_id!=''){
								set_post_thumbnail( $recurren_list[$j], $attach_id );
							}
							update_post_meta( $recurren_list[$j], 'we_startdate', $st_date);
							update_post_meta( $recurren_list[$j], 'we_enddate', $e_date);
							update_post_meta( $recurren_list[$j], 'we_allday', $all_day);
							update_post_meta( $recurren_list[$j], 'recurren_list', '');
							
							delete_post_meta( $recurren_list[$j], 'we_recurrence');
							delete_post_meta( $recurren_list[$j], 'we_recurrence_end');
							delete_post_meta( $recurren_list[$j], 'we_every_x');
							delete_post_meta( $recurren_list[$j], 'we_ctdate');
							delete_post_meta( $recurren_list[$j], 'we_frequency');
							delete_post_meta( $recurren_list[$j], 'we_weekday');
							delete_post_meta( $recurren_list[$j], 'we_monthday');
							delete_post_meta( $recurren_list[$j], 'we_mweekday');
							
							remove_action( 'save_post', array($this,'recurrence_event' ));
						}elseif( ($it_st['exc_mb-field-0']['date']!='') && ( ( FALSE === get_post_status( $recurren_list[$j] ) ) || ($j >= count($recurren_list)) ) ){
							if ( current_user_can( 'manage_options' ) ) {
								$p_status = 'publish';
							}else{
								$p_status = 'pending';
							}
							$attr = array(
							  'post_title'    => wp_strip_all_tags( $data['post_title'] ),
							  'post_content'  => $data['post_content'],
							  'post_status'   => $p_status,
							  'post_author'   => get_current_user_id(),
							  'post_type'      => 'product',
							  'post_excerpt' => $data['excerpt'],
							);
							$_ids_ne[] = $this->create_new_recurring($attr,$st_date,$e_date,$post_id,$attach_id);
						}
						$j++;
					}
					$arr_ids = array_merge($recurren_list,$_ids_ne);
					update_post_meta( $post_id, 'recurren_list', $arr_ids);
				}
				return false;
			}else{
				return true;
			}
		}else{
			//echo '<pre>';print_r($data);echo '</pre>';exit;
			$ev_stc = get_post_meta($post_id,'we_startdate', true );
			$ev_edc = get_post_meta($post_id,'we_enddate', true );
			$ev_recurrence_end = get_post_meta($post_id,'we_recurrence_end', true );
			$ev_recurrence = get_post_meta($post_id,'we_recurrence', true );
			$cr_st = strtotime($we_startdate['exc_mb-field-0']['date'] .' '. $we_startdate['exc_mb-field-0']['time']);
			$cr_ed = strtotime($we_enddate['exc_mb-field-0']['date'] .' '. $we_enddate['exc_mb-field-0']['time']);
			$cr_rec = strtotime($recurr_end['exc_mb-field-0']);
			$ctmcheck = 0;
			if($ev_stc !=$cr_st || $ev_edc!= $cr_ed || $ev_recurrence_end!= $cr_rec || $ev_recurrence!= $data['we_recurrence']['exc_mb-field-0']){
				$ctmcheck = 1;
			}elseif($ev_recurrence == $data['we_recurrence']['exc_mb-field-0']){
				$we_frequency = get_post_meta($post_id,'we_frequency', true );
				if($we_frequency == $data['we_frequency']['exc_mb-field-0']){
					if(get_post_meta($post_id,'we_every_x', true ) != $data['we_every_x']['exc_mb-field-0']){
						$ctmcheck = 1;
					}elseif($we_frequency=='week'){
						$we_weekday = get_post_meta($post_id,'we_weekday', true );
						$diff = array_diff($we_weekday,$data['we_weekday']['exc_mb-field-0']);
						if(empty($diff)){
							$diff = array_diff($data['we_weekday']['exc_mb-field-0'],$we_weekday);
						}
						if(!empty($diff)){
							$ctmcheck = 1;
						}
					}elseif($we_frequency=='month'){
						$we_monthday = get_post_meta($post_id,'we_monthday', true );
						$we_mweekday = get_post_meta($post_id,'we_mweekday', true );
						if( ($we_monthday!= $data['we_monthday']['exc_mb-field-0']) || ($we_mweekday != $data['we_mweekday']['exc_mb-field-0']) ){
							$ctmcheck = 1;
						}
					}
				}else{
					$ctmcheck = 1;
				}
			}
			if(!empty($recurren_list)){
				//print_r($recurren_list);exit;
				foreach($recurren_list as $item){
					remove_action( 'save_post', array($this,'recurrence_event' ));
					$stdate = get_post_meta($item,'we_startdate', true );
					$enddate = get_post_meta($item,'we_enddate', true );
					if($ctmcheck==1){
						wp_delete_post($item);
					}else{
						we_update_recurren($_POST,$item,$post_id,$stdate);
						if($attach_id!=''){
							set_post_thumbnail( $item, $attach_id );
						}
						if (class_exists('SitePress')) {
							wooevent_wpml_duplicate_product( $item, $post_id,$stdate,$enddate );
						}
						update_post_meta( $item, 'we_startdate', $stdate);
						update_post_meta( $item, 'we_enddate', $enddate);
						update_post_meta( $item, 'recurren_list', '');
						delete_post_meta( $item, 'we_ctdate');
					}
					remove_action( 'save_post', array($this,'recurrence_event' ));
				}
			}else{
				// support old version 
				$args = array(
					'post_type' => 'product',
					'post_status' => get_post_status ( $post_id ),
					'post__not_in' => array( $post_id ),
					'posts_per_page' => -1,
					'order' => 'ASC',
					'meta_key' => 'recurren_ext',
					'orderby' => 'meta_value_num',
					'meta_query' => array(
						array(
							'key'     => 'recurren_ext',
							'value'   => $ex_recurr,
							'compare' => '=',
						),
					),
				); 
				$ex_posts = get_posts( $args );
				//echo '<pre>';print_r($ex_posts);echo '</pre>';exit;
				foreach($ex_posts as $item){
					remove_action( 'save_post', array($this,'recurrence_event' ));
					$stdate = get_post_meta($item->ID,'we_startdate', true );
					$enddate = get_post_meta($item->ID,'we_enddate', true );
					if($ctmcheck==1){
						wp_delete_post($item->ID);
					}else{
						we_update_recurren($_POST,$item->ID,$post_id,$stdate);
						if($attach_id!=''){
							set_post_thumbnail( $item->ID, $attach_id );
						}
						if (class_exists('SitePress') && function_exists('wooevent_wpml_duplicate_product')) {
							wooevent_wpml_duplicate_product( $item->ID, $post_id,$stdate,$enddate );
						}
						update_post_meta( $item->ID, 'we_startdate', $stdate);
						update_post_meta( $item->ID, 'we_enddate', $enddate);
						update_post_meta( $item->ID, 'recurren_list', '');
						delete_post_meta( $item->ID, 'we_ctdate');
					}
					remove_action( 'save_post', array($this,'recurrence_event' ));
				}
			}
			return $ctmcheck;
		}
	}
	// Get original product language
    function get_original_product_language( $product_id ){

        $cache_key = $product_id;
        $cache_group = 'original_product_language';

        $temp_language = wp_cache_get( $cache_key, $cache_group );
        if($temp_language) return $temp_language;

        global $wpdb;

        $language = $wpdb->get_var( $wpdb->prepare( "
                            SELECT t2.language_code FROM {$wpdb->prefix}icl_translations as t1
                            LEFT JOIN {$wpdb->prefix}icl_translations as t2 ON t1.trid = t2.trid
                            WHERE t1.element_id=%d AND t1.element_type=%s AND t2.source_language_code IS NULL", $product_id, 'post_'.get_post_type($product_id) ) );

        wp_cache_set( $cache_key, $language, $cache_group );

        return $language;
    }
	function wooevent_metadata(array $meta_boxes){
		$arr_dat = array();
		$arr_dat['first']= esc_html__('First', 'exthemes');
		$arr_dat['second']= esc_html__('Second', 'exthemes');
		$arr_dat['third']= esc_html__('Third', 'exthemes');
		$arr_dat['fourth']= esc_html__('Fourth', 'exthemes');
		$arr_dat['fifth']= esc_html__('Fifth', 'exthemes');
		$arr_dat['last']= esc_html__('Last', 'exthemes');
		for($i = 1; $i < 32; $i++){
			$arr_dat[$i] = $i;
		}
		$time_settings = array(	
			array( 'id' => 'we_allday',  'name' => esc_html__('All Day', 'exthemes'), 'cols' => 12, 'type' => 'checkbox' ),
			array( 'id' => 'we_startdate', 'name' => esc_html__('Start Date:', 'exthemes'), 'cols' => 4, 'type' => 'datetime_unix','desc' => esc_html__('', 'exthemes') , 'repeatable' => false, 'multiple' => false ),
			array( 'id' => 'we_enddate', 'name' => esc_html__('End Date:', 'exthemes'), 'cols' => 4, 'type' => 'datetime_unix' ,'desc' => esc_html__('', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			array( 'id' => 'we_time_zone', 'name' => esc_html__('Timezone', 'exthemes'), 'type' => 'select', 
				'options' => array( 
					'def' => esc_html__('Default', 'exthemes'), 
					'-12' => esc_html__('UTC-12', 'exthemes'), 
					'-11.5' => esc_html__('UTC-11:30', 'exthemes'),
					'-11' => esc_html__('UTC-11', 'exthemes'),
					'-10.5' => esc_html__('UTC-10:30', 'exthemes'),
					'-10' => esc_html__('UTC-10', 'exthemes'),
					'-9.5' => esc_html__('UTC-9:30', 'exthemes'),
					'-9' => esc_html__('UTC-9', 'exthemes'),
					'-8.5' => esc_html__('UTC-8:30', 'exthemes'),
					'-8' => esc_html__('UTC-8', 'exthemes'),
					'-7.5' => esc_html__('UTC-7:30', 'exthemes'),
					'-7' => esc_html__('UTC-7', 'exthemes'),
					'-6.5' => esc_html__('UTC-6:30', 'exthemes'),
					'-6' => esc_html__('UTC-6', 'exthemes'),
					'-5.5' => esc_html__('UTC-5:30', 'exthemes'),
					'-5' => esc_html__('UTC-5', 'exthemes'),
					'-4.5' => esc_html__('UTC-4:30', 'exthemes'),
					'-4' => esc_html__('UTC-4', 'exthemes'),
					'-3.5' => esc_html__('UTC-3:30', 'exthemes'),
					'-3' => esc_html__('UTC-3', 'exthemes'),
					'-2.5' => esc_html__('UTC-2:30', 'exthemes'),
					'-2' => esc_html__('UTC-2', 'exthemes'),
					'-1.5' => esc_html__('UTC-1:30', 'exthemes'),
					'-1' => esc_html__('UTC-1', 'exthemes'),
					'-0.5' => esc_html__('UTC-0:30', 'exthemes'),
					'+0' => esc_html__('UTC+0', 'exthemes'),
					'0.5' => esc_html__('UTC+0:30', 'exthemes'),
					'1' => esc_html__('UTC+1', 'exthemes'),
					'1.5' => esc_html__('UTC+1:30', 'exthemes'),
					'2' => esc_html__('UTC+2', 'exthemes'),
					'2.5' => esc_html__('UTC+2:30', 'exthemes'),
					'3' => esc_html__('UTC+3', 'exthemes'),
					'3.5' => esc_html__('UTC+3:30', 'exthemes'),
					'4' => esc_html__('UTC+4', 'exthemes'),
					'4.5' => esc_html__('UTC+4:30', 'exthemes'),
					'5' => esc_html__('UTC+5', 'exthemes'),
					'5.30' => esc_html__('UTC+5:30', 'exthemes'),
					'5.45' => esc_html__('UTC+5:45', 'exthemes'),
					'6' => esc_html__('UTC+6', 'exthemes'),
					'6.5' => esc_html__('UTC+6:30', 'exthemes'),
					'7' => esc_html__('UTC+7', 'exthemes'),
					'7.5' => esc_html__('UTC+7:30', 'exthemes'),
					'8' => esc_html__('UTC+8', 'exthemes'),
					'8.30' => esc_html__('UTC+8:30', 'exthemes'),
					'8.45' => esc_html__('UTC+8:45', 'exthemes'),
					'9' => esc_html__('UTC+9', 'exthemes'),
					'9.5' => esc_html__('UTC+9:30', 'exthemes'),
					'10' => esc_html__('UTC+10', 'exthemes'),
					'10.30' => esc_html__('UTC+10:30', 'exthemes'),
					'11' => esc_html__('UTC+11', 'exthemes'),
					'11.5' => esc_html__('UTC+11:30', 'exthemes'),
					'12' => esc_html__('UTC+12', 'exthemes'),
					'12.45' => esc_html__('UTC+12:45', 'exthemes'),
					'13' => esc_html__('UTC+13', 'exthemes'),
					'13.45' => esc_html__('UTC+13:45', 'exthemes'),
					'14' => esc_html__('UTC+14', 'exthemes'),
				),
				'cols' => 4,
				'desc' => '' , 
				'repeatable' => false,
				'multiple' => false
			),
			array( 'id' => 'we_recurrence', 'name' => esc_html__('Recurrence', 'exthemes'), 'cols' => 4, 'type' => 'select', 'options' => array( 'day' => esc_html__('Every Day', 'exthemes'),  'week' => esc_html__('Every Week', 'exthemes'),  'month' => esc_html__('Every Month', 'exthemes'), 'custom' => esc_html__('Custom', 'exthemes') ), 'allow_none' => true, 'sortable' => false, 'repeatable' => false ),
			
			array( 'id' => 'we_recurrence_end', 'name' => esc_html__('End Date of Recurrence:', 'exthemes'), 'cols' => 8, 'type' => 'date_unix' ,'desc' => esc_html__('', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			
			array( 'id' => 'we_frequency', 'name' => esc_html__('Frequency', 'exthemes'), 'cols' => 2, 'type' => 'select', 'options' => array( 'daily' => esc_html__('Daily', 'exthemes'),  'week' => esc_html__('Weekly', 'exthemes'),  'month' => esc_html__('Monthy', 'exthemes'), 'ct_date' => esc_html__('Custom date', 'exthemes')), 'allow_none' => false, 'sortable' => false, 'repeatable' => false ),
			array( 'id' => 'we_every_x', 'name' => esc_html__('Every X', 'exthemes'), 'cols' => 2, 'type' => 'number','desc' => '' ,'default' => 1, 'repeatable' => false, 'multiple' => false ),
			array( 
				'id' => 'we_weekday', 
				'name' => esc_html__('On day:', 'exthemes'), 
				'type' => 'select', 'options' => array( 
					'monday' => esc_html__('Monday', 'exthemes'), 
					'tuesday' => esc_html__('Tuesday', 'exthemes'), 
					'wednesday' => esc_html__('Wednesday', 'exthemes'), 
					'thursday' => esc_html__('Thursday', 'exthemes'), 
					'friday' => esc_html__('Friday', 'exthemes'), 
					'saturday' => esc_html__('Saturday', 'exthemes'), 
					'sunday' => esc_html__('Sunday', 'exthemes') 
				),
				'cols' => 4,
				'desc' => '',
				'multiple' => true 
			),
			
			array( 
				'id' => 'we_monthday', 
				'name' => esc_html__('Month On:', 'exthemes'), 
				'type' => 'select', 'options' => $arr_dat,
				'cols' => 2,
				'desc' => '',
				'multiple' => false 
			),
			array( 
				'id' => 'we_mweekday', 
				'name' => esc_html__('Day:', 'exthemes'), 
				'type' => 'select', 'options' => array( 
					'mon' => esc_html__('Monday', 'exthemes'), 
					'tue' => esc_html__('Tuesday', 'exthemes'), 
					'wed' => esc_html__('Wednesday', 'exthemes'), 
					'thu' => esc_html__('Thursday', 'exthemes'), 
					'fri' => esc_html__('Friday', 'exthemes'), 
					'sat' => esc_html__('Saturday', 'exthemes'), 
					'sun' => esc_html__('Sunday', 'exthemes'),
					'day' => esc_html__('Day', 'exthemes')
				),
				'cols' => 2,
				'desc' => '',
				'multiple' => false 
			),
			
			array( 'id' => 'we_ctdate', 'name' => esc_html__('Custom Date:', 'exthemes'), 'type' => 'group', 'cols' => 12, 'fields' => array(
				array( 'id' => 'we_ct_allday',  'name' => esc_html__('All Day', 'exthemes'), 'cols' => 2, 'type' => 'checkbox' ),
				array( 'id' => 'we_ct_stdate', 'name' => esc_html__('Start Date:', 'exthemes'), 'cols' => 5, 'type' => 'datetime_unix','desc' => '' , 'repeatable' => false, 'multiple' => false ),
				array( 'id' => 'we_ct_edate_end', 'name' => esc_html__('End Date:', 'exthemes'), 'cols' => 5, 'type' => 'datetime_unix','desc' => '' , 'repeatable' => false, 'multiple' => false ),
			), 'repeatable' => true, 'multiple' => false, 'sortable' => true ),
			
			
			array( 'id' => 'we_speakers', 'name' => esc_html__('Speakers', 'exthemes'),'type' => 'post_select', 'use_ajax' => true, 'query' => array( 'post_type' => 'ex-speaker' ),'allow_none' => true, 'desc' => esc_html__('Choose speaker for this event', 'exthemes'), 'repeatable' => false, 'multiple' => true ),
			array( 'id' => 'we_stop_booking', 'name' => esc_html__('Stop booking before event start', 'exthemes'), 'type' => 'text', 'desc' => esc_html__('Enter number', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			array( 'id' => 'we_sun_offset', 'name' => esc_html__('DST Offset for Sunrise/sunset', 'exthemes'), 'type' => 'text', 'desc' => '', 'repeatable' => false, 'multiple' => false ),	
		);
		//echo '<pre>'; print_r($time_settings);exit;
		$time_settings = apply_filters( 'we_meta_setting_field', $time_settings );
		if(get_option('we_speaker')=='yes'){
			unset($time_settings[12]);
		}
		if(get_option('we_sunsire_set')!='yes'){
			unset($time_settings[14]);
		}
		$location_settings = array(		
			array( 'id' => 'we_default_venue', 'name' => esc_html__('Select venue saved', 'exthemes'),'type' => 'post_select', 'use_ajax' => true, 'query' => array( 'post_type' => 'we_venue' ),'allow_none' => true, 'desc' => esc_html__('Leave blank to use new venue', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			
			array( 'id' => 'we_adress', 'name' => esc_html__('Address', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Location Address of event', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			array( 'id' => 'we_latitude_longitude', 'name' => esc_html__('Latitude and Longitude (optional)', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Physical address of your event location, if Event map shortcode cannot load your address, you need to fill Latitude and Longitude to fix it, you can find phisical address here: https://ctrlq.org/maps/address/. Enter Latitude and Longitude, separated by a comma. Ex for London: 42.9869502,-81.243177', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			
			array( 'id' => 'we_phone', 'name' => esc_html__('Phone', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Contact Number of event', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			array( 'id' => 'we_email', 'name' => esc_html__('Email', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Email Contact of event', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			array( 'id' => 'we_website', 'name' => esc_html__('Website', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Website URL of event', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			//array( 'id' => 'we_subscribe_url', 'name' => esc_html__('Subscribe url', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Link to a subscribe form. Only work if no price is set.', 'exthemes'), 'repeatable' => false, 'multiple' => false ),
			array( 'id' => 'we_schedu', 'name' => esc_html__('Schedule', 'exthemes'), 'type' => 'text' ,'desc' => esc_html__('Add Schedule for this event', 'exthemes'), 'repeatable' => true, 'multiple' => true ),
			array( 'id' => 'we_iconmap', 'name' => esc_html__('Map Icon', 'exthemes'), 'type' => 'image', 'repeatable' => false, 'show_size' => false ),
			array( 'id' => 'we_eventcolor', 'name' => esc_html__('Color', 'exthemes'), 'type' => 'colorpicker', 'repeatable' => false, 'multiple' => true ),
			
		);
		if(get_option('we_venue_off')=='yes'){
			unset($location_settings[0]);
		}
		$event_layout = array(	
			array( 'id' => 'we_layout', 'name' => esc_html__('Layout', 'exthemes'), 'type' => 'select', 'options' => array( '' => esc_html__('Default', 'exthemes'), 'layout-1' => esc_html__('Layout 1', 'exthemes'), 'layout-2' => esc_html__('Layout 2', 'exthemes'),'layout-3' => esc_html__('Layout 3', 'exthemes')),'desc' => esc_html__('Select "Default" to use settings in Event Options', 'exthemes') , 'repeatable' => false, 'multiple' => false),
			array( 'id' => 'we_sidebar', 'name' => esc_html__('Sidebar', 'exthemes'), 'type' => 'select', 'options' => array( '' => esc_html__('Default', 'exthemes'), 'right' => esc_html__('Right', 'exthemes'), 'left' => esc_html__('Left', 'exthemes'),'hide' => esc_html__('Hidden', 'exthemes')),'desc' => esc_html__('Select "Default" to use settings in Event Options', 'exthemes') , 'repeatable' => false, 'multiple' => false),
		);
		$event_purpose = array(	
			array( 'id' => 'we_layout_purpose', 'name' => '', 'type' => 'select', 'options' => array( 'woo' => esc_html__('WooCommere', 'exthemes'), 'event' => esc_html__('Event', 'exthemes')),'desc' => esc_html__('Select Layout Purpose for this product', 'exthemes') , 'repeatable' => false, 'multiple' => false)
		);
		
		$we_main_purpose = get_option('we_main_purpose');
		if($we_main_purpose!='woo'){
			$meta_boxes[] = array(
				'title' => __('Event Settings','exthemes'),
				'pages' => 'product',
				'fields' => $time_settings,
				'priority' => 'high'
			);
			$meta_boxes[] = array(
				'title' => __('Location Settings','exthemes'),
				'pages' => 'product',
				'fields' => $location_settings,
				'priority' => 'high'
			);
		}
		if($we_main_purpose=='custom' || $we_main_purpose=='meta'){
			if($we_main_purpose=='meta'){
				$event_purpose = array(	
					array( 'id' => 'we_layout_purpose', 'name' => '', 'type' => 'select', 'options' => array( 'def' => esc_html__('Default', 'exthemes'), 'woo' => esc_html__('WooCommere', 'exthemes'), 'event' => esc_html__('Event', 'exthemes')),'desc' => esc_html__('Select Default to use setting in plugin setting', 'exthemes') , 'repeatable' => false, 'multiple' => false)
				);
			}
			$meta_boxes[] = array(
				'title' => __('Layout Purpose','exthemes'),
				'context' => 'side',
				'pages' => 'product',
				'fields' => $event_purpose,
				'priority' => 'high'
			);
		}
		$event_layout = apply_filters( 'we_change_layout_meta', $event_layout );
		$meta_boxes[] = array(
			'title' => __('Layout Settings','exthemes'),
			'pages' => 'product',
			'fields' => $event_layout,
			'priority' => 'high'
		);
		$group_fields = array(
			array( 'id' => 'we_custom_title',  'name' => esc_html__('Title', 'exthemes'), 'type' => 'text' ),
			array( 'id' => 'we_custom_content', 'name' => esc_html__('Content', 'exthemes'), 'type' => 'text', 'desc' => '', 'repeatable' => false),
		);
		foreach ( $group_fields as &$field ) {
			$field['id'] = str_replace( 'field', 'gfield', $field['id'] );
		}
	
		$meta_boxes[] = array(
			'title' => esc_html__('Custom Field', 'exthemes'),
			'pages' => 'product',
			'fields' => array(
				array(
					'id' => 'we_custom_metadata',
					'name' => esc_html__('Custom Metadata', 'exthemes'),
					'type' => 'group',
					'repeatable' => true,
					'sortable' => true,
					'fields' => $group_fields,
					'desc' => esc_html__('Custom metadata for this post', 'exthemes')
				)
			),
			'priority' => 'high'
		);
		
		$group_sponsors = array(
			array( 'id' => 'we_sponsors_link',  'name' => esc_html__('Link', 'exthemes'), 'type' => 'text' ),
			array( 'id' => 'we_sponsors_logo', 'name' => esc_html__('Logo', 'exthemes'), 'type' => 'image', 'desc' => '', 'repeatable' => false, 'show_size' => false),
		);
		foreach ( $group_fields as &$field ) {
			$field['id'] = str_replace( 'field', 'gfield', $field['id'] );
		}
	
		$meta_boxes[] = array(
			'title' => esc_html__('Sponsors of Event', 'exthemes'),
			'pages' => 'product',
			'fields' => array(
				array(
					'id' => 'we_sponsors',
					'name' => esc_html__('Sponsor', 'exthemes'),
					'type' => 'group',
					'repeatable' => true,
					'sortable' => true,
					'fields' => $group_sponsors,
					'desc' => esc_html__('Add Sponsor for this event', 'exthemes')
				)
			),
			'priority' => 'high'
		);
		return $meta_boxes;
	}
	function meta_date_picker(){
		wp_enqueue_script( 'jquery-ui-timepicker-addon', trailingslashit( WOO_EVENT_PATH ) . 'js/time-picker/jquery-ui-timepicker-addon.js', array( 'jquery') );
		wp_enqueue_style( 'jquery-ui-timepicker-addon-css', trailingslashit( WOO_EVENT_PATH ) . 'js/time-picker/jquery-ui-timepicker-addon.css');
	}
    function woo_event_meta_tab(){
        echo '<li class="wooevent_options_tab"><a href="#wooevent_options">'.esc_html__('Event Settings','exthemes').'</a></li>';
    }
}
$WooEvent_Meta = new WooEvent_Meta();

if( get_option('we_cat_ctcolor') == 'on' ){
	/* Category color */
	add_action( 'product_cat_add_form_fields', 'we_color_fields', 10 );
	add_action ( 'product_cat_edit_form_fields', 'we_color_fields');
	
	function we_color_fields( $tag ) {
		$t_id 					= isset($tag->term_id) ? $tag->term_id : '';
		$we_category_color 			= get_option( "we_category_color_$t_id")?get_option( "we_category_color_$t_id"):'';
		?>
		<tr class="form-field" style="">
			<th scope="row" valign="top">
				<label for="we-category-color"><?php esc_html_e('Color','exthemes'); ?></label>
			</th>
			<td>
				<input type="text" name="we-category-color" id="we-category-color" class="jscolor {required:false}" style="margin-bottom:15px;" value="<?php echo esc_attr($we_category_color) ?>" />
			</td>
		</tr>
		<?php
	}
	//save color fields
	add_action ( 'edited_product_cat', 'we_save_extra_color_fileds', 10, 2);
	add_action( 'created_product_cat', 'we_save_extra_color_fileds', 10, 2 );
	function we_save_extra_color_fileds( $term_id ) {
		if ( isset( $_POST[sanitize_key('we-category-color')] ) ) {
			$we_category_color = $_POST['we-category-color'];
			update_option( "we_category_color_$term_id", $we_category_color );
		}
	}
}
if( get_option('we_enable_subtitle') == 'yes' ){
	function we_sub_title_metabox() {
	
		global $post; ## global post object
		if($post->post_type == 'product'){
			wp_nonce_field( plugin_basename( __FILE__ ), 'we_sub_title_nonce' ); ## Create nonce
			$we_subtitle = get_post_meta($post->ID, 'we_subtitle', true); ## Get the subtitle?>
			<p>
				<input type="text" name="we_subtitle" placeholder="<?php esc_html_e('Sub Title','exthemes');?>" id="sub_title" class="widefat" value="<?php if(isset($we_subtitle)) { echo $we_subtitle; } ?>" />
			</p>
			<?php
		}
	}
	add_action( 'edit_form_after_title', 'we_sub_title_metabox' );
	function we_save_sub_title($post_id, $post) {
		global $post;
	
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
			return false; ## Block if doing autosave
	
		if ( isset($post->ID) && !current_user_can( 'edit_post', $post->ID )) {
			return $post->ID; ## Block if user doesn't have priv
		}
	
		if (isset($_POST['we_sub_title_nonce']) && !wp_verify_nonce( $_POST['we_sub_title_nonce'], plugin_basename(__FILE__) )) {
	
	
		} else {
			if(isset($_POST['we_subtitle'])) {
				update_post_meta($post->ID, 'we_subtitle', $_POST['we_subtitle']);
			} else if(isset($post->ID)){
				update_post_meta($post->ID, 'we_subtitle', '');
			}
		}
	
		return false;
	
	}
	add_action('save_post', 'we_save_sub_title', 1, 2);
	
}
