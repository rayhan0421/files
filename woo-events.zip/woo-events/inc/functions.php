<?php
if(!function_exists('we_startsWith')){
	function we_startsWith($haystack, $needle)
	{
		return !strncmp($haystack, $needle, strlen($needle));
	}
} 
if(!function_exists('we_get_google_fonts_url')){
	function we_get_google_fonts_url ($font_names) {
	
		$font_url = '';
	
		$font_url = add_query_arg( 'family', urlencode(implode('|', $font_names)) , "//fonts.googleapis.com/css" );
		return $font_url;
	} 
}
if(!function_exists('we_get_google_font_name')){
	function we_get_google_font_name($family_name){
		$name = $family_name;
		if(we_startsWith($family_name, 'http')){
			// $family_name is a full link, so first, we need to cut off the link
			$idx = strpos($name,'=');
			if($idx > -1){
				$name = substr($name, $idx);
			}
		}
		$idx = strpos($name,':');
		if($idx > -1){
			$name = substr($name, 0, $idx);
			$name = str_replace('+',' ', $name);
		}
		return $name;
	}
}


function we_filter_wc_get_template_single($template, $slug, $name){
	if($slug=='content' && $name =='single-product'){
		return wooevent_template_plugin('single-product');
	}else{ 
		return $template;
	}
}
function filter_wc_get_template_shop($template, $slug, $name){
	if($slug=='content' && $name =='product'){
		return wooevent_template_plugin('product');
	}else{ 
		return $template;
	}
}
function we_filter_wc_get_template_related($located, $template_name, $args){
	if($template_name =='single-product/related.php'){
		if (locate_template('woo-events/related.php') != '') {
			return get_template_part('woo-events/related');
		} else {
			return we_get_plugin_url().'templates/related.php';
		}
	}else{ 
		return $located;
	}
}

function we_filter_wc_get_template_no_result($located, $template_name, $args){
	if(($template_name =='loop/no-products-found.php')){
		$shop_view = get_option('we_shop_view');
		if(is_tax() || ($shop_view=='list' && !isset($_GET['view'])) || (isset($_GET['view']) && $_GET['view']=='list' ) ){
			if (locate_template('woo-events/no-products-found.php') != '') {
				return get_template_part('woo-events/no-products-found');
			} else {
				return we_get_plugin_url().'templates/no-products-found.php';
			}
		}else{
			return $located;
		}
	}else{ 
		return $located;
	}
}

$we_main_purpose = get_option('we_main_purpose');
if($we_main_purpose!='meta'){
	add_filter( 'wc_get_template_part', 'we_filter_wc_get_template_single', 10, 3 );
	add_filter( 'wc_get_template_part', 'filter_wc_get_template_shop', 99, 3 );
	//if($we_main_purpose=='custom'){
		add_filter( 'wc_get_template', 'we_filter_wc_get_template_related', 99, 3 );
		add_filter( 'wc_get_template', 'we_filter_wc_get_template_no_result', 99, 3 );
	//}

}
// Change number or products per row to 3
if(!function_exists('wooevent_template_plugin')){
	function wooevent_template_plugin($pageName,$shortcode=false){
		if(isset($shortcode) && $shortcode== true){
			if (locate_template('woo-events/content-shortcode/content-' . $pageName . '.php') != '') {
				get_template_part('woo-events/content-shortcode/content', $pageName);
			} else {
				include we_get_plugin_url().'shortcode/content/content-' . $pageName . '.php';
			}

		}else{
			if (locate_template('woo-events/content-' . $pageName . '.php') != '') {
				get_template_part('woo-events/content', $pageName);
			} else {
				include we_get_plugin_url().'templates/content-' . $pageName . '.php';
			}
		}
	}
}
//
if(!function_exists('ex_cat_info')){
	function ex_cat_info($status,$post_type = false, $tax=false, $show_once= false, $hide_link=false){
		ob_start();
		if($status=='off'){ return;}
		if(isset($post_type) && $post_type!='post'){
			if($post_type == 'product' && class_exists('Woocommerce')){
				$tax = 'product_cat';
			}
			if(isset($tax) && $tax!=''){
				$args = array(
					'hide_empty'        => false, 
				);
				$terms = get_the_terms(get_the_ID(), $tax);
				if(!empty($terms)){
					$c_tax = count($terms);
					?>
					<span class="info-cat">
						<?php
						$i=0;
						foreach ( $terms as $term ) {
							$i++;
							if(isset($hide_link) && $hide_link ==1){
								echo $term->name;
							}else{
								echo '<a href="'.get_term_link( $term ).'" title="' . $term->name . '">'. $term->name .'</a>';
							}
							if($show_once==1){break;}
							if($i != $c_tax){ echo ', ';}
						}
						?>
                    </span>
                    <?php
				}
			}
		}else{
			$category = get_the_category();
			if(!isset($show_once) || $show_once!='1'){
				if(!empty($category)){
					?>
					<span class="info-cat">
						<i class="ion-ios-photos-outline"></i>
						<?php the_category(', '); ?>
					</span>
					<?php  
				}
			}else{
				if(!empty($category)){
					?>
					<span class="info-cat">
						<i class="ion-ios-photos-outline"></i>
						<?php
						foreach($category as $cat_item){
							if(is_array($cat_item) && isset($cat_item[0]))
								$cat_item = $cat_item[0];
								echo '
									<a href="' . esc_url(get_category_link( $cat_item->term_id )) . '" title="' . esc_html__('View all posts in ') . $cat_item->name . '">' . $cat_item->name . '</a>';
								if($show_once==1){
									break;
								}
							}
							?>
                    </span>
                    <?php
				}
			}
		}
		$output_string = ob_get_contents();
		ob_end_clean();
		return $output_string;
	}
}
// Get has purchased
function we_get_all_products_ordered_by_user() {
    $orders = we_get_all_user_orders(get_current_user_id(), 'completed');
    if(empty($orders)) {
        return false;
    }
    $order_list = '(' . join(',', $orders) . ')';//let us make a list for query
    //so, we have all the orders made by this user that were completed.
    //we need to find the products in these orders and make sure they are downloadable.
    global $wpdb;
    $query_select_order_items = "SELECT order_item_id as id FROM {$wpdb->prefix}woocommerce_order_items WHERE order_id IN {$order_list}";
    $query_select_product_ids = "SELECT meta_value as product_id FROM {$wpdb->prefix}woocommerce_order_itemmeta WHERE meta_key=%s AND order_item_id IN ($query_select_order_items)";
    $products = $wpdb->get_col($wpdb->prepare($query_select_product_ids, '_product_id'));
    return $products;
}
function we_get_all_user_orders($user_id, $status = 'completed') {
    if(!$user_id) {
        return false;
    }
    $args = array(
        'numberposts' => -1,
        'meta_key' => '_customer_user',
        'meta_value' => $user_id,
        'post_type' => 'shop_order',
        'post_status' => array( 'wc-completed' )
        
    );
    $posts = get_posts($args);
    //get the post ids as order ids
    return wp_list_pluck($posts, 'ID');
}
// Query function
if(!function_exists('woo_event_query')){
	function woo_event_query($posttype, $count, $order, $orderby, $meta_key, $cat, $tag, $ids,$page=false,$data_qr=false,$spe_day=false, $feature=false, $meta_value=false, $taxonomy=false, $terms=false ){
		if($orderby=='has_signed_up' || $orderby=='signed_upcoming'  || $orderby=='signed_past'){
			if(get_current_user_id()){
				$ids = we_get_all_products_ordered_by_user(); 
				if($ids =='' || empty($ids)){ $ids ='-1';}
			}else{
				$ids = '-1';
			}
		}elseif($orderby=='has_submited'){
			if(get_current_user_id()){
				$ids = get_user_meta(get_current_user_id(), '_my_submit', true);
				if($ids =='' || empty($ids)){ $ids ='-1';}
			}else{
				$ids = '-1';
			}
		}
		$texo = array();
		if($tag!=''){
			$tags = explode(",",$tag);
			if(is_numeric($tags[0])){$field_tag = 'term_id'; }
			else{ $field_tag = 'slug'; }
			if(count($tags)>1){
				  $texo['relation'] = 'OR';
				  foreach($tags as $iterm) {
					  $texo[] = 
						  array(
							  'taxonomy' => 'product_tag',
							  'field' => $field_tag,
							  'terms' => $iterm,
						  );
				  }
			  }else{
				  $texo = array(
					  array(
							  'taxonomy' => 'product_tag',
							  'field' => $field_tag,
							  'terms' => $tags,
						  )
				  );
			}
		}
		//cats
		if($cat!=''){
			$cats = explode(",",$cat);
			if(is_numeric($cats[0])){$field = 'term_id'; }
			else{ $field = 'slug'; }
			if(!is_array($texo)){ $texo = array();}
			$texo['relation'] = 'OR';
			if(count($cats)>1){
				  foreach($cats as $iterm) {
					  $texo[] = 
						  array(
							  'taxonomy' => 'product_cat',
							  'field' => $field,
							  'terms' => $iterm,
						  );
				  }
			  }else{
				  $texo[] = 
					  array(
							  'taxonomy' => 'product_cat',
							  'field' => $field,
							  'terms' => $cats,
				  );
			}
		}
		
		//taxonomy
		if(isset($taxonomy) && $taxonomy!='' && isset($terms) && $terms!=''){
			$terms = explode(",",$terms);
			if(is_numeric($terms[0])){$field = 'term_id'; }
			else{ $field = 'slug'; }
			if(!is_array($texo)){ $texo = array();}
			$texo['relation'] = 'OR';
			if(count($terms)>1){
				  foreach($terms as $iterm) {
					  $texo[] = 
						  array(
							  'taxonomy' => $taxonomy,
							  'field' => $field,
							  'terms' => $iterm,
						  );
				  }
			  }else{
				  $texo[] = 
					  array(
							  'taxonomy' => $taxonomy,
							  'field' => $field,
							  'terms' => $terms,
				  	);
			}
			
			
		}
		
		if($ids!='' || (is_array($ids) && !empty($ids))){ //specify IDs
			
			if(!is_array($ids)){
				$ids = explode(",", $ids);
			}
			$args = array(
				'post_type' => $posttype,
				'posts_per_page' => $count,
				'post_status' => 'publish',
				'post__in' =>  $ids,
				'order' => $order,
				'orderby' => $orderby,
				'meta_key' => $meta_key,
				'ignore_sticky_posts' => 1,
			);
			if($orderby=='has_signed_up'){
				$args['meta_query'] = array(
					array(
						'key'  => 'we_startdate',
						'value' => 0,
						'compare' => '>'
					)
				);
			}elseif($orderby=='signed_upcoming'){
				$args['orderby']= 'meta_value_num';
				$args['order']= 'ASC';
				$args['meta_key']= 'we_startdate';
				$args['meta_query'] = array(
					array(
						'key'  => 'we_startdate',
						'value' => strtotime("now"),
						'compare' => '>'
					)
				);
			}elseif($orderby=='signed_past'){
				$args['orderby']= 'meta_value_num';
				$args['order']= 'DESC';
				$args['meta_key']= 'we_enddate';
				$args['meta_query'] = array(
					array(
						'key'  => 'we_enddate',
						'value' => strtotime("now"),
						'compare' => '<'
					)
				);
			}
			if(isset($texo)){
				$args += array('tax_query' => $texo);
			}
		}elseif($ids==''){
			$args = array(
				'post_type' => $posttype,
				'posts_per_page' => $count,
				'post_status' => 'publish',
				'order' => $order,
				'orderby' => $orderby,
				'meta_key' => $meta_key,
				'ignore_sticky_posts' => 1,
			);
			if(isset($texo)){
				$args += array('tax_query' => $texo);
			}
			$cure_time =  strtotime("now");
			$gmt_offset = get_option('gmt_offset');
			if($gmt_offset!=''){
				$cure_time = $cure_time + ($gmt_offset*3600);
			}
			if($orderby=='ontoup'){
				if($order==''){$order='ASC';}
				$args += array(
					'meta_key' => 'we_startdate', 
					'meta_query' => array( 
						'relation' => 'OR',
						 array(
							'key'     => 'we_startdate',
							'value'   => $cure_time,
							'compare' => '>',
						 ),
						 array(
							'key'     => 'we_enddate',
							'value'   => $cure_time,
							'compare' => '>',
						),
					)
				);
				$args['orderby']= 'meta_value_num';
				$args['order']= $order;
			}elseif($orderby=='upcoming'){
				if($order==''){$order='ASC';}
				$args['orderby']= 'meta_value_num';
				$args['order']= $order;
				$args['meta_key']= 'we_startdate';
				/*$args['meta_value']= $cure_time;
				$args['meta_compare']= '>';*/
				$args['meta_query'] = array(
					'relation' => 'AND',
					array(
						'key'  => 'we_startdate',
						'value' => $cure_time,
						'compare' => '>'
					)
				);
			}elseif($orderby=='past'){
				if($order==''){$order='DESC';}
				$args['orderby']= 'meta_value_num';
				$args['order']= $order;
				$args['meta_key']= 'we_enddate';
				$args['meta_query'] = array(
					'relation' => 'AND',
					array(
						'key'  => 'we_enddate',
						'value' => $cure_time,
						'compare' => '<'
					)
				);
			}elseif($orderby=='day'){
				if($order==''){$order='ASC';}
				$d_start =  strtotime(date('m/d/Y'));
				$d_end = $d_start + 86400;
				$args += array(
						 'meta_key' => 'we_startdate',
						 'meta_query' => array( 
						 'relation' => 'AND',
						  array('key'  => 'we_startdate',
							   'value' => $d_start,
							   'compare' => '>'),
						  array('key'  => 'we_startdate',
							   'value' => $d_end,
							   'compare' => '<')
						 )
				);
				$args['orderby']= 'meta_value_num';
				$args['order']= $order;
			}elseif($orderby=='week'){
				/*$day = date('w');
				$week_start = date('m/d/Y', strtotime('-'.$day.' days'));
				$week_end = date('m/d/Y', strtotime('+'.(6-$day).' days'));*/
				
				if($order==''){$order='ASC';}
				$week_start =  strtotime('next Monday -1 week', strtotime('this sunday'));
				$week_end = $week_start + 604799;
				$args += array(
						 'meta_key' => 'we_startdate',
						 //'meta_value' => date('m/d/Y'),
						 'meta_query' => array( 
						 'relation' => 'AND',
						  array('key'  => 'we_startdate',
							   'value' => $week_start,
							   'compare' => '>'),
						  array('key'  => 'we_startdate',
							   'value' => $week_end,
							   'compare' => '<=')
						 )
				);
				$args['orderby']= 'meta_value_num';
				$args['order']= $order;
			}elseif($orderby=='month'){
				$month_start = date("m/1/Y") ;
				if($order==''){$order='DESC';}
				$month_end =  date("m/t/Y") ;
				$args += array(
						 'meta_key' => 'we_startdate',
						 //'meta_value' => date('m/d/Y'),
						 'meta_query' => array( 
						 'relation' => 'AND',
						  array('key'  => 'we_startdate',
							   'value' => strtotime($month_start),
							   'compare' => '>'),
						  array('key'  => 'we_startdate',
							   'value' => strtotime($month_end),
							   'compare' => '<=')
						 )
				);
				$args['orderby']= 'meta_value_num';
				$args['order']= $order;
			}elseif($orderby=='year'){
				$y_start = date("1/1/Y") ;
				$y_end =  date("12/t/Y") ;
				if($order==''){$order='DESC';}
				$args += array(
						 'meta_key' => 'we_startdate',
						 //'meta_value' => date('m/d/Y'),
						 'meta_query' => array( 
						 'relation' => 'AND',
						  array('key'  => 'we_startdate',
							   'value' => strtotime($y_start),
							   'compare' => '>'),
						  array('key'  => 'we_startdate',
							   'value' => strtotime($y_end),
							   'compare' => '<=')
						 )
				);
				$args['orderby']= 'meta_value_num';
				$args['order']= $order;
			}
		}	
		if(isset($page) && $page!=''){
			$args['paged'] = $page;
		}
		if($orderby=='has_submited'){
			$args['post_status'] = array( 'publish', 'pending', 'trash' );
		}
		if(isset($meta_value) && $meta_value!='' && $meta_key!=''){
			if(!empty($args['meta_query'])){
				$args['meta_query']['relation'] = 'AND';
			}
			$args['meta_query'][] = array(
				'key'  => $meta_key,
				'value' => $meta_value,
				'compare' => '='
			);
		}
		if(isset($feature) && $feature==1){
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'product_visibility',
					'field'    => 'name',
					'terms'    => 'featured',
				)
			);
		}
		if(isset($data_qr) && $data_qr!='' && is_numeric($data_qr)){
			$args['meta_query']['relation'] = 'AND';
			$args['meta_query'][]= 
				 array(
					'key' => 'we_speakers',
					'value' => $data_qr,
					'compare' => 'LIKE'
			);
		}
		if(get_option('woocommerce_hide_out_of_stock_items')=='yes'){
			$args['meta_query']['relation'] = 'AND';
			$args['meta_query'][] = array(
				'key'       => '_stock_status',
				'value'     => 'outofstock',
				'compare'   => 'NOT IN'
			);
		}
		return apply_filters( 'wooevent_query', $args,$orderby );
	}
}
//View search bar
if(!function_exists('wooevent_search_view_bar')){
	function wooevent_search_view_bar($ID=false){
		ob_start();
		$search_ajax = get_option('we_search_ajax')=='yes' ? 1 : '';
		$we_search_style = get_option('we_search_style');
		?>
        <div class="woo-event-toolbar">
        	<div class="row">
                <div class="<?php if(is_search()){?>col-md-12<?php }else{?> col-md-8<?php }?>">
                <?php 
					$cat_include =  get_option('we_scat_include');
					$tag_include = get_option('we_stag_include');
					$we_syear_include = get_option('we_syear_include');
					$we_loca_include = get_option('we_loca_include');
					if(isset($_GET['view']) && $_GET['view']=='map'){
					}
					echo do_shortcode('[we_search cats="'.$cat_include.'" tags="'.$tag_include.'" location="'.$we_loca_include.'" years="'.$we_syear_include.'" search_ajax="'.$search_ajax.'" result_showin=".woo-event-toolbar + .we-calendar"]');
				?>
                </div>
                <?php if(!is_search()){?>
                    <div class="col-md-4">
                        <div class="we-viewas">
                            <?php $pageURL = 'http';
                            if(isset($_SERVER["HTTPS"]) && ($_SERVER["HTTPS"] == "on")) {$pageURL .= "s";}
                            $pageURL .= "://";
                            if ($_SERVER["SERVER_PORT"] != "80") {
                            $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
                            } else {
                            $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
                            }?>
                            <span class="viewas-lb lb-sp"><?php echo get_option('we_text_viewas')!='' ? get_option('we_text_viewas') : esc_html__('View as','exthemes');?></span>
                            <div class="input-group-btn we-viewas-dropdown">
                                <button name="we-viewas" type="button" class="btn btn-default we-viewas-dropdown-button we-showdrd">
                                    <span class="button-label">
                                        <?php 
										$we_shop_view = get_option('we_shop_view');
										if(isset($_GET['view']) && $_GET['view']=='day' || !isset($_GET['view']) && $we_shop_view=='day'){
											echo get_option('we_text_day')!='' ? get_option('we_text_day') : esc_html__('Day','exthemes'); 
										}elseif(isset($_GET['view']) && $_GET['view']=='week' || !isset($_GET['view']) && $we_shop_view=='week'){
											echo get_option('we_text_week')!='' ? get_option('we_text_week') : esc_html__('Week','exthemes');
										}elseif(isset($_GET['view']) && $_GET['view']=='map' || !isset($_GET['view']) && $we_shop_view=='map'){
											echo get_option('we_text_map')!='' ? get_option('we_text_map') : esc_html__('Map','exthemes'); 
										}elseif(isset($_GET['view']) && $_GET['view']=='list' || !isset($_GET['view']) && $we_shop_view=='list'){
											echo get_option('we_text_list')!='' ? get_option('we_text_list') : esc_html__('List','exthemes');
										}elseif(isset($_GET['view']) && $_GET['view']=='month' || !isset($_GET['view']) && $we_shop_view=='month'){
											echo get_option('we_text_month')!='' ? get_option('we_text_month') : esc_html__('Month','exthemes');
										}elseif(!isset($_GET['view']) ){
											echo '<span>'.get_option('we_text_select')!='' ? get_option('we_text_select') : esc_html__('Select','exthemes').'</span>';
										}?>
                                    </span> <span class="icon-arr fa fa-angle-down"></span>
                                </button>
                                <ul class="we-dropdown-select">
                                    <?php if((!isset($_GET['view']) && $we_shop_view !='list') || (isset($_GET['view']) && $_GET['view']!='list')){?>
                                        <li><a href="<?php echo add_query_arg( array('view' => 'list'), $pageURL); ?>" data-value=""><?php echo get_option('we_text_list')!='' ? get_option('we_text_list') : esc_html__('List','exthemes'); ?></a></li>
                                    <?php }
                                    if((!isset($_GET['view']) && $we_shop_view !='map') || (isset($_GET['view']) && $_GET['view']!='map')){?>
                                        <li><a href="<?php echo add_query_arg( array('view' => 'map'), $pageURL); ?>" data-value=""><?php echo get_option('we_text_map')!='' ? get_option('we_text_map') : esc_html__('Map','exthemes'); ?></a></li>
                                    <?php }
                                    if((!isset($_GET['view']) && $we_shop_view !='month') ||  (isset($_GET['view']) && $_GET['view']!='month')){?>
                                    <li><a href="<?php echo add_query_arg( array('view' => 'month'), $pageURL); ?>" data-value=""><?php echo get_option('we_text_month')!='' ? get_option('we_text_month') : esc_html__('Month','exthemes'); ?></a></li>
                                    <?php }
                                    if((!isset($_GET['view']) && $we_shop_view !='week') || (isset($_GET['view']) && $_GET['view']!='week')){?>
                                    <li><a href="<?php echo add_query_arg( array('view' => 'week'), $pageURL); ?>" data-value=""><?php echo get_option('we_text_week')!='' ? get_option('we_text_week') : esc_html__('Week','exthemes'); ?></a></li>
                                    <?php }
                                    if((!isset($_GET['view']) && $we_shop_view !='week') || (isset($_GET['view']) && $_GET['view']!='day')){?>
                                    <li><a href="<?php echo add_query_arg( array('view' => 'day'), $pageURL); ?>" data-value=""><?php echo get_option('we_text_day')!='' ? get_option('we_text_day') : esc_html__('Day','exthemes'); ?></a></li>
                                    <?php }?>
                                </ul>
                            </div><!-- /btn-group -->
                        </div>
                    </div>
                <?php }?>
            </div>

        </div>    
    	<?php
		$output_string = ob_get_contents();
		ob_end_clean();
		return $output_string;
	}
}
// Ical button
function woo_events_ical() {
	if(isset($_GET['ical_product'])&& $_GET['ical_product']>0){
		// - start collecting output -
		$startdate = get_post_meta($_GET['ical_product'],'we_startdate', true );
		if($startdate==''){ return;}
		ob_start();
		
		// - file header -
		header('Content-type: text/calendar');
		header('Content-Disposition: attachment; filename="'.esc_attr(get_the_title($_GET['ical_product'])).' - ical.ics"');
		$content = "BEGIN:VCALENDAR\r\n";
		$content .= "VERSION:2.0\r\n";
		$content .= 'PRODID:-//'.get_bloginfo('name')."\r\n";
		$content .= "CALSCALE:GREGORIAN\r\n";
		$content .= "METHOD:PUBLISH\r\n";
		$content .= 'X-WR-CALNAME:'.get_bloginfo('name')."\r\n";// Remove this code to disable create new calendar outlook
		$content .= 'X-ORIGINAL-URL:'.get_permalink($_GET['ical_product'])."\r\n";
		$content .= 'X-WR-CALDESC:'.esc_attr(get_the_title($_GET['ical_product']))."\r\n";
		
		$content .= we_ical_event_generate($_GET['ical_product']);
		$content .= "END:VCALENDAR\r\n";
		// - full output -
		$tfeventsical = ob_get_contents();
		ob_end_clean();
		$content = apply_filters( 'we_ical_html', $content, $_GET);
		echo $content;
		exit;
		}
}
add_action('init','woo_events_ical');
if(!function_exists('we_ical_event_generate')){
	function we_ical_event_generate($id){
		$startdate = get_post_meta($id,'we_startdate', true );
		if($startdate==''){ return;}		
		$date_format = get_option('date_format');
		$hour_format = get_option('time_format');
		if($startdate){
			$startdate = gmdate("Ymd\THis", $startdate);// convert date ux
		}
		$enddate = get_post_meta($id,'we_enddate', true );
		if($enddate){
			$enddate = gmdate("Ymd\THis", $enddate);
		}
		
		$gmts = get_gmt_from_date($startdate); // this function requires Y-m-d H:i:s, hence the back & forth.
		$gmts = strtotime($gmts);
		
		// - grab gmt for end -
		//$gmte = date('Y-m-d H:i:s', $conv_enddate);
		$gmte = get_gmt_from_date($enddate); // this function requires Y-m-d H:i:s, hence the back & forth.
		$gmte = strtotime($gmte);
		
		// - Set to UTC ICAL FORMAT -
		$stime = date('Ymd\THis', $gmts);
		$etime = date('Ymd\THis', $gmte);
		
		// - item output -
		$content .= "BEGIN:VEVENT\r\n";
		$content .= 'DTSTART:'.$startdate."\r\n";
		$content .= 'DTEND:'.$enddate."\r\n";
		$content .= 'SUMMARY:'.esc_attr(get_the_title($id))."\r\n";
		$content .= 'DESCRIPTION:'.get_post($id)->post_excerpt."\r\n";
		$content .= 'URL:'.get_permalink($id)."\r\n";
        $content .= 'LOCATION:'.get_post_meta($id, 'we_adress', true )."\r\n";
		$content .= "END:VEVENT\r\n";
		// - full output -
		
		return $content;
	}
}
// Ical in calendar
function we_ical_events() {
	if(isset($_GET['ical_events'])&& $_GET['ical_events']=='we'){
		// - start collecting output -
		$time_now =  strtotime("now");
		$gmt_offset = get_option('gmt_offset');
		if($gmt_offset!=''){
			$time_now = $time_now + ($gmt_offset*3600);
		}
		$args = array(
			  'post_type' => 'product',
			  'posts_per_page' => -1,
			  'post_status' => 'publish',
			  'ignore_sticky_posts' => 1,
			  'meta_key' => 'we_startdate',
			  'orderby' => 'meta_value_num',
			  'meta_query' => array(
			  array('key'  => 'we_startdate',
				   'value' => $time_now,
				   'compare' => '>'),
			  ),
			  'suppress_filters' => false 
		);
		//cats
		$cat ='';
		if(isset($_GET['category']) && $_GET['category']!=''){
			$cat = $_GET['category'];
		}
		$taxonomy =  isset($_GET['taxonomy']) ? $_GET['taxonomy'] :'';
		$terms =  isset($_GET['terms']) ? $_GET['terms'] :'';
		$speaker_id =  isset($_GET['speaker']) ? $_GET['speaker'] :'';
		$texo = array();
		if($cat!=''){
			$cats = explode(",",$cat);
			if(is_numeric($cats[0])){$field = 'term_id'; }
			else{ $field = 'slug'; }
			$texo['relation'] = 'OR';
			if(count($cats)>1){
				  foreach($cats as $iterm) {
					  $texo[] = array(
						  'taxonomy' => 'product_cat',
						  'field' => $field,
						  'terms' => $iterm,
					  );
				  }
			  }else{
				  $texo []= array(
					  'taxonomy' => 'product_cat',
					  'field' => $field,
					  'terms' => $cats,
				  );
			}
		}
		if(isset($taxonomy) && $taxonomy!='' && isset($terms) && $terms!=''){
			$terms = explode(",",$terms);
			if(is_numeric($terms[0])){$field = 'term_id'; }
			else{ $field = 'slug'; }
			$texo []= array('relation' => 'OR',);
			if(count($terms)>1){
				  foreach($terms as $iterm) {
					  $texo[] =  array(
						  'taxonomy' => $taxonomy,
						  'field' => $field,
						  'terms' => $iterm,
					  );
				  }
			  }else{
				  $texo[] =  array(
					  'taxonomy' => $taxonomy,
					  'field' => $field,
					  'terms' => $terms,
				  );
			}
		}
		if(isset($speaker_id) && $speaker_id!='' && is_numeric($speaker_id)){
			$args['meta_query']['relation'] = 'AND';
			$args['meta_query'][]=  array(
					'key' => 'we_speakers',
					'value' => $speaker_id,
					'compare' => 'LIKE'
			);
		}
		if(isset($texo)){
			$args += array('tax_query' => $texo);
		}
		$the_query = get_posts( $args );
		if(!empty($the_query)){
			// - file header -
			header('Content-type: text/calendar');
			header('Content-Disposition: attachment; filename="'.esc_attr(get_bloginfo('name')).' - ical.ics"');
			// - content header -
			$content = "BEGIN:VCALENDAR\r\n";
			$content .= "VERSION:2.0\r\n";
			$content .= 'PRODID:-//'.get_bloginfo('name')."\r\n";
			$content .= "CALSCALE:GREGORIAN\r\n";
			$content .= "METHOD:PUBLISH\r\n";
			$content .= apply_filters( 'we_ical_cal_name', 'X-WR-CALNAME:'.get_bloginfo('name')."\r\n");// Remove this code to disable create new calendar outlook
			$content .= 'X-ORIGINAL-URL:'.home_url()."\r\n";
			$content .= 'X-WR-CALDESC:'.esc_attr(get_the_title($id))."\r\n";
			foreach ( $the_query as $post ){
				$content .= we_ical_event_generate($post->ID);
			}
			$content .= "END:VCALENDAR\r\n";
			echo $content;
		}
		exit;
	}
}
add_action('init','we_ical_events');

//Status
if(!function_exists('woo_event_status')){
	function woo_event_status( $post_id, $we_enddate=false){
		if(!$we_enddate){$we_enddate = get_post_meta( $post_id, 'we_enddate', true ) ;}
		global $product; 
		$we_main_purpose = we_global_main_purpose();
		$stock_status = get_post_meta($post_id, '_stock_status',true);
		$numleft  = $product->get_stock_quantity();
		$type = $product->get_type();
		if($type=='variable' && $numleft < 1){
			$numleft  = 0;
			$all_st = 'out';
			foreach ($product->get_available_variations() as $key_status) {
				//echo get_post_meta( $key_status['variation_id'], '_stock_status', true );
				if(get_post_meta( $key_status['variation_id'], '_stock_status', true ) !='outofstock'){
					$all_st = 'in';
				}
			}
			if($all_st == 'out'){ $stock_status ='outofstock';}
			foreach ($product->get_available_variations() as $key) {
				if(!isset($key['max_qty']) || $key['max_qty']==''){
					$numleft=0;
					break;
				}else{
					$numleft  = $numleft + $key['max_qty'];
				}
			}
		}
		if($stock_status !='outofstock') { 
			  $now =  strtotime("now");
			  
			  $we_time_zone = get_post_meta($post_id,'we_time_zone',true);
			  if($we_time_zone!='' && $we_time_zone!='def'){
				  $we_time_zone = $we_time_zone * 60 * 60;
				  $now = $we_time_zone + $now;
			  }
			  
			  if($now > $we_enddate && $we_enddate!=''){
				  $stt =  get_option('we_text_event_pass')!='' ? get_option('we_text_event_pass') : esc_html__('This event has passed','exthemes');
			  }else{
				  if($numleft==0){
					  $stt = get_option('we_text_unl_tic')!='' ? get_option('we_text_unl_tic') : esc_html__('Unlimited tickets','exthemes');
					  if($we_main_purpose=='woo'){
						  $stt = get_option('we_text_unl_pie')!='' ? get_option('we_text_unl_pie') : esc_html__('Unlimited pieces','exthemes');
					  }
				  }else{
					  $qtyavtrsl = get_option('we_text_qty_av')!='' ? get_option('we_text_qty_av') :  esc_html__(' Qty Available','exthemes');
					  $stt = $numleft.'  '.$qtyavtrsl;
					  if($we_main_purpose=='woo'){
						  $pietrsl = get_option('we_text_pie_av')!='' ? get_option('we_text_pie_av') :  esc_html__(' Pieces Available','exthemes');
						  $stt = $numleft.'  '.$pietrsl;
					  }
				  }
			  }
		  }else{ 
			  $stt = get_option('we_text_no_tk')!='' ? get_option('we_text_no_tk') : esc_html__('There are no ticket available at this time.','exthemes'); 
			  if($we_main_purpose=='woo'){
				  $stt = get_option('we_text_no_pie')!='' ? get_option('we_text_no_pie') : esc_html__('There are no pieces available at this time.','exthemes'); 
			  }
		  }
		  $stt = apply_filters( 'we_ticket_status', $stt );
		  return $stt;
	}
}
//Calendar event ajax
if(!function_exists('we_get_product_type_fix')){
	function we_get_product_type_fix( $product_id ) {
		$post_type = get_post_type( $product_id );
		if ( 'product_variation' === $post_type ) {
			return 'variation';
		} elseif ( 'product' === $post_type ) {
			$terms = get_the_terms( $product_id, 'product_type' );
			return ! empty( $terms ) ? sanitize_title( current( $terms )->name ) : 'simple';
		} else {
			return false;
		}
	}
}

add_action( 'wp_ajax_we_get_events_calendar', 'we_get_events_calendar',99 );
add_action( 'wp_ajax_nopriv_we_get_events_calendar', 'we_get_events_calendar',99 );
function we_get_events_calendar() {	
	$curl = $_GET['lang'];
	if (class_exists('SitePress')){
		global $sitepress;
		$sitepress->switch_lang($curl, true);
	}
	$result ='';
	$args = array(
		'post_type' => 'product',
		'posts_per_page' => -1,
		'post_status' => 'publish',
		'ignore_sticky_posts' => 1,
	);
	$time_now =  strtotime("now");
	if(isset($_GET['orderby']) && $_GET['orderby']=='upcoming'){
		$_GET['start'] = $time_now;
	}elseif(isset($_GET['orderby']) && $_GET['orderby']=='past'){
		$_GET['end'] = $time_now;
	}
	if($_GET['end'] && $_GET['start']){
		$args = array(
			  'post_type' => 'product',
			  'posts_per_page' => -1,
			  'post_status' => 'publish',
			  'ignore_sticky_posts' => 1,
			  'meta_key' => 'we_startdate',
			  'orderby' => 'meta_value_num',
			  'meta_query' => array(
			  'relation' => 'AND',
			  array('key'  => 'we_enddate',
				   'value' => $_GET['start'],
				   'compare' => '>='),
			  array('key'  => 'we_startdate',
				   'value' => $_GET['end'],
				   'compare' => '<=')
			  ),
			  'suppress_filters' => false 
		);
		//cats
		$taxonomy =  isset($_GET['taxonomy']) ? $_GET['taxonomy'] :'';
		$terms =  isset($_GET['terms']) ? $_GET['terms'] :'';
		$speaker_id =  isset($_GET['speaker_id']) ? $_GET['speaker_id'] :'';
		$texo = array();
		if(isset($_GET['category']) && $_GET['category']!=''){
			$cat = $_GET['category'];
			$cats = explode(",",$cat);
			if(is_numeric($cats[0])){$field = 'term_id'; }
			else{ $field = 'slug'; }
			$texo['relation'] = 'OR';
			if(count($cats)>1){
				  
				  foreach($cats as $iterm) {
					  $texo[] = 
						  array(
							  'taxonomy' => 'product_cat',
							  'field' => $field,
							  'terms' => $iterm,
						  );
				  }
			  }else{
				  $texo []= 
					  array(
							  'taxonomy' => 'product_cat',
							  'field' => $field,
							  'terms' => $cats,
				  );
			}
		}
		if(isset($_GET['tag']) && $_GET['tag']!=''){
			$tag = $_GET['tag'];
			$tags = explode(",",$tag);
			if(is_numeric($tags[0])){$field_tag = 'term_id'; }
			else{ $field_tag = 'slug'; }
			if(count($tags)>1){
				  $texo['relation'] = 'AND';
				  foreach($tags as $iterm) {
					  $texo[] = 
						  array(
							  'taxonomy' => 'product_tag',
							  'field' => $field_tag,
							  'terms' => $iterm,
						  );
				  }
			  }else{
				  $texo = array(
					  array(
							  'taxonomy' => 'product_tag',
							  'field' => $field_tag,
							  'terms' => $tags,
						  )
				  );
			}
		}
		if(isset($taxonomy) && $taxonomy!='' && isset($terms) && $terms!=''){
			$terms = explode(",",$terms);
			if(is_numeric($terms[0])){$field = 'term_id'; }
			else{ $field = 'slug'; }
			$texo['relation'] = 'OR';
			if(count($terms)>1){
				  foreach($terms as $iterm) {
					  $texo[] = 
						  array(
							  'taxonomy' => $taxonomy,
							  'field' => $field,
							  'terms' => $iterm,
						  );
				  }
			  }else{
				  $texo[] = 
					  array(
							  'taxonomy' => $taxonomy,
							  'field' => $field,
							  'terms' => $terms,
				  	);
			}
		}
		if(isset($speaker_id) && $speaker_id!='' && is_numeric($speaker_id)){
			$args['meta_query']['relation'] = 'AND';
			$args['meta_query'][]= 
				 array(
					'key' => 'we_speakers',
					'value' => $speaker_id,
					'compare' => 'LIKE'
			);
		}
		if(isset($_GET['location']) && $_GET['location']!='' && is_numeric($_GET['location'])){
			$args['meta_query']['relation'] = 'AND';
			$args['meta_query'][]= 
				 array(
					'key' => 'we_default_venue',
					'value' => $_GET['location'],
					'compare' => '='
			);
		}
		if(isset($texo)){
			$args += array('tax_query' => $texo);
		}
		if(isset($_GET['ids']) && $_GET['ids']!=''){
			if(!is_array($ids)){
				$ids = explode(",", $_GET['ids']);
			}
			$args['post__in'] = $ids;
		}
		global $post;
		if(get_option('woocommerce_hide_out_of_stock_items')=='yes'){
			$args['meta_query'][] = array(
				'key'       => '_stock_status',
				'value'     => 'outofstock',
				'compare'   => 'NOT IN'
			);
		}
		$args = apply_filters( 'we_calendar_query_var', $args );
		$the_query = get_posts( $args );
		$it = count($the_query);
		$rs=array();
		$show_bt =  isset($_GET['show_bt']) ? $_GET['show_bt'] :'';
		$curent_url =  isset($_GET['curent_url']) ? $_GET['curent_url'] :'';
		if(!empty($the_query)){
			$date_format = get_option('date_format');
			$hour_format = get_option('time_format');
			$result = array();
			foreach ( $the_query as $post ) : setup_postdata( $post );
				$image_src = wp_get_attachment_image_src( get_post_thumbnail_id(),'thumb_150x160' );
				$image_src = apply_filters( 'we_qtip_image_size', $image_src, get_post_thumbnail_id() );
				$we_startdate_unix = get_post_meta(get_the_ID(),'we_startdate', true );
				$we_enddate_unix = get_post_meta(get_the_ID(),'we_enddate', true );
				$all_day = get_post_meta(get_the_ID(),'we_allday', true );
				if($we_startdate_unix!=''){
				   // $startdate_cal = gmdate("Ymd\THis", $startdate);
					$we_startdate = gmdate("Y-m-d\TH:i:s", $we_startdate_unix);// convert date ux
				}
				if($we_enddate_unix!=''){
					$we_enddate = gmdate("Y-m-d\TH:i:s", $we_enddate_unix);
					if($all_day==1){
						$we_enddate = gmdate("Y-m-d\TH:i:s", $we_enddate_unix*1 + 86400);
					}
				}
				if($all_day==1){$start_hourtime = $end_hourtime = '';}
				if($we_startdate_unix!=''){
					$alltrsl = get_option('we_text_allday')!='' ? get_option('we_text_allday') : esc_html__('(All day)','exthemes');
					if($all_day=='1'){ 
					  $h_st = '';
					  $h_e = $alltrsl;
					}else{ 
						$h_st = date_i18n( $hour_format, $we_startdate_unix);  
						$h_e = date_i18n( $hour_format, $we_enddate_unix);
					}
					if(date_i18n( $date_format, $we_startdate_unix) == date_i18n( $date_format, $we_enddate_unix)){
						if($all_day!='1'){ $h_e = ' - '.$h_e;}
						$dt_fm = date_i18n( $date_format, $we_startdate_unix).' '.$h_st.$h_e;
						$edt_fm ='';
					}else{
						$dt_fm = date_i18n( $date_format, $we_startdate_unix).' '.$h_st;
						if($we_enddate_unix!=''){
							$edt_fm = date_i18n( $date_format, $we_enddate_unix).' '.$h_e;
						}
					}
					global $product;	
					$type = $product->get_type();
					$price ='';
					if($type=='variable'){
						$price = we_variable_price_html();
					}else{
						  if ( $price_html = $product->get_price_html() ) :
							  $price = $price_html; 
						  endif; 	
					}
					$we_eventcolor = we_event_custom_color(get_the_ID());
					if($we_eventcolor==''){$we_eventcolor = we_autochange_color();}
					$url_tt = $tbt = '';
					if($show_bt == 'addtocart'){
						$variations = '';
						$product = wc_get_product(get_the_ID());
						if($product!==false) { $variations = $product->get_type();}
						if($variations == 'variable' || $variations=='variation'){
							$url_tt = get_permalink();
							$tbt = get_option('we_text_sl_op')!='' ? get_option('we_text_sl_op') : esc_html__('Select options','exthemes');
						}else{
							$url_tt = add_query_arg( array('add-to-cart' => get_the_ID()), get_permalink());
							$tbt = get_option('we_text_add_to_cart')!='' ? get_option('we_text_add_to_cart') : esc_html__('Add to cart','exthemes');
						}
					}elseif($show_bt == 'details'){
						$url_tt = get_permalink();
						$tbt = get_option('we_text_viewdetails')!='' ? get_option('we_text_viewdetails') : esc_html__('View Details','exthemes');
					}
					$status_tk =  woo_event_status( get_the_ID(), $we_enddate_unix);
					if(get_option('we_dis_status') =='yes'){ $status_tk ='';}
					$sub_title =  we_subtitle_html(get_the_ID(),true);
					$ar_rs= array(
						'id'=> get_the_ID(),
						'number'=> $it,
						'title'=> esc_attr(get_the_title()),
						'url'=> get_permalink(),
						'start'=>$we_startdate,
						'end'=>$we_enddate,
						'startdate'=> $dt_fm,
						'enddate'=> $edt_fm,
						'thumbnail' => $image_src[0],
						'price'=> $price,
						'color'=> $we_eventcolor,
						'status'=>  $status_tk,
						'description'=> get_the_excerpt(),
						'location' => get_post_meta(get_the_ID(),'we_adress', true ),
						'allDay' => $all_day,
						'url_ontt'=> $url_tt,
						'text_onbt'=> $tbt,
						'sub_title'=> $sub_title,
					);
				}
				$result[]=$ar_rs;
			endforeach; 
			wp_reset_postdata();
		}
		echo str_replace('\/', '/', json_encode($result));
		exit;
	}
}
//
if(!function_exists('we_social_share')){
	function we_social_share( $id = false){
		$id = get_the_ID();
		$tl_share_button = array('fb','tw','li','tb','gg','pin','vk','em','wa');
		ob_start();
		if(is_array($tl_share_button) && !empty($tl_share_button)){
			?>
			<ul class="wooevent-social-share">
				<?php if(in_array('fb', $tl_share_button)){ ?>
					<li class="facebook">
						<a class="trasition-all" title="<?php esc_html_e('Share on Facebook','exthemes');?>" href="#" target="_blank" rel="nofollow" onclick="window.open('https://www.facebook.com/sharer/sharer.php?u='+'<?php echo urlencode(get_permalink($id)); ?>','facebook-share-dialog','width=626,height=436');return false;"><i class="fa fa-facebook"></i>
						</a>
					</li>
				<?php }
	
				if(in_array('tw', $tl_share_button)){ ?>
					<li class="twitter">
						<a class="trasition-all" href="#" title="<?php esc_html_e('Share on Twitter','exthemes');?>" rel="nofollow" target="_blank" onclick="window.open('http://twitter.com/share?text=<?php echo urlencode(html_entity_decode(get_the_title($id), ENT_COMPAT, 'UTF-8')); ?>&amp;url=<?php echo urlencode(get_permalink($id)); ?>','twitter-share-dialog','width=626,height=436');return false;"><i class="fa fa-twitter"></i>
						</a>
					</li>
				<?php }
	
				if(in_array('li', $tl_share_button)){ ?>
						<li class="linkedin">
							<a class="trasition-all" href="#" title="<?php esc_html_e('Share on LinkedIn','exthemes');?>" rel="nofollow" target="_blank" onclick="window.open('http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo urlencode(get_permalink($id)); ?>&amp;title=<?php echo urlencode(html_entity_decode(get_the_title($id), ENT_COMPAT, 'UTF-8')); ?>&amp;source=<?php echo urlencode(get_bloginfo('name')); ?>','linkedin-share-dialog','width=626,height=436');return false;"><i class="fa fa-linkedin"></i>
							</a>
						</li>
				<?php }
	
				if(in_array('tb', $tl_share_button)){ ?>
					<li class="tumblr">
					   <a class="trasition-all" href="#" title="<?php esc_html_e('Share on Tumblr','exthemes');?>" rel="nofollow" target="_blank" onclick="window.open('http://www.tumblr.com/share/link?url=<?php echo urlencode(get_permalink($id)); ?>&amp;name=<?php echo urlencode(html_entity_decode(get_the_title($id), ENT_COMPAT, 'UTF-8')); ?>','tumblr-share-dialog','width=626,height=436');return false;"><i class="fa fa-tumblr"></i>
					   </a>
					</li>
				<?php }
	
				if(in_array('gg', $tl_share_button)){ ?>
					 <li class="google-plus">
						<a class="trasition-all" href="#" title="<?php esc_html_e('Share on Google Plus','exthemes');?>" rel="nofollow" target="_blank" onclick="window.open('https://plus.google.com/share?url=<?php echo urlencode(get_permalink($id)); ?>','googleplus-share-dialog','width=626,height=436');return false;"><i class="fa fa-google-plus"></i>
						</a>
					 </li>
				 <?php }
	
				 if(in_array('pin', $tl_share_button)){ ?>
					 <li class="pinterest">
						<a class="trasition-all" href="#" title="<?php esc_html_e('Pin this','exthemes');?>" rel="nofollow" target="_blank" onclick="window.open('//pinterest.com/pin/create/button/?url=<?php echo urlencode(get_permalink($id)) ?>&amp;media=<?php echo urlencode(wp_get_attachment_url( get_post_thumbnail_id($id))); ?>&amp;description=<?php echo urlencode(html_entity_decode(get_the_title($id), ENT_COMPAT, 'UTF-8')); ?>','pin-share-dialog','width=626,height=436');return false;"><i class="fa fa-pinterest"></i>
						</a>
					 </li>
				 <?php }
				 
				 if(in_array('vk', $tl_share_button)){ ?>
					 <li class="vk">
						<a class="trasition-all" href="#" title="<?php esc_html_e('Share on VK','exthemes');?>" rel="nofollow" target="_blank" onclick="window.open('//vkontakte.ru/share.php?url=<?php echo urlencode(get_permalink(get_the_ID())); ?>','vk-share-dialog','width=626,height=436');return false;"><i class="fa fa-vk"></i>
						</a>
					 </li>
				 <?php }
	
				 if(in_array('em', $tl_share_button)){ ?>
					<li class="email">
						<a class="trasition-all" href="mailto:?subject=<?php echo urlencode(html_entity_decode(get_the_title($id), ENT_COMPAT, 'UTF-8')); ?>&amp;body=<?php echo urlencode(get_permalink($id)) ?>" title="<?php esc_html_e('Email this','exthemes');?>"><i class="fa fa-envelope"></i>
						</a>
					</li>
				<?php }
                if(in_array('wa', $tl_share_button)){ ?>
					<li class="whatsapp">
						<a class="trasition-all" href="whatsapp://send?text=<?php echo urlencode(html_entity_decode(get_the_title($id), ENT_COMPAT, 'UTF-8')); ?> - <?php echo urlencode(get_permalink($id)) ?>" data-action="share/whatsapp/share" title="<?php esc_html_e('Share via Whatsapp','exthemes');?>"><i class="fa fa-whatsapp"></i>
						</a>
					</li>
				<?php }?>
                
			</ul>
			<?php
		}
		$output_string = ob_get_contents();
		ob_end_clean();
		return $output_string;
	}
}
// member social
if(!function_exists('speaker_print_social_accounts')){
	function speaker_print_social_accounts(){
		$accounts = array('facebook','instagram','envelope','twitter','linkedin','tumblr','google-plus','pinterest','youtube','flickr','github','dribbble');
		
		$html ='';
		foreach($accounts as $account){
			$url = get_post_meta( get_the_ID(), $account, true );
			if($url){
				if($account == 'envelope'){
					$url = 'mailto:' . $url;
				}
				$html .= '<li class="'.$account.'"><a href="'.$url.'" title="'.$account.'"><i class="fa fa-'.$account.'"></i></a></li>';
			}
		}
		if($html !=''){
			$html ='<ul class="wooevent-social-share speaker-social">'.$html.'</ul>';
		}
		return $html;
	}
}
//Global function
function wooevent_global_layout(){
	if(is_singular('product')){
		global $layout,$post;
		if(isset($layout) && $layout!=''){
			return $layout;
		}
		$layout = get_post_meta( $post->ID, 'we_layout', true );
		if($layout ==''){
			$layout = get_option('we_slayout');
		}
		return $layout;
		}
}
function we_global_startdate(){
	global $we_startdate, $post;
	if(isset($we_startdate) && $we_startdate!='' && is_main_query() && is_singular('product')){
		return $we_startdate;
	}
	$we_startdate = get_post_meta( $post->ID, 'we_startdate', true ) ;
	return $we_startdate;
}
function we_global_enddate(){
	global $we_enddate, $post;
	if(isset($we_enddate) && $we_enddate!='' && is_main_query() && is_singular('product')){
		return $we_enddate;
	}
	$we_enddate = get_post_meta( $post->ID, 'we_enddate', true ) ;
	return $we_enddate;
}
function we_global_search_result_page(){
	global $we_search_result;
	if(isset($we_search_result)){
		return $we_search_result;
	}
	$we_search_result = get_option('we_search_result') ;
	return $we_search_result;
}
function we_global_main_purpose(){
	global $we_main_purpose;
	if(isset($we_main_purpose) && $we_main_purpose!=''){
		return $we_main_purpose;
	}
	$we_main_purpose = get_option('we_main_purpose');
	return $we_main_purpose;
}
function we_global_default_spurpose(){
	global $we_layout_purpose,$post;
	if(isset($we_layout_purpose) && $we_layout_purpose!=''){
		return $we_layout_purpose;
	}
	$we_layout_purpose = get_post_meta($post->ID,'we_layout_purpose',true);
	if($we_layout_purpose=='' || $we_layout_purpose=='def'){
		if(we_global_main_purpose() =='meta'){
			if(function_exists('we_event_cat_custom_layout')){
				$we_layout_purpose = we_event_cat_custom_layout($post->ID);
				if($we_layout_purpose!=''){
					return $we_layout_purpose;
				}
			}
		}
		$we_layout_purpose = get_option('we_slayout_purpose','woo');
	}
	return $we_layout_purpose;
}

//edit link recurrence
add_action( 'admin_bar_menu', 'toolbar_link_recurren_edit', 999 );

function toolbar_link_recurren_edit( $wp_admin_bar ) {
	if(is_singular('product')){
		global $post;
		$ex_recurr = get_post_meta($post->ID,'recurren_ext', true );
		$ex_recurr  = explode("_",$ex_recurr);
		if(isset($ex_recurr[1]) && $ex_recurr[1]!=''){
			$wp_admin_bar->remove_node( 'edit' );
			$args_e = array(
				'id'    => 'edit-single',
				'title' => 'Edit Single',
				'href'  => get_edit_post_link( $post->ID, true ),
				'meta'  => array( 'class' => 'single-edit' )
			);
			$wp_admin_bar->add_node( $args_e );
			$args = array(
				'id'    => 'recurren_edit',
				'title' => 'Edit All Recurrence',
				'href'  => get_edit_post_link( $ex_recurr[1], true ),
				'meta'  => array( 'class' => 'recurren-page' )
			);
			$wp_admin_bar->add_node( $args );
		}
	}
}
//barcode
add_action( 'wpo_wcpdf_after_order_details', 'wooevents_add_barcode', 10, 2 );
function wooevents_add_barcode ($template_type, $order) {
	$items = $order->get_items();
	$fev = 0;
	foreach ( $items as $item ) {
		if($item->get_meta('_startdate')!=''){
			$fev = 1;
			break;
		}
	}
	if($fev == 0){ return;}
	?>
        <div class="we-barcode">
        <h3><?php esc_html_e('Your order Barcode:','exthemes');?></h3>
        <p><img src="http://www.barcode-generator.org/zint/api.php?bc_number=20&bc_data=<?php echo $order->get_order_number(); ?>"/></p>
        </div>
        <?php
}
//Add info to pdf invoice
add_action( 'wpo_wcpdf_after_item_meta', 'wooevents_add_event_meta', 10, 3 );
function wooevents_add_event_meta ($template_type, $item, $order) {
	$we_startdate = get_post_meta( $item['product_id'], 'we_startdate', true ) ;
	$we_enddate = get_post_meta( $item['product_id'], 'we_enddate', true ) ;
	$we_adress = get_post_meta( $item['product_id'], 'we_adress', true ) ;
	$all_day = get_post_meta($item['product_id'],'we_allday', true );
	$html ='';
	if($all_day!='1' && $we_startdate!=''){
		$stdatetrsl = get_option('we_text_stdate')!='' ? get_option('we_text_stdate') :  esc_html__('Start Date','exthemes');
		$edatetrsl = get_option('we_text_edate')!='' ? get_option('we_text_edate') : esc_html__('End Date','exthemes');
		$alltrsl = get_option('we_text_allday')!='' ? get_option('we_text_allday') : esc_html__('(All day)','exthemes');
		$html .='<dl class="meta">'.$stdatetrsl.': '.date_i18n( get_option('date_format'), $we_startdate).' '.date_i18n(get_option('time_format'), $we_startdate).'</dl>';
		if($we_enddate!=''){
			$html .='<dl class="meta">'.$edatetrsl.': '.date_i18n( get_option('date_format'), $we_enddate).' '.date_i18n(get_option('time_format'), $we_enddate).'</dl>';
		}
	}elseif($we_startdate!=''){
		$html .='<dl class="meta">'.$stdatetrsl.': '.date_i18n( get_option('date_format'), $we_startdate).'</dl>';
		if($we_enddate!=''){
			$html .='<dl class="meta">'.$edatetrsl.': '.date_i18n( get_option('date_format'), $we_enddate).' '.$alltrsl.'</dl>';
		}
	}
	if($we_adress!=''){
	  $eaddtrsl = get_option('we_text_addres')!='' ? get_option('we_text_addres') : esc_html__('Address','exthemes');
	  $html .='<dl class="meta">'.$eaddtrsl.': '.$we_adress.'</dl>';
	}
	// user info
	
	$order_items = $order->get_items();
	$n = 0; $find = 0;
	foreach ($order_items as $items_key => $items_value) {
		$n ++;
		if($items_value->get_id() == $item['item_id']){
			$find = 1;
			break;
		}
	}
	if($find == 0){ return;}
	$value_id = $item['product_id'].'_'.$n;
	$value_id = apply_filters( 'we_attendee_key', $value_id, $item );
	
	$metadata = get_post_meta($order-> get_id(),'att_info-'.$value_id, true);
	if($metadata == ''){
		$metadata = get_post_meta($order->get_id(),'att_info-'.$item['product_id'], true);
	}
	if($metadata !=''){
		
		$t_atten = get_option('we_text_attende_')!='' ? get_option('we_text_attende_') : esc_html__('Attendees info','exthemes');
		$t_name = get_option('we_text_name_')!='' ? get_option('we_text_name_') : esc_html__('Name: ','exthemes');
		$t_email = get_option('we_text_email_')!='' ? get_option('we_text_email_') : esc_html__('Email: ','exthemes');
		
		$metadata = explode("][",$metadata);
		if(!empty($metadata)){
			$i=0;
			foreach($metadata as $item){
				$i++;
				$item = explode("||",$item);
				$f_name = isset($item[1]) && $item[1]!='' ? $item[1] : '';
				$l_name = isset($item[2]) && $item[2]!='' ? $item[2] : '';
				$html .= '<div class="we-user-info">'.$t_atten.' ('.$i.') ';
				$html .=  $f_name!='' && $l_name!='' ? '<span style="margin-right:15px;"><b>'.$t_name.'</b>'.$f_name.' '.$l_name.'</span>' : '';
				$html .=  isset($item[0]) && $item[0]!='' ? '<span><b>'.$t_email.' </b>'.$item[0].'</span>' : '';
				$html .= '</div>';
			}
		}
	}
	
	
	echo $html;
}
//ver 1.1
add_action( 'wp_ajax_ex_loadmore_grid', 'ajax_ex_loadmore_grid' );
add_action( 'wp_ajax_nopriv_ex_loadmore_grid', 'ajax_ex_loadmore_grid' );

function ajax_ex_loadmore_grid(){
	global $columns,$number_excerpt,$show_time,$orderby,$img_size;
	$atts = json_decode( stripslashes( $_POST['param_shortcode'] ), true );
	$columns = $atts['columns']	=  isset($atts['columns']) ? $atts['columns'] : 1;
	$img_size =  isset($atts['img_size']) ? $atts['img_size'] :'wethumb_460x307';
	$show_time =  isset($atts['show_time']) ? $atts['show_time'] :'';
	$orderby =  isset($atts['orderby']) ? $atts['orderby'] :'';
	$count =  isset($atts['count']) ? $atts['count'] :'6';
	$posts_per_page =  isset($atts['posts_per_page']) ? $atts['posts_per_page'] :'';
	$number_excerpt =  isset($atts['number_excerpt'])&& $atts['number_excerpt']!='' ? $atts['number_excerpt'] : '10';
	$style =  isset($atts['style']) ? $atts['style'] :'';
	$page = $_POST['page'];
	$param_query = json_decode( stripslashes( $_POST['param_query'] ), true );
	$param_ids = '';
	if(isset($_POST['param_ids']) && $_POST['param_ids']!=''){
		$param_ids =  json_decode( stripslashes( $_POST['param_ids'] ), true )!='' ? json_decode( stripslashes( $_POST['param_ids'] ), true ) : explode(",",$_POST['param_ids']);
	}
	$end_it_nb ='';
	if($page!=''){ 
		$param_query['paged'] = $page;
		$count_check = $page*$posts_per_page;
		if(($count_check > $count) && (($count_check - $count)< $posts_per_page)){$end_it_nb = $count - (($page - 1)*$posts_per_page);}
		else if(($count_check > $count)) {die;}
	}
	if($orderby =='rand' && is_array($param_ids)){
		$param_query['post__not_in'] = $param_ids;
		$param_query['paged'] = 1;
	}
	//echo '<pre>';
	//print_r($param_query);//exit;
	$the_query = new WP_Query( $param_query );
	$it = $the_query->post_count;
	ob_start();
	if($the_query->have_posts()){
		?>
        <div class="grid-row de-active">
        <?php
		$i =0;
		$arr_ids = array();
		while($the_query->have_posts()){ $the_query->the_post();
			$i++;
			$arr_ids[] = get_the_ID();
			if($style=='classic'){
				wooevent_template_plugin('grid-classic', true);
			}else{
				wooevent_template_plugin('grid', true);
			}
			if($i%$columns==0){?>
				</div>
				<div class="grid-row de-active">
				<?php
			}
			if($end_it_nb!='' && $end_it_nb == $i){break;}
		}
		//echo esc_html(str_replace('\/', '/', json_encode($arr_ids)));exit;
		if($orderby =='rand' && is_array($param_ids)){
		?>
        <script type="text/javascript">
		jQuery(document).ready(function() {
			jQuery('#<?php  echo esc_html__($_POST['id_crsc']);?> input[name=param_ids]').val(<?php echo str_replace('\/', '/', json_encode(array_merge($param_ids,$arr_ids)));?>);
		});
        </script>
        <?php 
		}?>
        </div>
        <?php
	}
	$html = ob_get_clean();
	echo  $html;
	die;
}
//table load
add_action( 'wp_ajax_ex_loadmore_table', 'ajax_ex_loadmore_table' );
add_action( 'wp_ajax_nopriv_ex_loadmore_table', 'ajax_ex_loadmore_table' );

function ajax_ex_loadmore_table(){
	global $style,$show_time,$show_atc,$show_thumb;
	$atts = json_decode( stripslashes( $_POST['param_shortcode'] ), true );
	$style =  isset($atts['style']) ? $atts['style'] :'';
	$count =  isset($atts['count']) ? $atts['count'] :'6';
	$show_atc =  isset($atts['show_atc']) ? $atts['show_atc'] :'';
	$show_time =  isset($atts['show_time']) ? $atts['show_time'] :'';
	$show_thumb =  isset($atts['show_thumb']) ? $atts['show_thumb'] :'';
	$posts_per_page =  isset($atts['posts_per_page']) ? $atts['posts_per_page'] :'';
	$page = $_POST['page'];
	$style =  isset($atts['style']) ? $atts['style'] :'';
	$param_query = json_decode( stripslashes( $_POST['param_query'] ), true );
	$end_it_nb ='';
	if($page!=''){ 
		$param_query['paged'] = $page;
		$count_check = $page*$posts_per_page;
		if(($count_check > $count) && (($count_check - $count)< $posts_per_page)){$end_it_nb = $count - (($page - 1)*$posts_per_page);}
		else if(($count_check > $count)) {die;}
	}
	$the_query = new WP_Query( $param_query );
	$it = $the_query->post_count;
	ob_start();
	global $ajax_load;
	if($the_query->have_posts()){
		while($the_query->have_posts()){ $the_query->the_post();
			$ajax_load =1;
			wooevent_template_plugin('table', true);
			if($end_it_nb!='' && $end_it_nb == $i){break;}
		}
	}
	$html = ob_get_clean();
	echo  $html;
	die;
}
// auto change color when low stock
if(!function_exists('we_autochange_color')){
	function we_autochange_color(){
		$color = '';
		$we_auto_color = get_option('we_auto_color');
		if($we_auto_color=='on'){
			global $product,$post;
			$stock_status = get_post_meta($post->ID, '_stock_status',true);
			$_manage_stock = get_post_meta($post->ID, '_manage_stock',true);
			$numleft  = $product->get_stock_quantity();
			if($_manage_stock=='yes' && $numleft > 0){
				$stock_status = 'instock';
			}
			$type = $product->get_type();
			if($type=='variable' && $numleft < 1){
				$all_st = 'out';
				foreach ($product->get_available_variations() as $key_status) {
					if(get_post_meta( $key_status['variation_id'], '_stock_status', true ) !='outofstock'){
						$all_st = 'in';
					}
				}
				if($all_st == 'out'){ $stock_status ='outofstock';}
				else{ $stock_status = 'instock';}
			}
			if($stock_status !='outofstock') { 
				$total = get_post_meta($post->ID, 'total_sales', true);
				if($total >= $numleft && $numleft!=0){
					$color = '#FFEB3B';
				}elseif($numleft=='0'){
					//$color = '#cc0000';
				}
			}else{
				$color = '#cc0000';
			}
		}
		$color = apply_filters( 'we_event_auto_color', $color, $we_auto_color);
		return $color;
	}
}
if(!function_exists('we_variable_price_html')){
	function we_variable_price_html(){
		$fromtrsl = get_option('we_text_from')!='' ? get_option('we_text_from') : esc_html__('From  ','exthemes');
		global $product; 
		$price_html = wc_price($product->get_variation_price('min')).$product->get_price_suffix();
		return apply_filters( 'we_variable_price_html', $fromtrsl.' '.$price_html, $product->get_variation_price('min'), $product,$fromtrsl);
	}
}

if(!function_exists('we_hide_booking_form')){
	function we_hide_booking_form(){
		$time_stops = get_post_meta(get_the_ID(),'we_stop_booking', true );
		$hour = false;
		if (strpos($time_stops, 'h') !== false) {
			$hour = true;
			$time_stops = str_replace("h","",$time_stops);
		}
		if($time_stops =='' || $time_stops < 0 ){
			$time_stops = get_option('we_stop_booking');
			if (strpos($time_stops, 'h') !== false) {
				$hour = true;
				$time_stops = str_replace("h","",$time_stops);
			}
		}
		$we_startdate =get_post_meta( get_the_ID(), 'we_startdate', true );
		if(is_numeric($time_stops)  && $we_startdate !='' && $we_startdate > 0){
			$time_now =  strtotime("now");
			$we_time_zone = get_post_meta(get_the_ID(),'we_time_zone',true);
			if($we_time_zone!='' && $we_time_zone!='def'){
				$we_time_zone = $we_time_zone * 60 * 60;
				$time_now = $we_time_zone + $time_now;
			}
			$we_main_purpose = we_global_main_purpose();
			$we_layout_purpose = we_global_default_spurpose();
			if($hour == true){
				$time_stops = $we_startdate - $time_stops*3600;
			}else{
				$time_stops = $we_startdate - $time_stops*86400;
			}
			if(($time_now > $time_stops  && $we_main_purpose=='event') || ($time_now > $time_stops  && $we_layout_purpose=='event') || ($time_now > $time_stops  && $we_layout_purpose=='custom')){
				return '
				<style type="text/css">.woocommerce div.product form.cart, .woocommerce div.product p.cart{ display:none !important}</style>';
			}
		}
		return;
	}
}
if(!function_exists('we_update_total_sales')){
	add_action( 'woocommerce_order_status_cancelled', 'we_update_total_sales' );
	function we_update_total_sales($order_id) {
		$order = new WC_Order( $order_id );
		$items = $order->get_items();
		foreach ( $items as $item ) {
			$product_id = $item['product_id'];
			$total = get_post_meta( $product_id, 'total_sales', true );
			if($total !='' && $total > 0){
				$total = $total -1;
				update_post_meta( $product_id, 'total_sales', $total);
			}
		}
	}
}
add_action( 'wp_ajax_ex_loadevent_ofday', 'ajax_ex_loadevent_ofday' );
add_action( 'wp_ajax_nopriv_ex_loadevent_ofday', 'ajax_ex_loadevent_ofday' );
if(!function_exists('ajax_ex_loadevent_ofday')){
	function ajax_ex_loadevent_ofday(){
		$spe_day = $_POST['param_day'];
		$ids = $_POST['ids'];
		if($ids==''){ exit;}
		if(!is_array($ids)){
			$ids = explode(",", $ids);
		}
		$args = array(
			'post_type' => 'product',
			'posts_per_page' => '-1',
			'post_status' => 'publish',
			'post__in' =>  $ids,
			'order' => 'ASC',
			'orderby' => 'meta_value_num',
			'meta_key' => 'we_startdate',
			'ignore_sticky_posts' => 1,
		);
		echo we_calendar_modern_data($args);
		exit;
	}
}
if(!function_exists('we_calendar_modern_data')){
	function we_calendar_modern_data($args) {
		ob_start();
		$the_query = new WP_Query( $args );
		$day_event = '';
		if($the_query->have_posts()){
			while($the_query->have_posts()){ $the_query->the_post();
				$we_startdate = get_post_meta( get_the_ID(), 'we_startdate', true );
				$we_enddate = get_post_meta( get_the_ID(), 'we_enddate', true )  ;
				global $product;	
				$type = $product->get_type();
				$price ='';
				if($type=='variable'){
					$price = we_variable_price_html();
				}else{
					if ( $price_html = $product->get_price_html() ) :
						$price = $price_html; 
					endif; 	
				}
				$we_adress = get_post_meta( get_the_ID(), 'we_adress', true );
				$we_status = woo_event_status( get_the_ID(), $we_enddate);
				if(get_option('we_dis_status') =='yes'){ $we_status ='';}
				$we_eventcolor = we_event_custom_color(get_the_ID());;
				if($we_eventcolor==''){$we_eventcolor = we_autochange_color();}
				$bgev_color = '';
				if($we_eventcolor!=""){
					$bgev_color = 'style="background-color:'.$we_eventcolor.'"';
				}
				?>
                
                <div class="day-event-details">
                	<?php 
					if(has_post_thumbnail(get_the_ID())){?>
                    <div class="day-ev-image">
                    	<a href="<?php the_permalink(); ?>" class="link-more">
							<?php the_post_thumbnail('wethumb_85x85');
							echo '<span class="bg-overlay"></span>';
							if($price!=''){
								echo '<span class="item-evprice" '.$bgev_color.'>'.$price.'</span>';
							}
							?>
                        </a>
                    </div>
                    <?php }?>
                    <div class="day-ev-des">
                        <h3><a href="<?php the_permalink(); ?>" class="link-more">
                            <?php  the_title();?>
                        </a></h3>
                        <div class="we-more-meta">
                        <?php
                            if($we_startdate!=''){
                                $sttime = '<span> - '.date_i18n(get_option('time_format'), $we_startdate).'</span>';
                                echo '<span class="st-date"><i class="fa fa-calendar"></i>'.date_i18n( get_option('date_format'), $we_startdate).$sttime.'</span>';
                            }
                            if($we_status!=''){
                                echo '
                                <span>
                                    <i class="fa fa-ticket"></i>
                                    '.$we_status.'
                                </span>';
                            }
                        ?>
                        </div>
                        <div class="ev-excerpt"><?php echo get_the_excerpt();?></div>
                    </div>
                </div>
                <?php
			}
		}else{
			$noftrsl = get_option('we_text_no_evf')!='' ? get_option('we_text_no_evf') : esc_html__('No Events Found','exthemes');
			echo '<span class="day-event-details">'.$noftrsl.'</span>';
		}
		wp_reset_postdata();
		$day_event = ob_get_contents();
		ob_end_clean();
		return $day_event;
	}
}
add_action('woocommerce_new_order_item','we_add_info_to_order_item_meta',10,2);
if(!function_exists('we_add_info_to_order_item_meta')){
	function we_add_info_to_order_item_meta($item_id, $item)
	{
		if(is_admin()){ return;}
		$values = $item->legacy_values;
		$_ev_date = get_post_meta( $values['product_id'], 'we_startdate', true );
		if($_ev_date!='')
		{
			$_ev_date = date_i18n( get_option('date_format'), $_ev_date).' - '.date_i18n(get_option('time_format'), $_ev_date);
			wc_add_order_item_meta($item_id,'_startdate',$_ev_date);
		}
		$_ev_edate = get_post_meta( $values['product_id'], 'we_enddate', true );
		if($_ev_edate!='')
		{
			$_ev_edate = date_i18n( get_option('date_format'), $_ev_edate).' - '.date_i18n(get_option('time_format'), $_ev_edate);
			wc_add_order_item_meta($item_id,'_enddate',$_ev_edate);
		}
		
	}
}
if(!function_exists('we_event_custom_color')){
	function we_event_custom_color($id){
		if($id==''){
			return;	
		}
		$we_eventcolor = get_post_meta( $id, 'we_eventcolor', true );
		$we_cat_color = get_option('we_cat_ctcolor');
		if($we_eventcolor=='' && $we_cat_color=='on'){
			$args = array(
				'hide_empty'        => true, 
			);
			$terms = wp_get_post_terms($id, 'product_cat', $args);
			if(!empty($terms) && !is_wp_error( $terms )){
				foreach ( $terms as $term ) {
					$we_eventcolor = get_option('we_category_color_' . $term->term_id);
					$we_eventcolor = str_replace("#", "", $we_eventcolor);
					if($we_eventcolor!=''){
						$we_eventcolor = '#'.$we_eventcolor;
						break;
					}
				}
			}
		}
		$we_eventcolor = apply_filters( 'we_event_customcolor', $we_eventcolor,$id );
		return $we_eventcolor;
	}
}
if(!function_exists('we_taxonomy_info')){
	function we_taxonomy_info( $tax, $link=false, $id= false){
		if(isset($id) && $id!=''){
			$product_id = $id;
		}else{
			$product_id = get_the_ID();
		}
		$post_type = 'product';
		ob_start();
		if(isset($tax) && $tax!=''){
			$args = array(
				'hide_empty'        => false, 
			);
			$terms = wp_get_post_terms($product_id, $tax, $args);
			if(!empty($terms) && !is_wp_error( $terms )){
				$c_tax = count($terms);
				$i=0;
				foreach ( $terms as $term ) {
					$i++;
					if(isset($link) && $link=='off'){
						echo $term->name;
					}else{
						echo '<a href="'.get_term_link( $term ).'" title="' . $term->name . '">'. $term->name .'</a>';
					}
					if($i != $c_tax){ echo '<span>, </span>';}
				}
			}
		}
		$output_string = ob_get_contents();
		ob_end_clean();
		return $output_string;
	}
}
if(!function_exists('we_ical_google_button')){
	function we_ical_google_button( $id ){
		if(isset($id) && $id!=''){
			$product_id = $id;
		}else{
			$product_id = get_the_ID();
		}
		$we_startdate = get_post_meta( $product_id, 'we_startdate', true ) ;
		if($we_startdate==''){ return;}
		$we_enddate = get_post_meta( $product_id, 'we_enddate', true ) ;
		$excerpt = get_post_field('post_excerpt', $product_id);
		if($excerpt !=''){
			$excerpt = apply_filters('the_excerpt', $excerpt);
		}
		$title = urlencode(html_entity_decode(get_the_title($product_id), ENT_COMPAT, 'UTF-8'));
		$all_day = get_post_meta($product_id,'we_allday', true );
		if($all_day!='1'){
			$st = gmdate("Ymd\THis", $we_startdate);
			if($we_enddate!=''){
				$en = gmdate("Ymd\THis", $we_enddate);
			}else{$en =$st;}
		}else{
			$st = gmdate("Ymd", $we_startdate);
			if($we_enddate!=''){
				$we_enddate = $we_enddate + 86400;
				$en = gmdate("Ymd", $we_enddate);
			}else{$en =$st;}
		}
		?>
        <div class="we-icl-import col-md-12">
            <div class="row">
                    <div class="btn btn-primary"><a href="<?php echo home_url().'?ical_product='.$product_id; ?>"><?php echo get_option('we_text_ical')!='' ? get_option('we_text_ical') : esc_html__('+ Ical Import','exthemes');?></a></div>
                    <div class="btn btn-primary"><a href="https://www.google.com/calendar/render?dates=<?php  echo $st;?>/<?php echo $en;?>&action=TEMPLATE&text=<?php echo $title;?>&location=<?php echo esc_attr(urlencode(get_post_meta($product_id,'we_adress', true )));?>&details=<?php echo esc_attr(urlencode( strip_tags($excerpt) ) );?>"><?php echo get_option('we_text_ggcal')!='' ? get_option('we_text_ggcal') : esc_html__('+ Google calendar','exthemes');?></a></div>
            </div>
        </div>
        <?php
	}
}
if(!function_exists('we_ical_google_button_inorder')){
	add_action( 'woocommerce_order_item_meta_end', 'we_ical_google_button_inorder', 10, 3 );
	function we_ical_google_button_inorder($item_id, $item, $order){
		$id = $item['product_id'];
		we_ical_google_button( $id );
	}
}
if(!function_exists('we_show_custom_meta_inorder')){
	add_action( 'woocommerce_order_item_meta_end', 'we_show_custom_meta_inorder', 9, 3 );
	function we_show_custom_meta_inorder($item_id, $item, $order){
		$id = $item['product_id'];
		$we_startdate = get_post_meta( $id, 'we_startdate', true ) ;
		$we_enddate = get_post_meta( $id, 'we_enddate', true ) ;
		$lbst = get_option('we_text_start')!='' ? get_option('we_text_start') : esc_html__('Start','exthemes');
		$lbe = get_option('we_text_end')!='' ? get_option('we_text_end') : esc_html__('End','exthemes');
		$all_day = get_post_meta($id,'we_allday', true );
		if($we_startdate!=''){
			$st_html = date_i18n( get_option('date_format'), $we_startdate).' ';
            if(($we_enddate=='') || ($all_day!='1' && (date_i18n(get_option('time_format'), $we_startdate)!=date_i18n(get_option('time_format'), $we_enddate)))){ 
            	$st_html .= date_i18n(get_option('time_format'), $we_startdate);
           	}
			
			echo '<br><span><strong>'.$lbst.':</strong> '.$st_html.'</span><br>';
		}
		if($we_enddate!=''){
			$en_html = date_i18n( get_option('date_format'), $we_enddate);
			if($all_day!='1' && (date_i18n(get_option('time_format'), $we_startdate)!=date_i18n(get_option('time_format'), $we_enddate))){ 
				$en_html .= ' '.date_i18n(get_option('time_format'), $we_enddate);
			}elseif($all_day=='1'){ 
				$alltrsl = get_option('we_text_allday')!='' ? get_option('we_text_allday') : esc_html__('(All day)','exthemes');
				$en_html .= ' '.$alltrsl;
			}
			
			
			echo '<span><strong>'.$lbe.':</strong> '.$en_html.'</span><br>';
		}
	}
}
/* Search hook*/
add_action( 'pre_get_posts','we_event_search_hook_change',101 );
if (!function_exists('we_event_search_hook_change')) {
	function we_event_search_hook_change($query) {
		if( is_search() && $query->is_main_query() && is_shop() && !is_admin() ){
			if( isset($_GET['orderby']) && $_GET['orderby']!='' ){
				$cure_time =  strtotime("now");
				$query->set('meta_key', 'we_startdate');
				$query->set('meta_value', $cure_time);
				if($_GET['orderby']=='upcoming'){
					$query->set('meta_compare', '>');
				}
				if($_GET['orderby']=='past'){
					$query->set('meta_compare', '<');
				}
			}
			if( isset($_GET['location']) && $_GET['location']!='' ){
				$meta_query_args['relation'] = 'AND';
				$meta_query_args = array(
					array(
					  'key' => 'we_default_venue',
					  'value' => array ($_GET['location']),
					  'compare' => 'IN',
					),
				);
			}
			if( isset($_GET['evyear']) && $_GET['evyear']!='' ){
				$start = strtotime('first day of January '.$_GET['evyear'] );
				$end = strtotime('last day of December '.$_GET['evyear'] ) + 86399;
				if(isset($_GET['month_up']) && $_GET['month_up']!=''){
					$cr_m = date("m");
					$m = we_convert_month_to_text($_GET['month_up']);
					if($cr_m < $_GET['month_up'] || $cr_m > $_GET['month_up']){
						$y = $_GET['evyear'];
						if($cr_m < $_GET['month_up']){
							$y = $_GET['evyear'] + 1;
						}
						$start = strtotime('first day of '.$m.' '.$y );
						$end = strtotime('last day of '.$m.' '.$y ) + 86399;
					}elseif($cr_m == $_GET['month_up']){
						$cure_time =  strtotime("now");
						$gmt_offset = get_option('gmt_offset');
						if($gmt_offset!=''){
							$cure_time = $cure_time + ($gmt_offset*3600);
						}
						$start = $cure_time;
						$end = strtotime('last day of '.$m.' '.$_GET['evyear'] ) + 86399;
					}else{ echo 'error';exit;}
				}elseif(isset($_GET['month']) && $_GET['month']!=''){
					$m = we_convert_month_to_text($_GET['month']);
					$start = strtotime('first day of '.$m.' '.$_GET['evyear'] );
					$end = strtotime('last day of '.$m.' '.$_GET['evyear'] ) + 86399;
				}
				//$start = mktime(0, 0, 0, 1, 1, $_GET['evyear']);
				//$end = mktime(0, 0, 0, 12, 31, $_GET['evyear']);
				$meta_query_args [] =
					array('key'  => 'we_startdate',
						 'value' => $start,
						 'compare' => '>');
				$meta_query_args [] =		 
					array('key'  => 'we_startdate',
						 'value' => $end,
						 'compare' => '<='
				);
			}else if((isset($_GET['month_up']) && $_GET['month_up']!='') || (isset($_GET['month']) && $_GET['month']!='')){
				if(isset($_GET['month_up']) && $_GET['month_up']!=''){
					$cr_m = date("m");
					$m = we_convert_month_to_text($_GET['month_up']);
					if($cr_m < $_GET['month_up'] || $cr_m > $_GET['month_up']){
						$y = $_GET['evyear'];
						if($cr_m < $_GET['month_up']){
							$y = $_GET['evyear'] + 1;
						}
						$start = strtotime('first day of '.$m.' '.$y );
						$end = strtotime('last day of '.$m.' '.$y ) + 86399;
					}elseif($cr_m == $_GET['month_up']){
						$cure_time =  strtotime("now");
						$gmt_offset = get_option('gmt_offset');
						if($gmt_offset!=''){
							$cure_time = $cure_time + ($gmt_offset*3600);
						}
						$start = $cure_time;
						$end = strtotime('last day of '.$m.' '.$_GET['evyear'] ) + 86399;
					}else{ echo 'error';exit;}
				}elseif(isset($_GET['month']) && $_GET['month']!=''){
					$m = we_convert_month_to_text($_GET['month']);
					$start = strtotime('first day of '.$m.' '.$_GET['evyear'] );
					$end = strtotime('last day of '.$m.' '.$_GET['evyear'] ) + 86399;
				}
				$meta_query_args [] =
					array('key'  => 'we_startdate',
						 'value' => $start,
						 'compare' => '>');
				$meta_query_args [] =		 
					array('key'  => 'we_startdate',
						 'value' => $end,
						 'compare' => '<='
				);
			}else if( isset($_GET['sm']) && $_GET['sm']=='event' ){
				$meta_query_args [] =
					array('key'  => 'we_startdate',
						 'value' => 0,
						 'compare' => '>');
			}
			if(isset($meta_query_args)){
				$query->set('meta_query', $meta_query_args);
			}
		}
		//return $query;
	}
}
if(!function_exists('we_convert_month_to_text')){
	function we_convert_month_to_text($month){
		if($month=='01'){
			$m = 'January';
		}else if($month=='02'){
			$m = 'February';
		}else if($month=='03'){
			$m = 'March';
		}else if($month=='04'){
			$m = 'April';
		}else if($month=='05'){
			$m = 'May';
		}else if($month=='06'){
			$m = 'June';
		}else if($month=='07'){
			$m = 'July';
		}else if($month=='08'){
			$m = 'August';
		}else if($month=='09'){
			$m = 'September';
		}else if($month=='10'){
			$m = 'October';
		}else if($month=='11'){
			$m = 'November';
		}else if($month=='12'){
			$m = 'December';
		}else{ echo 'error';exit;}
		return $m;
	}
}
add_filter( 'the_content', 'we_venues_the_content', 20 );
function we_venues_the_content($content){
	if ( is_singular('we_venue') ){
		$content = $content.'[we_grid style="classic" count="999" posts_per_page="6" columns="3" meta_key="we_default_venue" meta_value="'.get_the_ID().'"]';
	}
	return do_shortcode($content);
}

if(!function_exists('we_login_if_sc')){
	function we_login_if_sc( $atts,$content ) {
		$mess =  isset($atts['message']) ? $atts['message'] : esc_html__('Please login to submit event','ex-themes');
		$login_url =  isset($atts['login_url']) ? $atts['login_url'] : '';
		ob_start();
		if(is_user_logged_in()){
			echo $content;
		}else{
			if($login_url!=''){
				echo '<p class="we-log-requied"><a href="'.esc_url($login_url).'">'.$mess.'</a></p>';
			}else{
				echo '<p class="we-log-requied">'.$mess.'</p>';
			}
		}
		$output_string = ob_get_contents();
		ob_end_clean();
		return $output_string;
	}
	add_shortcode( 'we_lgrequied', 'we_login_if_sc' );
}

// Support schema
if(!function_exists('we_google_event_schema')){
	function we_google_event_schema() {
		if(get_option('we_schema')!='yes'){
			return;
		}
		if(is_singular('product')){
			global $post;
			$_product = wc_get_product ($post->ID);
			$type = $_product->get_type();
			if($type=='variable'){
				$price = $_product->get_variation_price('min');
			}else{
				$price = $_product->get_price();
			}
			$we_startdate = get_post_meta( $post->ID, 'we_startdate', true ) ;
			if($we_startdate==''){ return;}
			$we_enddate = get_post_meta( $post->ID, 'we_enddate', true ) ;
			$excerpt = get_post_field('post_excerpt', $post->ID);
			if($excerpt !=''){
				$excerpt = apply_filters('the_excerpt', $excerpt);
			}
			$all_day = get_post_meta($post->ID,'we_allday', true );
			if($all_day!='1'){
				$st = gmdate("Y-m-d\THis", $we_startdate);
				if($we_enddate!=''){
					$en = gmdate("Y-m-d\THis", $we_enddate);
				}else{$en =$st;}
			}else{
				$st = gmdate("Ymd", $we_startdate);
				if($we_enddate!=''){
					$we_enddate = $we_enddate + 86400;
					$en = gmdate("Ymd", $we_enddate);
				}else{$en =$st;}
			}
			$image_src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID),'full' );
			$image_src = isset($image_src[0]) && $image_src[0]!='' ? $image_src[0] : '';
			?>
			<script type="application/ld+json">
            {
				"@context": "http://schema.org",
				"@type": "Event",
				"name": "<?php echo esc_attr(get_the_title($post->ID));?>",
				"startDate": "<?php echo esc_attr($st);?>",
				"location": {
				  "@type": "Place",
				  "name": "<?php echo esc_attr(get_the_title(get_post_meta( $post->ID, 'we_default_venue', true )));?>",
				  "address": "<?php echo esc_attr(get_post_meta( $post->ID, 'we_adress', true ));?>"
				},
				"image": [
				  "<?php echo esc_url($image_src); ?>"
				 ],
				"description": "<?php echo esc_attr($excerpt);?>",
				"offers": {
				  "@type": "Offer",
				  "url": "<?php echo esc_attr(get_permalink($post->ID));?>",
				  "price": "<?php echo esc_attr($price);?>",
				  "priceCurrency": "<?php echo esc_attr(get_woocommerce_currency()); ?>",
				  <?php 
				  $stock_status = get_post_meta($post->ID, '_stock_status',true);
				  if($stock_status !='outofstock') {
					  echo '"availability": "http://schema.org/SoldOut"';
				  }?>
				},
				<?php
				$we_speakers = get_post_meta( $post->ID, 'we_speakers', true );
				if(!is_array($we_speakers) && $we_speakers!=''){
					$we_speakers = explode(",",$we_speakers);
				}
				if(is_array($we_speakers)){
					?>
					"performer": <?php if(count($we_speakers) >1){?>[<?php }?>
					<?php
					$i = 0;
					foreach($we_speakers as $speaker){
						$i ++;
						$spk_img = wp_get_attachment_image_src( get_post_thumbnail_id($speaker),'full' );
						$spk_img = isset($spk_img[0]) && $spk_img[0]!='' ? $spk_img[0] : '';?>
						{
						  "@type": "Person",
						  "image": "<?php echo esc_url($spk_img);?>",
						  "name": "<?php echo esc_attr(get_the_title($speaker));?>"
						}<?php if($i!=count($we_speakers)){ echo ',';}
					}
					if(count($we_speakers) >1){?>],<?php }
				}?>
				"endDate": "<?php echo esc_attr($en);?>"
            }
            </script>
			<?php
		}
	}
	add_action('wp_head', 'we_google_event_schema');
}
if(!function_exists('we_if_product_isevent')){
	function we_if_product_isevent($id){
		$we_mpurpose = get_option('we_main_purpose');
		$we_glayout = get_option('we_slayout_purpose');
		$we_slayout = get_post_meta($id,'we_layout_purpose',true);
		if($we_mpurpose =='meta'){
			if($we_glayout !='event' && $we_slayout =='event' || $we_glayout =='event' && $we_slayout !='woo'){
				return true;
			}
		}else if($we_mpurpose =='custom'){
			if($we_slayout =='event'){
				return true;
			}
		}else if($we_mpurpose =='' || $we_mpurpose =='event'){
			return true;
		}
		return false;
	}
}

if(!function_exists('we_calendar_month_select')){
	function we_calendar_month_select($cat_include,$tag_include,$location_include,$spk_include){?>
        <div class="we-calendar-filter">
            <div class="we-cal-filter-month">
                <select name="cal-filter-month" class="we-mft-select">
                    <option value=""><?php echo esc_html__('Months','exthemes');?></option>
					<?php 
                    $currentMonth = (int)date('m');
            
                    for ($x = $currentMonth; $x < $currentMonth + 12; $x++) {
                        $date = date('F j, Y', mktime(0, 0, 0, $x, 1));
                        $value = date('Y-m-d', mktime(0, 0, 0, $x, 1));
                        $selected = '';
                        if((isset($_GET['month']) && $_GET['month'] ==$value)){
                            $selected ='selected';
                        }
                        echo '<option value="'. $value .'" '.$selected.'>'. $date .'</option>';
                    }?>
                </select>
            </div>
            <?php 
            if($cat_include!='hide'){
                $args = array( 'hide_empty' => false ); 
                if($cat_include!=''){
                    $cat_include = explode(",", $cat_include);
                    if(is_numeric($cat_include[0])){
                        $args['include'] = $cat_include;
                    }else{
                        $args['slug'] = $cat_include;
                    }
                }
                $terms = get_terms('product_cat', $args);
                if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){ ?>
                    <div class="we-cal-filter-cat">
                        <select name="product_cat">
                            <option value=""><?php echo get_option('we_text_evcat')!='' ? get_option('we_text_evcat') : esc_html__('All Categories','exthemes');?></option>
                            <?php 
                            foreach ( $terms as $term ) {
                                $selected = '';
                                if((isset($_GET['product_cat']) && $_GET['product_cat'] == $term->slug)){
                                    $selected ='selected';
                                }
                                echo '<option value="'. $term->slug .'" '.$selected.'>'. $term->name .'</option>';
                            }?>
                        </select>
                    </div>
            <?php }
            }
			if($tag_include!='hide'){
				$args = array( 'hide_empty' => false ); 
				if($tag_include!=''){
					$tag_include = explode(",", $tag_include);
					if(is_numeric($tag_include[0])){
						$args['include'] = $tag_include;
					}else{
						$args['slug'] = $tag_include;
					}
				}
				$terms = get_terms('product_tag', $args);
				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){ ?>
					<div class="we-filter-tag">
                        <select name="product_tag">
                            <option value=""><?php echo get_option('we_text_evtag')!='' ? get_option('we_text_evtag') : esc_html__('Tags','exthemes');?></option>
                            <?php 
							foreach ( $terms as $term ) {
								$selected = '';
								if((isset($_GET['product_tag']) && $_GET['product_tag'] == $term->slug)){
									$selected ='selected';
								}	
								echo '<option value="'. $term->slug .'" '.$selected.'>'. $term->name .'</option>';
							}
                              ?>
                        </select>
					</div>
			<?php } 
			}
			if($location_include!='hide'){
				if($location_include!=''){
					$ids = explode(",", $location_include);
				}else{ $ids = '';}
				$args = array(
					'post_type' => 'we_venue',
					'posts_per_page' => -1,
					'post_status' => 'publish',
					'post__in' =>  $ids,
					'ignore_sticky_posts' => 1,
				);
				$the_query = new WP_Query( $args );
				if($the_query->have_posts()){ ?>
					<div class="we-filter-loc">
                        <select name="product_loc">
                            <option value=""><?php echo get_option('we_text_loca')!='' ? get_option('we_text_loca') : esc_html__('Locations','exthemes');?></option>
                            <?php 
								while($the_query->have_posts()){ $the_query->the_post();
								  $selected = '';
								  if((isset($_GET['location']) && $_GET['location'] == get_the_ID())){
									  $selected ='selected';
								  }
								  echo '<option value="'. get_the_ID() .'" '.$selected.'>'. get_the_title() .'</option>';
                              }?>
                        </select>
					</div>
				<?php }
				wp_reset_postdata();
			}
			if($spk_include!='hide'){
				if($spk_include!=''){
					$ids = explode(",", $spk_include);
				}else{ $ids = '';}
				$args = array(
					'post_type' => 'ex-speaker',
					'posts_per_page' => -1,
					'post_status' => 'publish',
					'post__in' =>  $ids,
					'ignore_sticky_posts' => 1,
				);
				$the_query = new WP_Query( $args );
				if($the_query->have_posts()){ ?>
					<div class="we-filter-speaker">
                        <select name="product_spk">
                            <option value=""><?php echo get_option('we_text_speaker')!='' ? get_option('we_text_speaker') : esc_html__('Speakers','exthemes');?></option>
                            <?php 
								while($the_query->have_posts()){ $the_query->the_post();
								  $selected = '';
								  if((isset($_GET['speaker']) && $_GET['speaker'] == get_the_ID())){
									  $selected ='selected';
								  }
								  echo '<option value="'. get_the_ID() .'" '.$selected.'>'. get_the_title() .'</option>';
                              }?>
                        </select>
					</div>
				<?php }
				wp_reset_postdata();
			}
			?>
        </div>
        <div class="clearfix"></div>
        <?php
	}
}
// subtitle html
if(!function_exists('we_subtitle_html')){
	function we_subtitle_html($id=false,$return=false){
		if( get_option('we_enable_subtitle') != 'yes' ){ return;}
		if(isset($id) && is_numeric($id)){}else{ $id = get_the_ID();}
		$subtitle = get_post_meta($id,'we_subtitle',true);
		if($subtitle ==''){ return;}
        $html ='<div class="we-subtitle">
            <span>'.$subtitle.'</span>
        </div>';
		if(isset($return) && $return==true){
			return $html;
		}else{
			echo $html;
		}
			
		
	}
}
if(!function_exists('we_get_number_post_by_meta')){
	function we_get_number_post_by_meta($id){
		global $wpdb;
		$query = $wpdb->get_results($wpdb->prepare(
			"
			SELECT * 
			FROM {$wpdb->prefix}postmeta 
			WHERE meta_key = %s
			AND meta_value = %f
			",
			'we_default_venue',
			$id
		));
		return count($query);
	}
}
if(!function_exists('wpext_pagenavi')){
	function wpext_pagenavi($the_query,$idsc){
		if(function_exists('paginate_links')) {
			echo '<div class="we-ajax-pagination" data-id="'.$idsc.'" id="pag-'.rand(10,9999).'">';
			$args = array(
				'base'         => home_url( '/%_%' ),
				'format'       => '?paged=%#%',
				'add_args'     => '',
				'show_all'     => false,
				'current' => isset($_POST['page']) && $_POST['page']!='' ? $_POST['page'] : max( 1, get_query_var('paged') ),
				'total' => $the_query->max_num_pages,
				'prev_text'    => '&larr;',
				'next_text'    => '&rarr;',
				'type'         => 'list',
				'end_size'     => 2,
				'mid_size'     => 2
			);
			$args['add_args'] = array(
				'post_type' => 'product',
				's' => isset($_POST['key_word']) ? $_POST['key_word'] : '',
				'product_cat' => $_POST['cat'],
				'product_tag' => $_POST['tag'],
				'evyear' => $_POST['year'],
				'location' => $_POST['location']
			);
			echo paginate_links($args);
		}
	}
}
//ajax search shortcode new
add_action( 'wp_ajax_we_ajax_search', 'we_ajax_search_result' );
add_action( 'wp_ajax_nopriv_we_ajax_search', 'we_ajax_search_result' );
if(!function_exists('we_ajax_search_result')){
	function we_ajax_search_result(){
		$page = isset($_POST['page']) ? $_POST['page'] : '';
		global $posts_per_page,$count,$layout,$idsc;
		$idsc = isset($_POST['idsc']) ? $_POST['idsc'] : '';
		$layout = isset($_POST['layout']) ? $_POST['layout'] : '';
		$posts_per_page = 3;
		$count = 999;
		$args = array(
			'post_type' => 'product',
			'posts_per_page' => $posts_per_page,
			'post_status' => 'publish',
			's' => $_POST['key_word'],
			'ignore_sticky_posts' => 1,
		);
		$args['paged'] = $page;
		$cat = isset($_POST['cat']) && $_POST['cat']!='' ? $_POST['cat'] : '';
		$tag = isset($_POST['tag']) && $_POST['tag']!='' ? $_POST['tag'] : '';
		$year = isset($_POST['year']) && $_POST['year']!='' ? $_POST['year'] : '';
		if($year!=''){
			$year = explode(",",$year);
			$year = array_filter($year);
			sort($year);
			if(count($year)>1){
				$start = mktime(0, 0, 0, 1, 1, $year[0]);
				$end = mktime(0, 0, 0, 12, 31, end($year));
				$args ['meta_query']=  array( 
				   'relation' => 'AND',
					array('key'  => 'we_startdate',
						 'value' => $start,
						 'compare' => '>'),
					array('key'  => 'we_startdate',
						 'value' => $end,
						 'compare' => '<=')
				);
			}else if(!empty($year)){
				$year = date($year[0]);
				$start = mktime(0, 0, 0, 1, 1, $year);
				$end = mktime(0, 0, 0, 12, 31, $year);
				$args ['meta_query']=  array( 
				   'relation' => 'AND',
					array('key'  => 'we_startdate',
						 'value' => $start,
						 'compare' => '>'),
					array('key'  => 'we_startdate',
						 'value' => $end,
						 'compare' => '<=')
				);
			}
		}
		if($tag!=''){
			$texo['relation'] = 'AND';
			$tags = explode(",",$tag);
			if(is_numeric($tags[0])){$field_tag = 'term_id'; }
			else{ $field_tag = 'slug'; }
			if(count($tags)>1){
				  foreach($tags as $iterm) {
					  if($iterm!=''){
					  $texo[] = array(
							  'taxonomy' => 'product_tag',
							  'field' => $field_tag,
							  'terms' => $iterm,
						  );
					  }
				  }
			  }else{
				  if(!empty($tags)){
				  $texo[] = array(
						  'taxonomy' => 'product_tag',
						  'field' => $field_tag,
						  'terms' => $tags,
				  );
				  }
			}
		}
		if($cat!=''){
			$texo['relation'] = 'AND';
			$cats = explode(",",$cat);
			if(is_numeric($cats[0])){$field = 'term_id'; }
			else{ $field = 'slug'; }
			if(count($cats)>1){
				  foreach($cats as $iterm) {
					  if($iterm!=''){
					  $texo[] = array(
							  'taxonomy' => 'product_cat',
							  'field' => $field,
							  'terms' => $iterm,
						  );
					  }
				  }
			  }else{
				  if(!empty($cats)){
					  $texo[] = array(
								  'taxonomy' => 'product_cat',
								  'field' => $field,
								  'terms' => $cats,
					  );
				  }
			}
		}
		if( isset($_POST['location']) && $_POST['location']!='' ){
			$args ['meta_query'][]= 
				array(
				  'key' => 'we_default_venue',
				  'value' => array ($_POST['location']),
				  'compare' => 'IN',
			);
		}
		if(isset($texo)){
			$args += array('tax_query' => $texo);
		}
		$args = apply_filters( 'we_ajax_search_arg', $args );
		global $the_query;
		$the_query = new WP_Query( $args );
		$it = $the_query->post_count;
		ob_start();
		wooevent_template_plugin('search-ajax', true);
		$html = ob_get_clean();
		ob_end_clean();
		echo  $html;
		die;
	}
}
if(!function_exists('we_badget_html')){
	function we_badget_html (){
		global $product;
		$html = '';
		if ( $product->is_on_sale() ) {
			$html = '<span class="woocommerce-we-onsale">' . __( 'Sale!', 'woocommerce' ) . '</span>';
		}else if( $product->is_featured() ) {
			$html = '<span class="woocommerce-we-onsale we-featured">' . esc_html__( 'Featured', 'exthemes' ) . '</span>';
		}else {
			if(function_exists('wc_get_rating_html')){
				$rating_html = wc_get_rating_html($product->get_average_rating());
			}else{
				$rating_html = $product->get_rating_html();
			}
			if ( get_option( 'woocommerce_enable_review_rating' ) != 'no' && $rating_html!=''){
					$html = '<div class="woocommerce-we-onsale woocommerce">'.$rating_html.'</div>';
			}
		}
		return apply_filters( 'we_badget_html', $html, $product );
	}
}

