<?php
//User Submit Event
if(!function_exists('getUserIP')){
	function getUserIP(){
		$client  = @$_SERVER['HTTP_CLIENT_IP'];
		$forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
		$remote  = $_SERVER['REMOTE_ADDR'];
		if(filter_var($client, FILTER_VALIDATE_IP)){
			$ip = $client;
		}elseif(filter_var($forward, FILTER_VALIDATE_IP)){
			$ip = $forward;
		}else{
			$ip = $remote;
		}
		return $ip;
	}
}
if(!function_exists('we_event_submit_image')){
	function we_event_submit_image($submission,$cf_data,$key,$new_event,$set_thumb){
		$title_img = $cf_data[$key];
		$loc_img = $submission->uploaded_files();
		$loc_img = $loc_img[$key];
		$img = file_get_contents($loc_img);
		$upload_dir = wp_upload_dir(); 
		$upload = wp_upload_bits( $title_img, '', $img);
		$filename= $upload['file'];
		require_once(ABSPATH . 'wp-admin/includes/admin.php');
		$file_type = wp_check_filetype(basename($filename), null );
		$attachment = array(
		   'post_mime_type' => $file_type['type'],
		   'post_title' => preg_replace('/\.[^.]+$/', '', basename($filename)),
		   'post_content' => '',
		   'post_status' => 'inherit'
		);
		$attach_id = wp_insert_attachment( $attachment, $filename, $new_event);
		$attach_url = get_attached_file( $attach_id );
		if($set_thumb == 1){
			set_post_thumbnail( $new_event, $attach_id );
		}else{
			$product = wc_get_product( $new_event );
			$images = $product->get_gallery_image_ids();
			if(is_array($images)){ 
				array_push($images,$attach_id);
				$images = implode(",",$images);
			}else{
				$images = $attach_id;
			}
			update_post_meta( $new_event, '_product_image_gallery', $images);
		}
		$attach_data =  wp_generate_attachment_metadata( $attach_id, $attach_url );
		wp_update_attachment_metadata( $attach_id,  $attach_data );

	}
}

function we_usersubmit_hook_cf7($cf) {
	if(!class_exists('WPCF7_Submission')){
		return false;
	}
	$submission = WPCF7_Submission::get_instance();
	if($submission) {
		$cf_data = $submission->get_posted_data();
		if(isset($cf_data['we-startdate']) && isset($cf_data['we-enddate'])){
			$title = isset($cf_data['we-event-title'])?$cf_data['we-event-title']:'';
			$email = isset($cf_data['your-email'])?$cf_data['your-email']:'';
			$name = isset($cf_data['your-name'])?$cf_data['your-name']:'';
			$email_event = isset($cf_data['we-event-mail'])?$cf_data['we-event-mail']:'';
			$phone_event = isset($cf_data['we-event-phone'])?$cf_data['we-event-phone']:'';
			$url_event = isset($cf_data['we-event-url'])?$cf_data['we-event-url']:'';
			$tzone = isset($cf_data['we-event-tzone'])?$cf_data['we-event-tzone']:'';
			$location_event = isset($cf_data['we-event-location'])?$cf_data['we-event-location']:'';
			$content = isset($cf_data['we-event-details'])?$cf_data['we-event-details']:'';
			
			$event_recurrence = isset($cf_data['we-recurrence'])?$cf_data['we-recurrence']:'';
			$event_recurrence_end = isset($cf_data['we-recurr-enddate'])?$cf_data['we-recurr-enddate']:'';
			$event_color = isset($cf_data['we-event-color'])?$cf_data['we-event-color']:'';
			if($event_color!=''){ $event_color = '#'.$event_color;}
			$event_price = isset($cf_data['we-event-price'])?$cf_data['we-event-price']:'0';
			$event_stock = isset($cf_data['we-event-stock'])?$cf_data['we-event-stock']:'';
			$event_tag = isset($cf_data['we-event-tag'])?$cf_data['we-event-tag']:'';
			$event_tag = explode(",",$event_tag);
			$event_cat = isset($cf_data['we-event-cat'])?$cf_data['we-event-cat']:'';
			$event_schedu = isset($cf_data['we-event-schedule'])?$cf_data['we-event-schedule']:'';
			if($name==''){ $name = $email;}
			$title = apply_filters( 'we_event_submit_title', $title, $name);
			$event = array(
				'post_content'   => $content,
				'post_name' 	   => sanitize_title($title),
				'post_title'     => $title,
				'post_status'    => apply_filters( 'we_event_submit_status', 'pending'),
				'post_type'      => 'product'
			);
			$current_user = wp_get_current_user();
			if ( $current_user->exists() ) {
				$event['post_author'] = $current_user->ID;
			}
			if($new_event = wp_insert_post( $event, false )){
				
				$list_ids 			= get_user_meta(get_current_user_id(), '_my_submit', true);
				if(!$list_ids || !is_array($list_ids)) $list_ids = array();
				$list_ids = array_merge($list_ids, array($new_event));
				update_user_meta(get_current_user_id(), '_my_submit', $list_ids);
				if(get_option('we_sm_datefm') == 'dd/mm/yyyy'){
					$cf_data['we-startdate'] = str_replace('/', '-', $cf_data['we-startdate']);
					$cf_data['we-enddate'] = str_replace('/', '-', $cf_data['we-enddate']);
				}				
				$cf_data['we-starttime'] = str_replace(' ', '', $cf_data['we-starttime']);
				$cf_data['we-endtime'] = str_replace(' ', '', $cf_data['we-endtime']);
				add_post_meta( $new_event, 'we_startdate', strtotime($cf_data['we-startdate'].' '.$cf_data['we-starttime']) );
				add_post_meta( $new_event, 'we_enddate', strtotime($cf_data['we-enddate'].' '.$cf_data['we-endtime']));
				add_post_meta( $new_event, '_visibility', 'visible' );
				if(is_numeric($event_price)){
					add_post_meta( $new_event, '_regular_price', $event_price);
					add_post_meta( $new_event, '_price', $event_price);
				}
				add_post_meta( $new_event, '_stock_status', 'instock');
				if(is_numeric($event_stock)){
					add_post_meta($new_event, '_stock', $event_stock);
					add_post_meta($new_event, '_manage_stock', 'yes');
				}
				if($event_recurrence_end!='' && $event_recurrence!=''){
					add_post_meta( $new_event, 'we_recurrence_end', strtotime($event_recurrence_end) );
					add_post_meta( $new_event, 'we_recurrence', $event_recurrence );
				}
				add_post_meta( $new_event, 'we_eventcolor', $event_color);
				add_post_meta( $new_event, 'we_email_submit', $email);
				if($email!=''){
					$subject = esc_html__('Thank you for submitting your event','exthemes');
					$message = esc_html__('Thank you for submitting your event. We will notify you if the event is approved.','exthemes');
					wp_mail( $email, $subject, $message );
				}
				add_post_meta( $new_event, 'we_adress', $location_event);
				add_post_meta( $new_event, 'we_phone', $phone_event);
				add_post_meta( $new_event, 'we_email', $email_event);
				add_post_meta( $new_event, 'we_website', $url_event);
				add_post_meta( $new_event, 'we_time_zone', $tzone);
				wp_set_object_terms( $new_event, $event_cat, 'product_cat' );
				wp_set_object_terms( $new_event, $event_tag, 'product_tag' );
				if(isset($cf_data["we-event-image"]) && $cf_data["we-event-image"]!=''){
					we_event_submit_image($submission,$cf_data,'we-event-image',$new_event,1);
				}
				if( is_array($event_schedu)){
					foreach ($event_schedu as $schedu){
						add_post_meta( $new_event, 'we_schedu', $schedu);
					}
				}
				do_action('we_event_submit_meta_data',$submission,$cf_data,$new_event);
			}
		}else if(isset($cf_data['we-sp-title'])){
			$title = isset($cf_data['we-sp-title'])?$cf_data['we-sp-title']:'';
			$email = isset($cf_data['your-email'])?$cf_data['your-email']:'';
			$name = isset($cf_data['your-name'])?$cf_data['your-name']:'';
			$pos_sp = isset($cf_data['we-sp-pos'])?$cf_data['we-sp-pos']:'';
			
			$dribbble = isset($cf_data['we-sp-dribbble'])?$cf_data['we-sp-dribbble']:'';
			$envelope = isset($cf_data['we-sp-envelope'])?$cf_data['we-sp-envelope']:'';
			$facebook = isset($cf_data['we-sp-facebook'])?$cf_data['we-sp-facebook']:'';
			$flickr = isset($cf_data['we-sp-flickr'])?$cf_data['we-sp-flickr']:'';
			$google = isset($cf_data['we-sp-google-plus'])?$cf_data['we-sp-google-plus']:'';
			$instagram = isset($cf_data['we-sp-instagram'])?$cf_data['we-sp-instagram']:'';
			$linkedin = isset($cf_data['we-sp-linkedin'])?$cf_data['we-sp-linkedin']:'';
			$pinterest = isset($cf_data['we-sp-pinterest'])?$cf_data['we-sp-pinterest']:'';
			$tumblr = isset($cf_data['we-sp-tumblr'])?$cf_data['we-sp-tumblr']:'';
			$twitter = isset($cf_data['we-sp-twitter'])?$cf_data['we-sp-twitter']:'';
			$youtube = isset($cf_data['we-sp-youtube'])?$cf_data['we-sp-youtube']:'';
			$github = isset($cf_data['we-sp-github'])?$cf_data['we-sp-github']:'';
			$content = isset($cf_data['we-sp-details'])?$cf_data['we-sp-details']:'';
			$speaker = array(
				'post_content'   => $content,
				'post_name' 	   => sanitize_title($title),
				'post_title'     => $title,
				'post_status'    => apply_filters( 'we_speaker_submit_status', 'pending'),
				'post_type'      => 'ex-speaker'
			);
			if($new_speaker = wp_insert_post( $speaker, false )){
				add_post_meta( $new_speaker, 'dribbble', $dribbble);
				add_post_meta( $new_speaker, 'envelope', $envelope);
				add_post_meta( $new_speaker, 'facebook', $facebook);
				add_post_meta( $new_speaker, 'google-plus', $google);
				add_post_meta( $new_speaker, 'instagram', $instagram);
				add_post_meta( $new_speaker, 'linkedin', $linkedin);
				
				add_post_meta( $new_speaker, 'pinterest', $pinterest);
				add_post_meta( $new_speaker, 'tumblr', $tumblr);
				add_post_meta( $new_speaker, 'twitter', $twitter);
				add_post_meta( $new_speaker, 'youtube', $youtube);
				add_post_meta( $new_speaker, 'github', $github);
				add_post_meta( $new_speaker, 'speaker_position', $pos_sp);
				if(!is_user_logged_in()){
					add_post_meta( $new_speaker, 'ip_submit', getUserIP());
				}
				if(isset($cf_data["we-sp-image"]) && $cf_data["we-sp-image"]!=''){
					$title_img = $cf_data["we-sp-image"];
					$loc_img = $submission->uploaded_files();
					$loc_img = $loc_img["we-sp-image"];
					$img = file_get_contents($loc_img);
					$upload_dir = wp_upload_dir(); 
					$upload = wp_upload_bits( $title_img, '', $img);
					$filename= $upload['file'];
					require_once(ABSPATH . 'wp-admin/includes/admin.php');
					$file_type = wp_check_filetype(basename($filename), null );
					  $attachment = array(
					   'post_mime_type' => $file_type['type'],
					   'post_title' => preg_replace('/\.[^.]+$/', '', basename($filename)),
					   'post_content' => '',
					   'post_status' => 'inherit'
					);
					$attach_id = wp_insert_attachment( $attachment, $filename, $new_speaker);
					//$attach_url = wp_get_attachment_url( $attach_id );
					$attach_url = get_attached_file( $attach_id );
					set_post_thumbnail( $new_speaker, $attach_id );
					$attach_data =  wp_generate_attachment_metadata( $attach_id, $attach_url );
					wp_update_attachment_metadata( $attach_id,  $attach_data );
				}
			}
		}
	}
}
// email notification
add_action( 'save_post', 'we_notify_submit');
function we_notify_submit( $post_id ) {
	if ( wp_is_post_revision( $post_id ) || get_option('we_sm_notify')!='1' ){
		return;
	}
	$email = get_post_meta($post_id,'we_email_submit',true);
	if($email!='' && get_post_status($post_id)=='publish'){
		$subject = esc_html__('Your event submission has been approved','exthemes');
		$message = esc_html__('Your event has been approved. You can see it here','exthemes').' '.get_permalink($post_id);
		wp_mail( $email, $subject, $message );
		update_post_meta( $post_id, 'we_email_submit', '');
	}
}
add_action('wp_trash_post','we_trash_post_function');
function we_trash_post_function($post_id){
	$email = get_post_meta($post_id,'we_email_submit',true);
	if($email!='' && get_option('we_sm_notify')=='1'){
		$subject = esc_html__('Your submission has been canceled','exthemes');
		$message = esc_html__('Sorry, but the event you submitted did not get approved. ','exthemes');
		wp_mail( $email, $subject, $message );
	}
}
add_action("wpcf7_before_send_mail", "we_usersubmit_hook_cf7");
function we_time_cf7_field($tag){
	/*$output = '
	<input type="text"  name="'.$tag['name'].'" id="'.$tag['name'].'" class="time submit-time" placeholder="'.esc_html__('H:i','exthemes').'">';
	return $output;*/
	
	$tag = new WPCF7_FormTag( $tag );

	if ( empty( $tag->name ) ) { return ''; }

	$validation_error = wpcf7_get_validation_error( $tag->name );

	$class = wpcf7_form_controls_class( $tag->type, 'wpcf7-text' );

	if ( $validation_error ) {
		$class .= ' wpcf7-not-valid';
	}
	$class .= ' time submit-time ';

	$atts = array();
	$atts['class'] = $tag->get_class_option( $class );
	$atts['id'] = $tag->get_id_option();
	$atts['placeholder'] = esc_html__('H:i','exthemes');
	if ( $tag->is_required() ) { $atts['aria-required'] = 'true'; }

	$atts['aria-invalid'] = $validation_error ? 'true' : 'false';

	$atts['type'] = 'text';

	$atts['name'] = $tag->name;

	$atts = wpcf7_format_atts( $atts );

	$html = sprintf(
		'<span class="wpcf7-form-control-wrap %1$s"><input %2$s />%3$s</span>',
		sanitize_html_class( $tag->name ), $atts, $validation_error );

	ob_start();
	wp_enqueue_style('we-jquery.timepicker', WOO_EVENT_PATH.'js/jquery-timepicker/jquery.timepicker.css');
	wp_enqueue_script( 'we-jquery.timepicker', WOO_EVENT_PATH.'js/jquery-timepicker/jquery.timepicker.min.js', array( 'jquery' ) );
	$js_string = ob_get_contents();
	ob_end_clean();
	return $html.$js_string;
}
function we_time_cf7_shortcode(){
	if(function_exists('wpcf7_add_form_tag')){
		wpcf7_add_form_tag(array('we_time','we_time*'), 'we_time_cf7_field', true);
	}
}
add_action( 'init', 'we_time_cf7_shortcode' );
// submit date
function we_date_cf7_field($tag){
	/*$output = '
	<input type="text"  name="'.$tag['name'].'" id="'.$tag['name'].'" class="date submit-date wpcf7-validates-as-required" aria-required="true" placeholder="">';
	return $output;
	*/
	$tag = new WPCF7_FormTag( $tag );

	if ( empty( $tag->name ) ) { return ''; }

	$validation_error = wpcf7_get_validation_error( $tag->name );

	$class = wpcf7_form_controls_class( $tag->type, 'wpcf7-text' );

	if ( $validation_error ) {
		$class .= ' wpcf7-not-valid';
	}
	$class .= ' date submit-date ';

	$atts = array();
	$atts['class'] = $tag->get_class_option( $class );
	$atts['id'] = $tag->get_id_option();

	if ( $tag->is_required() ) { $atts['aria-required'] = 'true'; }

	$atts['aria-invalid'] = $validation_error ? 'true' : 'false';

	$atts['type'] = 'text';

	$atts['name'] = $tag->name;

	$atts = wpcf7_format_atts( $atts );
	$tfm = get_option('we_sm_timefm')!='' ? get_option('we_sm_timefm') : 'h:i A';
	$html = sprintf(
		'<span class="wpcf7-form-control-wrap %1$s"><input %2$s />%3$s <input type="hidden" class="wedate_format" value="'.get_option('we_sm_datefm').'"/><input type="hidden" class="wetime_format" value="'.$tfm.'"/></span>',
		sanitize_html_class( $tag->name ), $atts, $validation_error );
	ob_start();
	wp_enqueue_style('we-bootstrap-datepicker', WOO_EVENT_PATH.'js/jquery-timepicker/lib/bootstrap-datepicker.css');
	wp_enqueue_script( 'we-bootstrap-datepicker', WOO_EVENT_PATH.'js/jquery-timepicker/lib/bootstrap-datepicker.js', array( 'jquery' ) );
	if(get_option('we_jscolor_js')!='on'){
		wp_enqueue_script( 'we-color-picker', WOO_EVENT_PATH. 'js/jscolor.min.js', array('jquery'), '2.0', true );
	}
	$js_string = ob_get_contents();
	ob_end_clean();
	return $html.$js_string;
		
}
add_filter( 'wpcf7_validate_we_date', 'wpcf7_we_date_validation_filter', 10, 2 );
add_filter( 'wpcf7_validate_we_date*', 'wpcf7_we_date_validation_filter', 10, 2 );
add_filter( 'wpcf7_validate_we_time', 'wpcf7_we_date_validation_filter', 10, 2 );
add_filter( 'wpcf7_validate_we_time*', 'wpcf7_we_date_validation_filter', 10, 2 );

function wpcf7_we_date_validation_filter( $result, $tag ) {
	$tag = new WPCF7_FormTag( $tag );

	$name = $tag->name;
	$value = isset( $_POST[$name] )
		? trim( strtr( (string) $_POST[$name], "\n", " " ) )
		: '';

	if ( $tag->is_required() && '' == $value ) {
		$result->invalidate( $tag, wpcf7_get_message( 'invalid_required' ) );
	}
	return $result;
}




function we_date_cf7_shortcode(){
	if(function_exists('wpcf7_add_form_tag')){
		wpcf7_add_form_tag(array('we_date','we_date*'), 'we_date_cf7_field', true);
	}
}
add_action( 'init', 'we_date_cf7_shortcode' );
// submit recurrence
function we_recurr_cf7_field($tag){
	$output = '
	<select name="'.$tag['name'].'" id="'.$tag['name'].'" class="recurrence submit-recurrence">
		<option value="">'.esc_html__('None','exthemes').'</option>
		<option value="day">'.esc_html__('Every Day','exthemes').'</option>
		<option value="week">'.esc_html__('Every Week','exthemes').'</option>
		<option value="month">'.esc_html__('Every Month','exthemes').'</option>
	</select>';
	return $output;
}
function we_recurr_cf7_shortcode(){
	if(function_exists('wpcf7_add_form_tag')){
		wpcf7_add_form_tag(array('we_recurrence','we_recurrence*'), 'we_recurr_cf7_field', true);
	}
}
add_action( 'init', 'we_recurr_cf7_shortcode' );
// submit category
function we_cat_shortcode(){
	if(function_exists('wpcf7_add_form_tag')){
		wpcf7_add_form_tag(array('we_category','we_category*'), 'we_cathtml', true);
	}
}
function we_cathtml($tag){
	$class = '';
	$is_required = 0;
	if(class_exists('WPCF7_FormTag')){
		$tag = new WPCF7_FormTag( $tag );
		if ( $tag->is_required() ){
			$is_required = 1;
			$class .= ' required-cat';
		}
	}
	$cat_exclude = get_option('we_sm_cat');
	$cat_include = get_option('we_sm_cat_in');
	$cargs = array(
		'hide_empty'    => false, 
		'exclude'       => explode(",",$cat_exclude),
		'include'       => explode(",",$cat_include)
	); 
	$cats = get_terms( 'product_cat', $cargs );
	$output = '';
	if($cats){
		$output = '<div class="wpcf7-form-control-wrap event-cat"><div class="row wpcf7-form-control wpcf7-checkbox wpcf7-validates-as-required'.$class.'">';
		foreach ($cats as $acat){
			$output .= '
			<label class="col-md-4 wpcf7-list-item">
				<input type="checkbox" name="we-event-cat[]" value="'.$acat->slug.'" /> '.$acat->name.'
			</label>';
		}
		$output .= '</div>';
	}
	ob_start();
	if($is_required){
		?>
		<script>
		jQuery(document).ready(function(e) {
			jQuery('.we-submit .wpcf7-submit').on('click', function (e) {
				var checked = 0;
				var namecat = '';
				jQuery.each(jQuery("input[name='we-event-cat[]']:checked"), function() {
					checked = jQuery(this).val();
					if(namecat!=''){
						namecat = namecat+', '+jQuery(this).closest('label' ).text();
					}else{
						namecat = jQuery(this).closest('label' ).text();
					}
				});
				if(jQuery("form.wpcf7-form input[name='we-event-cname']").length){
					jQuery(this).val(namecat);
				}
				if(checked == 0){
					if(jQuery('.cat-alert').length==0){
						jQuery('.wpcf7-form-control-wrap.event-cat').append('<span role="alert" class="wpcf7-not-valid-tip cat-alert"><?php echo wpcf7_get_message( 'invalid_required' ); ?></span>');
					}
					e.preventDefault();
					return false;
				}else{
					return true;
				}
			});
		});
		</script>
		<?php
	}
	?>
    <script>
	jQuery(document).ready(function(e) {
		jQuery("form.wpcf7-form").submit(function (e) {
			if(jQuery("form.wpcf7-form input[name='we-event-cname']").length){
				var namecat = '';
				jQuery.each(jQuery("input[name='we-event-cat[]']:checked"), function() {
					if(jQuery(this).closest('label' ).text()!=''){
						if(namecat!=''){
							namecat = namecat+', '+jQuery(this).closest('label' ).text();
						}else{
							namecat = jQuery(this).closest('label' ).text();
						}
					}
				});
				jQuery("form.wpcf7-form input[name='we-event-cname']").val(namecat);
			}
			return true;
		});
	});
	</script>
    <?php
	$js_string = ob_get_contents();
	ob_end_clean();
	return $output.$js_string;
}
add_action( 'init', 'we_cat_shortcode' );

function we_speakerhtml($tag){
	$is_required = 0;
	if(class_exists('WPCF7_FormTag')){
		$tag = new WPCF7_FormTag( $tag );
		if ( $tag->is_required() ){
			$is_required = 1;
		}
	}
	$cat_exclude = get_option('we_sm_cat');
	$args = array(
		'post_type' => 'ex-speaker',
		'posts_per_page' => -1,
		'post_status' => array( 'pending', 'publish'),
 		'meta_key' => $meta_key,
		'ignore_sticky_posts' => 1,
	);
	if(is_user_logged_in()){
		$args['author'] = get_current_user_id();
	}else{
		$args['meta_key'] = 'ip_submit';
		$args['meta_value'] = getUserIP();
		
	}
	$postlist = get_posts($args);
	$output = '<div class="wpcf7-form-control-wrap event-speaker"><div class="row wpcf7-form-control wpcf7-checkbox wpcf7-validates-as-required">';
	$url= isset($tag->options) ? $tag->options : '';
	if(isset($url[0]) ){
		$output .= '<p class="col-md-12"><a href="'.$url[0].'">'.esc_html__('Submit new speaker','exthemes').'</a></p>';
	}
	if($postlist){
		foreach ( $postlist as $post ) {
			$output .= '
			<label class="col-md-4 wpcf7-list-item">
				<input type="checkbox" name="we-event-speaker[]" value="'.$post->ID.'" /> '.get_the_title( $post->ID ).'
			</label>';
		}
	}
	$output .= '</div>';
	ob_start();
	if($is_required){?>
    <script>
	jQuery(document).ready(function(e) {
		jQuery('.we-submit .wpcf7-submit').on('click', function (e) {
			var checked = 0;
			jQuery.each(jQuery("input[name='we-event-speaker[]']:checked"), function() {
				checked = jQuery(this).val();
			});
			if(checked == 0){
				if(jQuery('.sp-alert').length==0){
					jQuery('.wpcf7-form-control-wrap.event-speaker').append('<span role="alert" class="wpcf7-not-valid-tip sp-alert"><?php echo wpcf7_get_message( 'invalid_required' ); ?></span>');
				}
				return false;
			}else{
				return true;
			}
		});
	});
	</script>
	<?php
	}
	$js_string = ob_get_contents();
	ob_end_clean();
	return $output.$js_string;
}
function we_speaker_shortcode(){
	if(function_exists('wpcf7_add_form_tag')){
		wpcf7_add_form_tag(array('we_speaker','we_speaker*'), 'we_speakerhtml', true);
	}
}
add_action( 'init', 'we_speaker_shortcode' );
// submit schedule
function we_scheduler_cf7_field($tag){
	$output = '
	<button name="'.$tag['name'].'" id="'.$tag['name'].'" class="submit-schedule">'.esc_html__('+ Add New','exthemes').'</button>';
	ob_start();
	?>
    <script>
	jQuery(document).ready(function(e) {
		jQuery("#<?php echo esc_attr($tag['name']);?>").on('click', function(e) {
			jQuery(this).before( '<input type="text" name="we-event-schedule[]" value="" />' );
		});
	});
	</script>
    <?php
	$js_string = ob_get_contents();
	ob_end_clean();
	return $output.$js_string;
}
function we_schedule_cf7_shortcode(){
	if(function_exists('wpcf7_add_form_tag')){
		wpcf7_add_form_tag(array('we_schedule','we_schedule*'), 'we_scheduler_cf7_field', true);
	}
}
add_action( 'init', 'we_schedule_cf7_shortcode' );
// Submit Venue
function we_venue_submit_html($tag){
	$is_required = 0;
	if(class_exists('WPCF7_FormTag')){
		$tag = new WPCF7_FormTag( $tag );
		if ( $tag->is_required() ){
			$is_required = 1;
		}
	}
	$args = array(
		'post_type' => 'we_venue',
		'posts_per_page' => -1,
		'post_status' => array('publish'),
		'ignore_sticky_posts' => 1,
	);
	$postlist = get_posts($args);
	$output = '';
	if($postlist){
		$output .= '
		<span class="wpcf7-form-control-wrap we-event-venue wpcf7-not-valid">
			<select name="we-event-venue">
			<option value="" />'.esc_html__('None','exthemes').'</option>';
		foreach ( $postlist as $post ) {
			$output .= '<option value="'.$post->ID.'" /> '.get_the_title( $post->ID ).'</option>';
		}
		$output .= '
			</select>
		</span>';
	}
	$output .= '';
	ob_start();
	if($is_required){?>
    <script>
	jQuery(document).ready(function(e) {
		jQuery('.we-submit .wpcf7-submit').on('click', function (e) {
			var value = 0;
			jQuery.each(jQuery("select[name='we-event-venue'] option"), function() {
				if(jQuery(this).is(':selected')){
					value = jQuery(this).val() !='' ? jQuery(this).val() : 0;
				}
			});
			if(value == 0){
				if(!jQuery('.sp-alert').length){
					jQuery('.wpcf7-form-control-wrap.we-event-venue').append('<span role="alert" class="wpcf7-not-valid-tip sp-alert"><?php echo wpcf7_get_message( 'invalid_required' ); ?></span>');
				}
				e.preventDefault();
				return false;
			}else{
				return true;
			}
		});
	});
	</script>
	<?php
	}
	$js_string = ob_get_contents();
	ob_end_clean();
	return $output.$js_string;
}
function we_venuesm_shortcode(){
	if(function_exists('wpcf7_add_form_tag')){
		wpcf7_add_form_tag(array('we_venue','we_venue*'), 'we_venue_submit_html', true);
	}
}
add_action( 'init', 'we_venuesm_shortcode' );
