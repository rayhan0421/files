;(function($){
	$(document).ready(function() {
		$(document).on('click', 'a.clear-ev', function(e){
			if(!confirm($(this).data('confirm'))){
				e.stopImmediatePropagation();
				e.preventDefault();
			}
		});
		if(jQuery("#we_allday input").prop('checked')){
			jQuery('#we_startdate .exc_mb_timepicker').css('display', 'none');
			jQuery('#we_enddate .exc_mb_timepicker').css('display', 'none');
		}
		jQuery("#we_allday input").click(function(){
			if(jQuery('#we_allday input').prop('checked')){			
				jQuery('#we_startdate .exc_mb_timepicker').css('display', 'none');
				jQuery('#we_enddate .exc_mb_timepicker').css('display', 'none');
			}else{
				jQuery('#we_startdate .exc_mb_timepicker').css('display', 'inline');
				jQuery('#we_enddate .exc_mb_timepicker').css('display', 'inline');
			}
		});
		jQuery('#we_startdate #we_startdate-exc_mb-field-0-date').change(function() {
			jQuery('#we_enddate #we_enddate-exc_mb-field-0-date').val(this.value);
		});
		
		jQuery(document).on('change', '#we_ct_stdate .field-item .exc_mb_datepicker:first-child', function() {
			fieldItem = jQuery(this).closest('.we_ct_allday' );
			jQuery('#we_ct_edate_end .field-item .exc_mb_datepicker:first-child', fieldItem).val(this.value);
		});
		jQuery(document).on('click','#we_ct_allday input',function(){
			fieldItem = jQuery(this).closest('.we_ct_allday' );
			if(jQuery(this).prop('checked')){
				jQuery('.field-item .exc_mb_timepicker:last-child', fieldItem).css('display', 'none');
			}else{
				jQuery('.field-item .exc_mb_timepicker:last-child', fieldItem).css('display', 'inline');
			}
		});
		if(jQuery('#we_ct_allday').length){
			jQuery('#we_ct_allday input').each(function(){
				if(jQuery(this).prop('checked')){
					fieldItem = jQuery(this).closest('.we_ct_allday' );
					jQuery('.field-item .exc_mb_timepicker:last-child', fieldItem).css('display', 'none');
				}
			});
		}
		
		
		var we_layout_purpose_obj  = jQuery('.postbox-container #we_layout_purpose select');
		var we_layout_purpose = jQuery('.postbox-container #we_layout_purpose select').val();
		var we_event_settings = jQuery('#event-settings.postbox');
		var we_location_settings = jQuery('#location-settings.postbox');
		
		var we_custom_field = jQuery('.post-type-product .postbox-container #custom-field.postbox');
		var we_sponsor = jQuery('.post-type-product .postbox-container #sponsors-of-event.postbox');
		var we_layout_set = jQuery('.post-type-product .postbox-container #layout-settings.postbox');
		if(typeof(we_layout_purpose)!='undefined'){
			if(we_layout_purpose == 'event'){
				we_event_settings.show();
				we_event_settings.addClass('active-c');
				
				we_location_settings.show();
				we_location_settings.addClass('active-c');
				
				we_custom_field.show();
				we_custom_field.addClass('active-c');
				
				we_sponsor.show();
				we_sponsor.addClass('active-c');
				
				we_layout_set.show();
				we_layout_set.addClass();
			}else if(we_layout_purpose == 'woo'){
				we_event_settings.hide();
				we_event_settings.removeClass('active-c');
				
				we_location_settings.hide();
				we_location_settings.removeClass('active-c');
				
				we_custom_field.hide();
				we_custom_field.removeClass('active-c');
				
				we_sponsor.hide();
				we_sponsor.removeClass('active-c');
				
				we_layout_set.hide();
				we_layout_set.removeClass('active-c');
			}
			we_layout_purpose_obj.change(function(event) {
				if(jQuery(this).val() == 'event'){
					we_event_settings.show(200);
					we_event_settings.addClass('active-c');
					
					we_location_settings.show(200);
					we_location_settings.addClass('active-c');
					
					we_custom_field.show();
					we_custom_field.addClass('active-c');
					
					we_sponsor.show();
					we_sponsor.addClass('active-c');
					
					we_layout_set.show();
					we_layout_set.addClass('active-c');
				}else if(jQuery(this).val() == 'woo'){
					we_event_settings.hide(200);
					we_event_settings.removeClass('active-c');
					
					we_location_settings.hide(200);
					we_location_settings.removeClass('active-c');
					
					we_custom_field.hide();
					we_custom_field.removeClass('active-c');
					
					we_sponsor.hide();
					we_sponsor.removeClass('active-c');
					
					we_layout_set.hide();
					we_layout_set.removeClass('active-c');
				}else if(jQuery(this).val() == 'def'){
					we_event_settings.css("display","");
					we_location_settings.css("display","");
					
					we_custom_field.css("display","");
					we_sponsor.css("display","");
					we_layout_set.css("display","");
					
					we_event_settings.removeClass('active-c');
					we_location_settings.removeClass('active-c');
					we_custom_field.removeClass('active-c');
					we_sponsor.removeClass('active-c');
					we_layout_set.removeClass('active-c');
					
				}
			});
		}
		/*--recurrence select--*/
		var we_recurrence = jQuery('.postbox-container #we_recurrence select').val();
		var we_frequency = jQuery('.post-type-product .postbox-container .we_frequency');
		var we_ctdate = jQuery('.post-type-product .postbox-container .we_ctdate');
		var we_frequency_sl = jQuery('.post-type-product #we_frequency select').val();
		
		var we_every_x = jQuery('.post-type-product .postbox-container #we_every_x');
		var we_weekday = jQuery('.post-type-product .postbox-container #we_weekday');
		var we_monthday = jQuery('.post-type-product .postbox-container #we_monthday');
		var we_mweekday = jQuery('.post-type-product .postbox-container #we_mweekday');
		
		var we_monthday_sl = jQuery('.post-type-product #we_monthday select').val();
		if(typeof(we_recurrence)!='undefined'){
			if(we_recurrence=='custom'){
				we_frequency.show(200);
				we_ctdate.show(200);
				if(we_frequency_sl=='ct_date'){ 
					we_ctdate.show(200);
					we_every_x.hide(200);
					we_weekday.hide(200);
					we_monthday.hide(200);
					we_mweekday.hide(200);
				}else{ 
					we_ctdate.hide(200);
					if(we_frequency_sl=='daily'){
						we_every_x.show(200);
						we_weekday.hide(200);
						we_monthday.hide(200);
						we_mweekday.hide(200);
					}else if(we_frequency_sl=='week'){
						we_every_x.show(200);
						we_weekday.show(200);
						we_monthday.hide(200);
						we_mweekday.hide(200);
					}else if(we_frequency_sl=='month'){
						we_weekday.hide(200);
						we_monthday.show(200);
						if(we_monthday_sl=='first' || we_monthday_sl=='second' || we_monthday_sl=='third' || we_monthday_sl=='fourth' || we_monthday_sl=='fifth' || we_monthday_sl=='last'){
							we_mweekday.show(200);
						}else{ we_mweekday.hide(200);}
					}
				}
			}else {
				we_frequency.hide(200);
				we_ctdate.hide(200);
			}
		}
		jQuery('.postbox-container #we_recurrence select').change(function(event) {
			if(jQuery(this).val() == 'custom'){
				we_frequency.show(200);
				we_ctdate.show(200);
				if(we_frequency_sl=='ct_date'){ 
					we_ctdate.show(200);
					we_every_x.hide(200);
					we_weekday.hide(200);
					we_monthday.hide(200);
					we_weekday.hide(200);
				}else{ 
					we_ctdate.hide(200);
					if(we_frequency_sl=='daily'){
						we_every_x.show(200);
						we_weekday.hide(200);
						we_monthday.hide(200);
						we_mweekday.hide(200);
					}else if(we_frequency_sl=='week'){
						we_every_x.show(200);
						we_weekday.show(200);
						we_monthday.hide(200);
						we_mweekday.hide(200);
					}else if(we_frequency_sl=='month'){
						we_weekday.hide(200);
						we_monthday.show(200);
						if(we_monthday_sl=='first' || we_monthday_sl=='second' || we_monthday_sl=='third' || we_monthday_sl=='fourth' || we_monthday_sl=='fifth' || we_monthday_sl=='last'){
							we_mweekday.show(200);
						}else{ we_mweekday.hide(200);}
					}
				}
			}else {
				we_frequency.hide(200);
				we_ctdate.hide(200);
			}
		});
		jQuery('.post-type-product #we_frequency select').change(function(event) {
			var we_frequency_ch = jQuery(this).val();
			if(we_frequency_ch=='ct_date'){ 
				we_ctdate.show(200);
				we_every_x.hide(200);
				we_weekday.hide(200);
				we_monthday.hide(200);
				we_mweekday.hide(200);
			}else{ 
				we_ctdate.hide(200);
				we_every_x.show(200);
				if(we_frequency_ch=='daily'){
					we_weekday.hide(200);
					we_monthday.hide(200);
					we_mweekday.hide(200);
				}else if(we_frequency_ch=='week'){
					we_weekday.show(200);
					we_monthday.hide(200);
					we_mweekday.hide(200);
				}else if(we_frequency_ch=='month'){
					we_weekday.hide(200);
					we_monthday.show(200);
					if(we_monthday_sl=='first' || we_monthday_sl=='second' || we_monthday_sl=='third' || we_monthday_sl=='fourth' || we_monthday_sl=='fifth' || we_monthday_sl=='last'){
						we_mweekday.show(200);
					}else{ we_mweekday.hide(200);}
				}
			}
		});
		jQuery('.post-type-product #we_monthday select').change(function(event) {
			var we_monthday_ch = jQuery(this).val();
			if(we_monthday_ch=='first' || we_monthday_ch=='second' || we_monthday_ch=='third' || we_monthday_ch=='fourth' || we_monthday_ch=='fifth' || we_monthday_ch=='last'){
				we_mweekday.show(200);
			}else{ we_mweekday.hide(200);}
		});
		/*- Default venue -*/
		jQuery('.postbox-container #we_default_venue #we_default_venue-exc_mb-field-0').change(function() {
			$('#location-settings').addClass('loading');
			if(!$('#location-settings .wpex-loading').length){
				$('#location-settings').prepend('<div class="wpex-loading"><div class="wpex-spinner"><div class="rect1"></div><div class="rect2"></div><div class="rect3"></div><div class="rect4"></div><div class="rect5"></div></div></div>');
			}
			var valu = jQuery(this).val();
           	var param = {
	   			action: 'we_add_venue',
				value: valu
	   		};
	   		$.ajax({
	   			type: "post",
	   			url: woo_events.ajaxurl,
	   			dataType: 'json',
	   			data: (param),
	   			success: function(data){
					if(data != '0')
					{
						$('#location-settings #we_adress .field-item > input').val(data.we_adress);
						$('#location-settings #we_latitude_longitude .field-item > input').val(data.we_latitude_longitude);
						$('#location-settings #we_phone .field-item > input').val(data.we_phone);
						$('#location-settings #we_email .field-item > input').val(data.we_email);
						$('#location-settings #we_website .field-item > input').val(data.we_website);
					}
					$('#location-settings').removeClass('loading');
	   				return true;
	   			}	
	   		});
		});
		jQuery("#bulk-update-venue").on('click', function() {
			var $this = jQuery(this);
			$this.addClass('loading');
			var $id = $this.data('id');
			var param = {
	   			action: 'we_update_events_venue',
				id: $id
	   		};
	   		$.ajax({
	   			type: "post",
	   			url: woo_events.ajaxurl,
	   			dataType: 'json',
	   			data: (param),
	   			success: function(data){
					if(data != '0')
					{
						
					}
					$this.removeClass('loading');
	   				return true;
	   			}	
	   		});
		});
	
	});
}(jQuery));

function initialize() {
	var input = document.getElementById('we_adress-exc_mb-field-0');
	if(input!=null){
		var autocomplete = new google.maps.places.Autocomplete(input);
		google.maps.event.addListener(autocomplete, 'place_changed', function () {
            var place = autocomplete.getPlace();
			if(place.geometry.location.lat()!='' && place.geometry.location.lng()!=''){
				document.getElementById('we_latitude_longitude-exc_mb-field-0').value = place.geometry.location.lat()+', '+place.geometry.location.lng();
			}

        });
	}
}
if (typeof google !== 'undefined' && google.maps.event.addDomListener) {
	google.maps.event.addDomListener(window, 'load', initialize);
};