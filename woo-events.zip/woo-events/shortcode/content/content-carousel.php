<?php
$we_startdate = get_post_meta( get_the_ID(), 'we_startdate', true );
$we_enddate = get_post_meta( get_the_ID(), 'we_enddate', true )  ;
global $img_size,$show_time,$style,$number_excerpt;
global $product;
$type = $product->get_type();
$price ='';
if($type=='variable'){
	$price = we_variable_price_html();
}else{
	if ( $price_html = $product->get_price_html() ) :
		$price = $price_html; 
	endif; 	
}
global $img_size;
$we_adress = get_post_meta( get_the_ID(), 'we_adress', true );
$we_status = woo_event_status( get_the_ID(), $we_enddate);
if(get_option('we_dis_status') =='yes'){ $we_status ='';}
$we_eventcolor = we_event_custom_color(get_the_ID());
if($we_eventcolor==''){$we_eventcolor = we_autochange_color();}
$bgev_color = '';
if($we_eventcolor!=""){
	$bgev_color = 'style="background-color:'.$we_eventcolor.'"';
}
$html_baget = we_badget_html();
?>
<div class="item-post-n">
	<figure class="ex-modern-blog">
		<div class="image">
        	<?php echo ex_cat_info('','product', '', true);?>
        	<a href="<?php the_permalink(); ?>" class="link-more">
				<?php the_post_thumbnail($img_size);?>
            </a>
            <?php echo $html_baget;?>
		</div>
		<div class="grid-content <?php if($html_baget!=''){ echo 'gr-withbg';}?>">
			<figcaption>
            	<?php if($we_startdate!=''){?>
				<div class="date" <?php echo $bgev_color;?>><span class="day"><?php echo date_i18n( 'd', $we_startdate); ?></span><span class="month"><?php echo date_i18n('M', $we_startdate); ?></span></div>
                <?php }
				if($style == 'we-car-modern'){?>
                	<div class="we-ca-title">
						<h3><a href="<?php the_permalink(); ?>" class="link-more"><?php the_title();?></a></h3>
                        <?php we_subtitle_html();?>
                        <?php
                        if($we_startdate!=''){ 
							$sttime = '';
							if($show_time=='1'){
								$sttime = ' - '.date_i18n(get_option('time_format'), $we_startdate);
							}
							echo '<span>'.date_i18n( get_option('date_format'), $we_startdate).$sttime.'</span>';
						}
						?>
                    </div>
                <?php }else{?>
                	<h3><a href="<?php the_permalink(); ?>" class="link-more"><?php the_title();?></a></h3>
                    <?php we_subtitle_html();?>
                <?php }?>
				<div class="we-more-meta">
				<?php
					if($we_startdate!='' && $style != 'we-car-modern'){ 
						$sttime = '';
						if($show_time=='1'){
							$sttime = ' - '.date_i18n(get_option('time_format'), $we_startdate);
						}
						echo '<span><i class="fa fa-calendar"></i>'.date_i18n( get_option('date_format'), $we_startdate).$sttime.'</span>';
					}
					if($we_adress!='' && $style == 'we-car-modern'){?>
				  		<span class="tb-meta"><i class="fa fa-map-marker"></i> <?php echo $we_adress;?></span>
			  		<?php }
					if($price!=''){
						echo  '<span><i class="fa fa-shopping-basket"></i>'.$price.'</span>';
					}
					if($we_status!=''){
						echo '
						<span>
							<i class="fa fa-ticket"></i>
							'.$we_status.'
						</span>';
					}
				?>
				</div>
                <?php if($number_excerpt!='0'){?>
				<div class="grid-excerpt"><?php echo wp_trim_words($number_excerpt,$more = '...');?></div>
                <?php }?>
			</figcaption>
		</div>
	</figure>    
</div>