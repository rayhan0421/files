<?php
function parse_we_venue_func($atts, $content){
	if(is_admin()){ return;}
	$ID = isset($atts['ID']) ? $atts['ID'] : rand(10,9999);
	$ids =  isset($atts['ids']) ? $atts['ids'] :'';
	$layout =  isset($atts['layout']) ? $atts['layout'] :'';
	$count =  isset($atts['count']) ? $atts['count'] :'3';
	$columns =  isset($atts['columns']) && $atts['columns']!='' ? $atts['columns'] :'1';
	$order =  isset($atts['order']) ? $atts['order'] :'';
	$orderby =  isset($atts['orderby']) ? $atts['orderby'] :'';
	$meta_key 	= isset($atts['meta_key']) ? $atts['meta_key'] : '';
	$meta_value 	= isset($atts['meta_value']) ? $atts['meta_value'] : '';
	$style =  isset($atts['style']) ? $atts['style'] :'';
	$autoplay =  isset($atts['autoplay']) ? $atts['autoplay'] :'';
	$autoplayspeed =  isset($atts['autoplayspeed']) ? $atts['autoplayspeed'] :'';
	$args = array(
		'post_type' => 'we_venue',
		'posts_per_page' => $count,
		'post_status' => 'publish',
		'post__in' =>  $ids,
		'order' => $order,
		'orderby' => $orderby,
		'meta_key' => $meta_key,
		'ignore_sticky_posts' => 1,
	);
	ob_start();
	$the_query = new WP_Query( $args );
	$class = 'we-column-'.esc_attr($columns).' venue-style-'.esc_attr($style);
	if($layout=='carousel'){
		$class = 'we-carousel venue-style-'.esc_attr($style);
	}
	if($the_query->have_posts()){?>
		<div class="we-venues-sc <?php echo $class;?>" id="venue-<?php echo $ID;?>">
        	<div <?php if($layout=='carousel'){?> class=" wenv-car is-carousel" id="post-corousel-<?php echo $ID; ?>" data-items="<?php echo esc_attr($columns); ?>" <?php if($autoplay=='on'){?> data-autoplay=1 <?php }?> data-autospeed="<?php echo esc_attr($autoplayspeed);?>" data-navigation=1 data-pagination=1 <?php }?>>
			<?php
            while($the_query->have_posts()){ $the_query->the_post();
                wooevent_template_plugin('venue', true);
            }?>
            </div>
		</div>
		<?php
	}
	wp_reset_postdata();
	$output_string = ob_get_contents();
	ob_end_clean();
	return $output_string;

}
add_shortcode( 'we_venues', 'parse_we_venue_func' );
add_action( 'after_setup_theme', 'we_venue_reg_vc' );
function we_venue_reg_vc(){
	if(function_exists('vc_map')){
	vc_map( array(
	   "name" => esc_html__("WooEvents - Venues", "exthemes"),
	   "base" => "we_venues",
	   "class" => "",
	   "icon" => "icon-table",
	   "controls" => "full",
	   "category" => esc_html__('WooEvents','exthemes'),
	   "params" => array(
	   	  array(
		  	"admin_label" => true,
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => esc_html__("Layout", 'exthemes'),
			 "param_name" => "layout",
			 "value" => array(
			 	esc_html__('Grid', 'exthemes') => '',
				esc_html__('Carousel', 'exthemes') => 'carousel',
			 ),
			 "description" => ''
		  ),
		  array(
		  	"admin_label" => true,
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => esc_html__("Style", 'exthemes'),
			 "param_name" => "style",
			 "value" => array(
				esc_html__('Style 1', 'exthemes') => '1',
				esc_html__('Style 2', 'exthemes') => '2',
				esc_html__('Style 3', 'exthemes') => '3',
			 ),
			 "description" => ''
		  ),
		  array(
		  	"admin_label" => true,
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => esc_html__("Columns", 'exthemes'),
			 "param_name" => "columns",
			 "value" => array(
			 	esc_html__('', 'exthemes') => '',
				esc_html__('1 columns', 'exthemes') => '1',
				esc_html__('2 columns', 'exthemes') => '2',
				esc_html__('3 columns', 'exthemes') => '3',
				esc_html__('4 columns', 'exthemes') => '4',
				esc_html__('5 columns', 'exthemes') => '5',
			 ),
			 "description" => ''
		  ),	
		  array(
		  	"admin_label" => true,
			"type" => "textfield",
			"heading" => esc_html__("IDs", "exthemes"),
			"param_name" => "ids",
			"value" => "",
			"description" => esc_html__("Specify post IDs to retrieve", "exthemes"),
		  ),
		  array(
		  	"admin_label" => true,
			"type" => "textfield",
			"heading" => esc_html__("Count", "exthemes"),
			"param_name" => "count",
			"value" => "",
			"description" => esc_html__("Number of posts", 'exthemes'),
		  ),
		  array(
		  	"admin_label" => true,
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => esc_html__("Order", 'exthemes'),
			 "param_name" => "order",
			 "value" => array(
			 	esc_html__('DESC', 'exthemes') => 'DESC',
				esc_html__('ASC', 'exthemes') => 'ASC',
			 ),
			 "description" => ''
		  ),
		  array(
		  	 "admin_label" => true,
			 "type" => "dropdown",
			 "class" => "",
			 "heading" => esc_html__("Order by", 'exthemes'),
			 "param_name" => "orderby",
			 "value" => array(
			 	esc_html__('Date', 'exthemes') => 'date',
				esc_html__('ID', 'exthemes') => 'ID',
				esc_html__('Author', 'exthemes') => 'author',
			 	esc_html__('Title', 'exthemes') => 'title',
				esc_html__('Name', 'exthemes') => 'name',
				esc_html__('Modified', 'exthemes') => 'modified',
			 	esc_html__('Parent', 'exthemes') => 'parent',
				esc_html__('Random', 'exthemes') => 'rand',
				esc_html__('Menu order', 'exthemes') => 'menu_order',
				esc_html__('Meta value', 'exthemes') => 'meta_value',
				esc_html__('Meta value num', 'exthemes') => 'meta_value_num',
				esc_html__('Post__in', 'exthemes') => 'post__in',
				esc_html__('None', 'exthemes') => 'none',
			 ),
			 "description" => ''
		  ),
		  array(
		  	"admin_label" => true,
			"type" => "textfield",
			"heading" => esc_html__("Meta key", "exthemes"),
			"param_name" => "meta_key",
			"value" => "",
			"description" => esc_html__("Enter meta key to query", "exthemes"),
		  ),
		  array(
		  	"admin_label" => true,
			"type" => "textfield",
			"heading" => esc_html__("Meta Value", "exthemes"),
			"param_name" => "meta_value",
			"value" => "",
			"description" => esc_html__("Enter meta value to query", "exthemes"),
		  ),
	   )
	));
	}
}